"""Agent 2: RCA Recommendations tools."""

from __future__ import annotations

import json
import logging
import os
from functools import lru_cache

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.tools import tool

from agent_server.knowledge.servicenow_repository import update_work_notes
from agent_server.knowledge.snow_dump_repository import load_snow_dump
from agent_server.platform.embeddings import get_embedding_model
from typing import Annotated
from langchain_core.messages import ToolMessage
from langchain_core.tools import tool, InjectedToolCallId
from langgraph.prebuilt import InjectedState, create_react_agent
from agent_server.platform.llm import get_bedrock_llm
from langgraph.prebuilt.chat_agent_executor import AgentState
from langgraph.types import Command
from agent_server.platform.paths import CHROMA_DIR

logger = logging.getLogger(__name__)

_META_FILE = ".dump_mtime"
_INCIDENT_HISTORY_VERSION = os.getenv(
    "INCIDENT_HISTORY_TABLE", "workspace.aidq.incident_history"
)
_CONTENT_COLS = ["category", "short_description", "work_notes", "resolution_notes"]
_META_COLS = ["incident_number", "state", "created_date", "resolved_date"]


# ---------------------------------------------------------------------------
# Vectorstore setup (private)
# ---------------------------------------------------------------------------

def _documents_from_dump() -> list[Document]:
    df = load_snow_dump()
    docs = []
    for _, row in df.iterrows():
        page_content = "\n".join(
            f"{col}: {row[col]}" for col in _CONTENT_COLS if col in df.columns
        )
        metadata = {col: str(row[col]) for col in _META_COLS if col in df.columns}
        docs.append(Document(page_content=page_content, metadata=metadata))
    return docs


def _needs_rebuild() -> bool:
    if not CHROMA_DIR.exists() or not (CHROMA_DIR / _META_FILE).exists():
        return True
    stored = (CHROMA_DIR / _META_FILE).read_text(encoding="utf-8").strip()
    return stored != _INCIDENT_HISTORY_VERSION


@lru_cache(maxsize=1)
def get_vectorstore() -> Chroma:
    CHROMA_DIR.mkdir(parents=True, exist_ok=True)
    embedding = get_embedding_model()
    if not _needs_rebuild():
        logger.info("[vectorstore] Loading existing Chroma index from %s", CHROMA_DIR)
        return Chroma(persist_directory=str(CHROMA_DIR), embedding_function=embedding)
    logger.info(
        "[vectorstore] Rebuilding Chroma index from Unity Catalog table "
        "workspace.aidq.incident_history (data changed)"
    )
    docs = _documents_from_dump()
    logger.info("[vectorstore] Embedding %d incident document(s) — this may take a moment", len(docs))
    vectorstore = Chroma.from_documents(
        documents=docs,
        embedding=embedding,
        persist_directory=str(CHROMA_DIR),
    )
    (CHROMA_DIR / _META_FILE).write_text(
        _INCIDENT_HISTORY_VERSION, encoding="utf-8"
    )
    logger.info("[vectorstore] Chroma index built and persisted to %s", CHROMA_DIR)
    return vectorstore


def _search_incidents(
    query: str,
    k: int = 5,
    incident_ids: list[str] | None = None,
) -> list[tuple[Document, float]]:
    vs = get_vectorstore()
    if incident_ids:
        where = (
            {"incident_number": incident_ids[0]}
            if len(incident_ids) == 1
            else {"incident_number": {"$in": incident_ids}}
        )
        return vs.similarity_search_with_score(query, k=max(k, len(incident_ids)), filter=where)
    return vs.similarity_search_with_score(query, k=k)


def _format_incident_results(results: list[tuple[Document, float]]) -> str:
    if not results:
        return "No matching incidents found."
    lines: list[str] = []
    seen: set[str] = set()
    count = 0
    for doc, score in results:
        incident_id = doc.metadata.get("incident_number", "")
        if incident_id in seen:
            continue
        seen.add(incident_id)
        count += 1
        confidence = round((1 / (1 + score)) * 100, 2)
        lines.append(
            f"Incident {count} [{incident_id}] — confidence {confidence}%\n"
            f"{doc.page_content}\n"
            f"State: {doc.metadata.get('state', '')} | "
            f"Resolved: {doc.metadata.get('resolved_date', '')}"
        )
        lines.append("-----")
    return "\n".join(lines).strip()


# ---------------------------------------------------------------------------
# Agent 2 tools (LangChain @tool decorated)
# ---------------------------------------------------------------------------

# @tool
# def search_similar_incidents(reason_code: str, k: int = 5) -> str:
#     """Search the historical incident knowledge base for past incidents similar to this reason code.

#     Performs semantic vector search over incident descriptions, work notes, and resolution notes.

#     Args:
#         reason_code: the DQ reason code to search for (e.g. 'ENGINE_SYSTEM_CODE AND ENGINE_COMPONENT_CODE : FE ET Invalid Combination')
#         k: number of similar incidents to return (default 5)

#     Returns a formatted text block listing the top-k most relevant historical incidents
#     with their incident numbers, categories, notes, and confidence scores.
#     Call this before synthesize_rca."""
#     logger.info("[search_similar_incidents] Searching for k=%d incidents similar to: %r", k, reason_code[:120])
#     results = _search_incidents(reason_code, k=k)
#     unique_ids = {doc.metadata.get("incident_number", "") for doc, _ in results}
#     logger.info("[search_similar_incidents] Found %d result(s) covering %d unique incident(s)", len(results), len(unique_ids))
#     for doc, score in results:
#         confidence = round((1 / (1 + score)) * 100, 2)
#         logger.info(
#             "[search_similar_incidents]   incident=%s  confidence=%.1f%%",
#             doc.metadata.get("incident_number", "?"),
#             confidence,
#         )
#     return _format_incident_results(results)


# @tool
def _synthesize_rca(reason_code: str, incidents_context: str) -> str:
    """Synthesize a root cause analysis narrative from historical incident data.

    Args:
        reason_code: the DQ reason code being investigated
        incidents_context: formatted text block of similar incidents from search_similar_incidents

    Returns an RCA narrative covering:
    - Root Cause
    - Impact
    - Historical Resolution
    - Recommendation
    Call this after search_similar_incidents."""
    from agent_server.platform.llm import get_bedrock_llm

    logger.info(
        "[synthesize_rca] Synthesizing RCA for reason_code=%r (context=%d chars)",
        reason_code[:80],
        len(incidents_context),
    )
    llm = get_bedrock_llm()
    prompt = (
        "You are an RCA analyst for automotive data quality issues.\n"
        "Using ONLY the historical incident data below, provide a root cause analysis.\n\n"
        f"Reason Code Under Investigation: {reason_code}\n\n"
        f"Historical Incidents:\n{incidents_context}\n\n"
        "Provide a structured RCA with these sections:\n"
        "- Root Cause: (what typically causes this error)\n"
        "- Impact: (scope and severity based on historical data)\n"
        "- Historical Resolution: (how it was resolved in the past)\n"
        "- Recommendation: (what action to take now)\n\n"
        "Be concise and factual. Only use evidence from the provided incidents. "
        "Do not invent information."
    )
    resp = llm.invoke(prompt)
    content = resp.content if hasattr(resp, "content") else str(resp)
    if isinstance(content, list):
        content = "".join(b.get("text", "") for b in content if isinstance(b, dict))
    logger.info("[synthesize_rca] RCA narrative ready (%d chars) for reason_code=%r", len(str(content)), reason_code[:80])
    return str(content)


# @tool
# def update_servicenow_work_note(sys_id: str, work_note_content: str) -> str:
#     """Post a work note to a ServiceNow incident.

#     Args:
#         sys_id: the ServiceNow sys_id of the incident (NOT the human-readable incident number like INC0001234).
#                 If empty, null, or "None", the call is skipped and a 'skipped' status is returned.
#         work_note_content: the text to post as a work note; should summarise the RCA findings

#     Returns JSON: {sys_id, status, error}
#     Call this after synthesize_rca to document findings on the incident.
#     If sys_id is missing (ServiceNow unavailable), skip this call — the RCA result is still returned."""
#     if not sys_id or sys_id in ("None", "null", "undefined"):
#         logger.info("[update_servicenow_work_note] sys_id=%r — skipping (not available)", sys_id)
#         return json.dumps({"sys_id": sys_id, "status": "skipped",
#                            "error": "sys_id not available — work note will be posted when ServiceNow is online"})
#     logger.info("[update_servicenow_work_note] Posting work note to sys_id=%s (%d chars)", sys_id, len(work_note_content))
#     result = update_work_notes(sys_id, work_note_content)
#     logger.info("[update_servicenow_work_note] Result for sys_id=%s: %s", sys_id, result)
#     return json.dumps(result)


class RcaAgentState(AgentState):
    # inputs injected by the router at invoke time
    reason_code: str
    sys_id: str
    incident_number: str
    # produced by the tools, passed via state
    incidents_context: str
    rca_narrative: str
    work_note_status: str
    
    

@tool
def search_incidents(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Search historical incidents similar to the reason code. Call this FIRST."""
    reason_code = state.get("reason_code", "")
    results = _search_incidents(reason_code, k=5)
    context = _format_incident_results(results)
    return Command(update={
        "incidents_context": context,
        "messages": [ToolMessage(f"Found {len(results)} similar incident(s).", tool_call_id=tool_call_id)],
    })
    
@tool
def synthesize_rca(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Synthesize an RCA narrative from the searched incidents. Call AFTER search_incidents."""
    reason_code = state.get("reason_code", "")
    context = state.get("incidents_context", "")
    narrative = _synthesize_rca(reason_code, context)
    return Command(update={
        "rca_narrative": narrative,
        "messages": [ToolMessage("RCA narrative generated.", tool_call_id=tool_call_id)],
    })


@tool
def post_work_note(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Post the RCA narrative to the ServiceNow incident. Call AFTER synthesize_rca."""
    sys_id = state.get("sys_id", "")
    narrative = state.get("rca_narrative", "")
    if not sys_id or sys_id in ("None", "null", "undefined", ""):
        status = "skipped"
    else:
        result = update_work_notes(sys_id, f"[Automated RCA Recommendation]\n{narrative}")
        status = result.get("status", "updated") if isinstance(result, dict) else "updated"
    return Command(update={
        "work_note_status": status,
        "messages": [ToolMessage(f"Work note {status}.", tool_call_id=tool_call_id)],
    })