"""Agent 4: General QA tools."""

from __future__ import annotations

import json
import logging
import re

from langchain_core.tools import tool

from agent_server.knowledge.snow_dump_repository import (
    extract_incident_ids,
    format_stats_rows,
    get_known_categories,
    load_incidents_for_stats,
)

logger = logging.getLogger(__name__)

_INC_ID_RE = re.compile(r"\bINC\d+\b", re.IGNORECASE)


@tool
def query_incident_stats(question: str, category_filter: str = "") -> str:
    """Query structured statistics from Unity Catalog table workspace.aidq.incident_history.

    Use this tool for questions about counts, totals, aggregations, listings, or trends
    over historical ServiceNow incidents (e.g. 'how many incidents?', 'list all categories',
    'which category has the most incidents?').

    Args:
        question: the user's question (used for context)
        category_filter: optional category string to filter rows; if provided, only rows
                         matching this category are returned. Leave empty to get all rows.

    Returns a plain-text table of incident records (incident_number, category, state,
    created_date, resolved_date) for the LLM to analyse and answer the question."""
    logger.info("[query_incident_stats] question=%r  category_filter=%r", question[:80], category_filter)
    df = load_incidents_for_stats()
    logger.info(
        "[query_incident_stats] Loaded %d incident row(s) from Unity Catalog table "
        "workspace.aidq.incident_history",
        len(df),
    )

    if category_filter:
        # Fuzzy match: try exact first, then substring
        exact = df[df["category"].str.strip() == category_filter.strip()]
        if not exact.empty:
            filtered = exact
            label = f'category="{category_filter}" (exact match)'
        else:
            filtered = df[df["category"].str.contains(category_filter.strip(), case=False, na=False)]
            label = f'category contains "{category_filter}" (partial match)'
        result_df = filtered if not filtered.empty else df
        prefix = (
            f"INCIDENT DATA for {label} ({len(result_df)} of {len(df)} total rows):\n"
        )
        logger.info("[query_incident_stats] Filter applied — returning %d of %d rows", len(result_df), len(df))
    else:
        result_df = df
        prefix = f"INCIDENT DATA — all {len(df)} rows:\n"
        logger.info("[query_incident_stats] No filter — returning all %d rows", len(df))

    known_cats = get_known_categories()
    categories_block = f"Known categories ({len(known_cats)}): " + ", ".join(known_cats[:20])
    if len(known_cats) > 20:
        categories_block += f" ... and {len(known_cats) - 20} more"

    return f"{categories_block}\n\n{prefix}{format_stats_rows(result_df)}"


@tool
def search_incidents_semantically(query: str, k: int = 5) -> str:
    """Semantically search historical incidents for root cause, resolution details, or similar issues.

    Use this tool for questions about root cause, how an error was resolved in the past,
    or when the user asks for similar historical incidents.
    Also use it when the user mentions specific INC numbers (e.g. INC0001234) — the tool
    will perform an exact metadata lookup for those IDs.

    Args:
        query: the user's question or search text; may contain INC IDs
        k: number of incidents to return (default 5)

    Returns a formatted text block of the most relevant historical incidents with
    their incident numbers, notes, and confidence scores."""
    from agent_server.agents.rca_recommendations.tools import (
        _format_incident_results,
        _search_incidents,
    )

    mentioned_ids = extract_incident_ids(query)
    if mentioned_ids:
        logger.info("[search_incidents_semantically] Exact lookup for INC IDs: %s", mentioned_ids)
        results = _search_incidents(query, k=k, incident_ids=mentioned_ids)
        label = "DIRECTLY REQUESTED INCIDENTS (exact lookup):"
    else:
        logger.info("[search_incidents_semantically] Semantic search: k=%d  query=%r", k, query[:80])
        results = _search_incidents(query, k=k)
        label = "SEMANTICALLY SIMILAR INCIDENTS:"

    logger.info("[search_incidents_semantically] Returning %d result(s)", len(results))
    formatted = _format_incident_results(results)
    return f"{label}\n{formatted}"


@tool
def get_sop_tools_knowledge() -> str:
    """Get live knowledge about all available SOP validation tools.

    Returns the name and description of each SOP tool defined in the remediation agent.
    Use this to answer questions about:
    - Which SOPs exist and what they validate
    - Which columns are compared for each SOP
    - Which reason codes have SOP coverage

    Returns a JSON array: [{tool_name, description}]
    This list auto-updates whenever new SOP tools are added."""
    from agent_server.agents.remediation.tools import SOP_TOOLS

    knowledge = []
    for sop_tool in SOP_TOOLS:
        knowledge.append(
            {
                "tool_name": sop_tool.name,
                "description": sop_tool.description,
            }
        )
    logger.info("[get_sop_tools_knowledge] Returning knowledge for %d SOP tool(s): %s",
                len(knowledge), [k["tool_name"] for k in knowledge])
    return json.dumps(knowledge, indent=2)
