"""Agent 1: Outfile Analysis tools — bucket_outfile and create_servicenow_ticket."""

from __future__ import annotations

import json
import logging
import os
import re
from typing import Any

# import numpy as np
import requests
from langchain_core.tools import tool

from agent_server.knowledge.outfile_repository import load_outfile
from agent_server.platform.llm import get_bedrock_llm

logger = logging.getLogger(__name__)
from typing import Annotated

from langchain.messages import HumanMessage, ToolMessage
from langchain_core.tools import tool, InjectedToolCallId
from langgraph.graph import MessagesState
from langgraph.prebuilt import InjectedState, create_react_agent
from langgraph.types import Command


from agent_server.platform.contracts import AgentContext

from langgraph.prebuilt.chat_agent_executor import AgentState

class OutfileAgentState(AgentState):
    buckets: dict
    tickets: list

# def _normalize_value(value: Any) -> Any:
#     if value is None:
#         return None
#     try:
#         import pandas as pd
#         if pd.isna(value):
#             return None
#     except (TypeError, ValueError):
#         pass
#     if isinstance(value, float) and value.is_integer():
#         return int(value)
#     return value



def bucket_outfile() -> str:
    """Read the Unity Catalog outfile table and cluster errors into reason-code buckets.

    Groups records by REASON_CODE. If multiple distinct reason codes exist, uses the LLM
    to merge variant or typo codes into a single canonical bucket name.

    Returns a JSON object mapping each canonical reason code to:
      {count: int, records: [{CLAIM_NUM, ENGINE_SERIAL_NUM, REASON_CODE}]}

    Call this first before creating any ServiceNow tickets."""
    logger.info("[bucket_outfile] Loading Unity Catalog table workspace.aidq.outfile")
    df = load_outfile()
    df.columns = df.columns.str.strip()
    df = df[df["REASON_CODE"].notna()].copy()
    df["REASON_CODE"] = df["REASON_CODE"].astype(str)

    logger.info(
        "[bucket_outfile] Loaded %d error row(s) from Unity Catalog table workspace.aidq.outfile",
        len(df),
    )

    if df.empty:
        logger.warning(
            "[bucket_outfile] Unity Catalog table workspace.aidq.outfile has no rows "
            "with REASON_CODE — returning empty buckets"
        )
        return json.dumps({})

    unique_codes = df["REASON_CODE"].unique().tolist()
    logger.info("[bucket_outfile] Found %d unique reason code(s): %s", len(unique_codes), unique_codes)

    # Use LLM to merge only true duplicates (typos/whitespace/casing variants of the SAME code).
    # Codes that mention different column names are ALWAYS separate buckets — never merge them.
    if len(unique_codes) > 1:
        logger.info("[bucket_outfile] Multiple codes — checking for typo/whitespace variants to merge")
        llm = get_bedrock_llm()
        prompt = (
            "You are deduplicating data quality reason codes from an automotive claims outfile.\n\n"
            "TASK: Map each code to its canonical form.\n\n"
            "STRICT RULES — read these carefully before responding:\n"
            "1. ONLY merge codes that are clear duplicates: same column names + same error type, "
            "differing only in whitespace, punctuation, or capitalisation.\n"
            "2. NEVER merge codes that mention DIFFERENT column names. "
            "For example, a code about PROGRAM_PAYMENT_CODE is ALWAYS a different bucket from "
            "a code about ENGINE_SYSTEM_CODE — even if both say 'Invalid Combination'.\n"
            "3. When in doubt, map each code to ITSELF (no merge).\n"
            "4. The canonical name MUST preserve the original column names exactly as written.\n\n"
            "Return ONLY valid JSON — no markdown fences, no explanation:\n"
            '{"<original_code>": "<canonical_code>", ...}\n\n'
            f"Codes to deduplicate: {json.dumps(unique_codes)}"
        )
        try:
            resp = llm.invoke(prompt)
            raw = resp.content if hasattr(resp, "content") else str(resp)
            if isinstance(raw, list):
                raw = "".join(b.get("text", "") for b in raw if isinstance(b, dict))
            raw = raw.strip()
            # LLM sometimes wraps the mapping in ```json ... ``` — strip fences
            fence_match = re.search(r"```(?:json|JSON)?\s*\n?([\s\S]*?)\n?```", raw)
            if fence_match:
                raw = fence_match.group(1).strip()
            code_map: dict[str, str] = json.loads(raw)
            
            safe_map: dict[str, str] = {}
            for original in unique_codes:
                canonical = code_map.get(original, original)
                if isinstance(canonical, str) and canonical.strip() in unique_codes:
                    safe_map[original] = canonical.strip()
                else:
                    if canonical != original:
                        logger.warning(
                            "[bucket_outfile] Rejecting non-existent canonical %r for %r — keeping original",
                            canonical, original,
                        )
                    safe_map[original] = original
            code_map = safe_map
            logger.info("[bucket_outfile] LLM code mapping (Case C guard): %s", code_map)
        except Exception:
            logger.warning("[bucket_outfile] LLM clustering failed — using identity mapping", exc_info=True)
            code_map = {c: c for c in unique_codes}
    else:
        code_map = {unique_codes[0]: unique_codes[0]} if unique_codes else {}
        logger.info("[bucket_outfile] Single code — no LLM clustering needed")

    # buckets: dict[str, Any] = {}
    # for _, row in df.iterrows():
    #     original = str(row["REASON_CODE"])
    #     canonical = code_map.get(original, original)
    #     if canonical not in buckets:
    #         buckets[canonical] = {"records": [], "count": 0}
    #     buckets[canonical]["records"].append(
    #         {
    #             "CLAIM_NUM": str(row.get("CLAIM_NUM", "")),
    #             "ENGINE_SERIAL_NUM": str(row.get("ENGINE_SERIAL_NUM", "")),
    #             "REASON_CODE": original,
    #         }
    #     )

    # for cat in buckets:
    #     buckets[cat]["count"] = len(buckets[cat]["records"])
    
    df["_canonical"] = df["REASON_CODE"].map(lambda c: code_map.get(c, c))
    buckets: dict[str, Any] = {}
    for canonical, group in df.groupby("_canonical"):
        records = [
            {
                "CLAIM_NUM": str(r.get("CLAIM_NUM", "")),
                "ENGINE_SERIAL_NUM": str(r.get("ENGINE_SERIAL_NUM", "")),
                "REASON_CODE": str(r["REASON_CODE"]),
            }
            for r in group.to_dict("records")
        ]
        buckets[canonical] = {"records": records, "count": len(records)}

    logger.info("[bucket_outfile] Created %d bucket(s):", len(buckets))
    for code, data in buckets.items():
        logger.info("[bucket_outfile]   %r → %d record(s)", code, data["count"])

    return json.dumps(buckets)


def create_servicenow_ticket(reason_code: str, count: int, records: str) -> str:
    """Create a ServiceNow incident for one reason-code bucket.

    Uses the LLM to write a professional, context-aware incident description.
    Priority is set by record count: >10 → 1 (Critical), >5 → 2 (High), else → 3 (Moderate).

    Args:
        reason_code: The canonical reason code / bucket name (exact string from bucket_outfile output)
        count: Total number of error records in this bucket
        records: JSON array of up to 5 sample records with CLAIM_NUM and ENGINE_SERIAL_NUM

    Returns JSON: {category, incident_number, sys_id, error}
    Call this once per bucket returned by bucket_outfile."""
    priority_label = "Critical (P1)" if count > 10 else "High (P2)" if count > 5 else "Moderate (P3)"
    logger.info(
        "[create_servicenow_ticket] reason_code=%r  count=%d  priority=%s",
        reason_code, count, priority_label,
    )

    instance = os.getenv("SERVICENOW_INSTANCE", "").rstrip("/")
    username = os.getenv("SERVICENOW_USERNAME", "")
    password = os.getenv("SERVICENOW_PASSWORD", "")

    if not instance or not username or not password:
        logger.warning("[create_servicenow_ticket] ServiceNow credentials missing — skipping ticket creation for %r", reason_code)
        return json.dumps(
            {
                "category": reason_code,
                "incident_number": None,
                "sys_id": None,
                "error": "ServiceNow credentials missing — set SERVICENOW_INSTANCE, _USERNAME, _PASSWORD in .env",
            }
        )

    # LLM-generated description
    sample = records[:600] if len(records) > 600 else records
    logger.info("[create_servicenow_ticket] Generating LLM description for %r", reason_code)
    llm = get_bedrock_llm()
    desc_prompt = (
        "Write a concise ServiceNow incident description for this data quality issue.\n"
        f"Reason Code: {reason_code}\n"
        f"Total Affected Records: {count}\n"
        f"Sample Records (first 5): {sample}\n\n"
        "Write 2-3 professional sentences covering: what the issue is, how many records are "
        "affected, and the urgency. Do not include markdown."
    )
    try:
        dr = llm.invoke(desc_prompt)
        description = dr.content if hasattr(dr, "content") else str(dr)
        if isinstance(description, list):
            description = "".join(
                b.get("text", "") for b in description if isinstance(b, dict)
            )
        logger.info("[create_servicenow_ticket] LLM description ready (%d chars)", len(str(description)))
    except Exception:
        logger.warning("[create_servicenow_ticket] LLM description failed — using fallback text", exc_info=True)
        description = (
            f"Data quality error for reason code: {reason_code}. "
            f"{count} records affected in Unity Catalog table workspace.aidq.outfile."
        )

    priority = "1" if count > 10 else "2" if count > 5 else "3"
    url = f"{instance}/api/now/table/incident"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    payload = {
        "short_description": reason_code,
        "description": str(description),
        "priority": priority,
    }

    logger.info("[create_servicenow_ticket] POST %s for reason_code=%r", url, reason_code)
    try:
        response = requests.post(
            url, auth=(username, password), headers=headers, json=payload, timeout=30
        )
        if response.status_code == 201:
            result = response.json()["result"]
            logger.info(
                "[create_servicenow_ticket] Created incident %s (sys_id=%s) for reason_code=%r",
                result["number"], result["sys_id"], reason_code,
            )
            return json.dumps(
                {
                    "category": reason_code,
                    "incident_number": result["number"],
                    "sys_id": result["sys_id"],
                    "error": None,
                }
            )
        logger.error(
            "[create_servicenow_ticket] ServiceNow returned HTTP %s for reason_code=%r: %s",
            response.status_code, reason_code, response.text[:200],
        )
        return json.dumps(
            {
                "category": reason_code,
                "incident_number": None,
                "sys_id": None,
                "error": f"HTTP {response.status_code}: {response.text[:200]}",
            }
        )
    except requests.RequestException as exc:
        logger.exception("[create_servicenow_ticket] Request failed for reason_code=%r", reason_code)
        return json.dumps(
            {"category": reason_code, "incident_number": None, "sys_id": None, "error": str(exc)}
        )






@tool
def bucket_errors(tool_call_id: Annotated[str, InjectedToolCallId]) -> Command:
    """Bucket outfile error records by REASON_CODE using embeddings. Call this FIRST."""
    # buckets = bucket_outfile()
    buckets = json.loads(bucket_outfile())
    if not buckets:
        return Command(update={
            "buckets": {},
            "messages": [ToolMessage("No error records found in outfile.", tool_call_id=tool_call_id)],
        })
    summary = f"Created {len(buckets)} bucket(s) for reason codes: {list(buckets)}"
    logger.info("*****************************OUTFILE ANALYSIS AGENT BUCKET ************************************")
    logger.info(buckets)
    return Command(update={
        "buckets": buckets,
        "messages": [ToolMessage(summary, tool_call_id=tool_call_id)],
    })


@tool
def create_tickets(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Create ServiceNow incidents for each error bucket. Call AFTER bucket_errors."""
    buckets = state.get("buckets") or {}
    logger.info(f"Buckets: {buckets}")
    if not buckets:
        return Command(update={"messages": [
            ToolMessage("No buckets available — run bucket_errors first.", tool_call_id=tool_call_id)
        ]})
        
    tickets = []
    for reason_code, data in buckets.items():
      count = data.get("count", 0)
      records = data.get("records", [])
      esns = [
          int(r["ENGINE_SERIAL_NUM"])
          for r in records
          if str(r.get("ENGINE_SERIAL_NUM", "")).strip().isdigit()
      ]
      result = json.loads(create_servicenow_ticket(reason_code, count, json.dumps(records[:5])))
      tickets.append({
          "reason_code": reason_code,
          "incident_number": result.get("incident_number"),
          "sys_id": result.get("sys_id"),
          "count": count,
          "esns": esns,
      })
    nums = [t.get("incident_number") for t in tickets if t.get("incident_number")]
    summary = f"Created {len(nums)} incident(s): {nums}"
    return Command(update={
        "tickets": tickets,
        "messages": [ToolMessage(summary, tool_call_id=tool_call_id)],
    })