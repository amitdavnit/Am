"""Agent 3a (SOP Diagnosis) and Agent 3b (SOP Apply) — two separate ReAct instances."""

from __future__ import annotations

import logging

from langgraph.prebuilt import create_react_agent

from agent_server.agents.remediation.tools import (
    SOP_TOOLS,
    Agent3aState,
    Agent3bState,
    apply_sop_corrections,
    post_diagnosis_work_note,
    resolve_all_tickets,
)
from agent_server.platform.llm import get_bedrock_llm

logger = logging.getLogger(__name__)
NAME = "remediation"

# ---------------------------------------------------------------------------
# Agent 3a — SOP Diagnosis
# Has: SOP validation tools + work note posting
# Does NOT have: apply_sop_corrections or resolve_servicenow_ticket
# ---------------------------------------------------------------------------
AGENT3A_SYSTEM_PROMPT = """You are Agent 3a: SOP Diagnosis Agent.

You receive a reason_code (available in your state) and a list of available SOP tools.
Your job is to call the matching SOP validation tool, then post a work note.

═══════════════════════════════════════════
YOUR DEFAULT ACTION IS TO CALL A SOP TOOL.
`no_sop_match` is the LAST RESORT, not the safe default.
═══════════════════════════════════════════

STEP 1 — CALL THE MATCHING SOP TOOL (mandatory unless nothing fits)
  - The SOP tools take NO arguments — they read the reason_code from state automatically.
    You only decide WHICH tool matches and call it.
  - If the reason_code contains column names that appear in a tool's description → that tool
    is the match. Call it immediately.
  - If the reason_code describes an "invalid combination" a tool covers → call it.
  - When in doubt: CALL THE TOOL ANYWAY. total_records=0 is still valid data.
  - Only conclude no_sop_match after reading EVERY tool description and finding no overlap.

STEP 2 — POST WORK NOTE
  - Call post_diagnosis_work_note (no arguments). It reads the diagnosis and sys_id from
    state and skips automatically if sys_id is unavailable.

STEP 3 — FINISH
  - After the SOP tool and work note have run, reply with a one-line confirmation.
    The structured diagnosis is captured in state automatically — do NOT re-emit it.

IF AND ONLY IF NO TOOL FITS (genuine no-match after reading all descriptions):
  Output ONLY: {"status": "no_sop_match", "reason_code": "<reason_code>"}

ABSOLUTE RULES:
- Do NOT call apply_sop_corrections or resolve_all_tickets — diagnosis only.
- total_records: 0 is a valid result — never downgrade it to no_sop_match.
- A failed/skipped work note does NOT change the outcome."""


def get_agent3a():
    """Return Agent 3a (SOP Diagnosis) — SOP tools + work note, state-driven, no apply tools."""
    sop_names = [t.name for t in SOP_TOOLS]
    logger.info("[Agent3a] Instantiating SOP Diagnosis ReAct agent (SOP tools: %s + post_diagnosis_work_note)", sop_names)
    return create_react_agent(
        model=get_bedrock_llm(),
        tools=[*SOP_TOOLS, post_diagnosis_work_note],
        state_schema=Agent3aState,
        prompt=AGENT3A_SYSTEM_PROMPT,
    )

AGENT3B_SYSTEM_PROMPT = """You are Agent 3b: SOP Apply Agent.

Your inputs (sop_diagnoses, approved_esns, tickets) are already in your state.
The tools read them automatically — you never pass arguments.

MANDATORY SEQUENCE:
STEP 1 — Call apply_sop_corrections (no arguments). It writes the approved source_value
         corrections to Unity Catalog table workspace.aidq.outfile deterministically and
         writes a snapshot to workspace.aidq.outfile_backups first.
STEP 2 — Call resolve_all_tickets (no arguments). It resolves every ServiceNow incident.
STEP 3 — Reply with a one-line confirmation. The structured results are captured in state.

RULES:
- Do NOT call SOP validation tools — that is Agent 3a's job.
- Always resolve ALL tickets, not just the ones with corrections."""


def get_agent3b():
    logger.info("[Agent3b] Instantiating SOP Apply ReAct agent (tools: apply_sop_corrections, resolve_all_tickets)")
    return create_react_agent(
        model=get_bedrock_llm(),
        tools=[apply_sop_corrections, resolve_all_tickets],
        state_schema=Agent3bState,
        prompt=AGENT3B_SYSTEM_PROMPT,
    )