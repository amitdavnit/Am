"""Small DataFrame adapter for Unity Catalog Delta tables."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

import pandas as pd

from api.services.databricks_sql import execute_sql


def load_table(table_name: str, columns: list[str] | None = None) -> pd.DataFrame:
    projection = ", ".join(f"`{column}`" for column in columns) if columns else "*"
    rows = execute_sql(f"SELECT {projection} FROM {table_name}")
    return pd.DataFrame(rows, columns=columns if columns and not rows else None)


def _literal(value: Any) -> str:
    if value is None or (not isinstance(value, (list, dict)) and pd.isna(value)):
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return str(value)
    if isinstance(value, (datetime, date)):
        return f"'{value.isoformat()}'"
    return "'" + str(value).replace("'", "''") + "'"


def merge_dataframe(table_name: str, df: pd.DataFrame, key: str) -> None:
    """Atomically replace table contents with a DataFrame using Delta MERGE."""
    columns = list(df.columns)
    if not columns:
        return
    if df.empty:
        execute_sql(f"DELETE FROM {table_name}")
        return

    rows = ",\n".join(
        "(" + ", ".join(_literal(value) for value in row) + ")"
        for row in df.itertuples(index=False, name=None)
    )
    column_sql = ", ".join(f"`{column}`" for column in columns)
    execute_sql(
        f"""
        MERGE INTO {table_name} target
        USING (SELECT * FROM VALUES
          {rows}
        AS source({column_sql})) source
        ON target.`{key}` = source.`{key}`
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
        WHEN NOT MATCHED BY SOURCE THEN DELETE
        """
    )


def append_dataframe(table_name: str, df: pd.DataFrame) -> None:
    if df.empty:
        return
    columns = list(df.columns)
    column_sql = ", ".join(f"`{column}`" for column in columns)
    rows = ",\n".join(
        "(" + ", ".join(_literal(value) for value in row) + ")"
        for row in df.itertuples(index=False, name=None)
    )
    execute_sql(
        f"INSERT INTO {table_name} ({column_sql}) VALUES {rows}"
    )
