"""Outfile error data repository."""

from __future__ import annotations

import os
import uuid
from datetime import datetime
from pathlib import Path

import pandas as pd

from agent_server.knowledge.uc_tables import append_dataframe, load_table, merge_dataframe

OUTFILE_TABLE = os.getenv("OUTFILE_TABLE", "workspace.aidq.outfile")
OUTFILE_BACKUPS_TABLE = os.getenv(
    "OUTFILE_BACKUPS_TABLE", "workspace.aidq.outfile_backups"
)
_NUMERIC_COLUMNS = [
    "ENGINE_SERIAL_NUM",
    "PROGRAM_PAYMENT_CODE",
    "PROGRAM_ACCOUNT_CODE",
    "ENGINE_SYSTEM_CODE",
    "ENGINE_COMPONENT_CODE",
]


def load_outfile() -> pd.DataFrame:
    df = load_table(OUTFILE_TABLE)
    for column in _NUMERIC_COLUMNS:
        if column in df:
            df[column] = pd.to_numeric(df[column], errors="coerce")
    return df


def save_outfile(df: pd.DataFrame) -> None:
    merge_dataframe(OUTFILE_TABLE, df, key="ENGINE_SERIAL_NUM")


def backup_outfile() -> Path:
    snapshot_id = str(uuid.uuid4())
    timestamp = datetime.now()
    df = load_outfile()
    df.insert(0, "snapshot_at", timestamp)
    df.insert(0, "snapshot_id", snapshot_id)
    append_dataframe(OUTFILE_BACKUPS_TABLE, df)
    return Path(f"{OUTFILE_BACKUPS_TABLE}/{snapshot_id}")
