"""Markdown SOP definitions and Unity Catalog remediation knowledge."""

from __future__ import annotations

import json
import logging
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from agent_server.knowledge.uc_tables import load_table
from api.services.databricks_sql import execute_sql

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
SOP_DIR = Path(
    os.getenv(
        "SOP_MARKDOWN_DIR",
        PROJECT_ROOT / "aidq-sop-knowledgebase" / "sops",
    )
)
SOP_KNOWLEDGE_TABLE = os.getenv(
    "SOP_KNOWLEDGE_TABLE", "workspace.aidq.remediation_knowledge"
)

_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_TABLE_IDENTIFIER = re.compile(
    r"^[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*$"
)
_DEFAULT_ALLOWED_TABLES = {
    "workspace.aidq.outfile",
    "workspace.aidq.source_reference",
    "workspace.aidq.incident_history",
    SOP_KNOWLEDGE_TABLE,
}


def _allowed_tables() -> set[str]:
    configured = os.getenv("SOP_ALLOWED_TABLES", "")
    return _DEFAULT_ALLOWED_TABLES | {
        value.strip() for value in configured.split(",") if value.strip()
    }


def _validate_identifier(value: str) -> str:
    if not _IDENTIFIER.fullmatch(value):
        raise ValueError(f"Unsafe column identifier: {value!r}")
    return value


def _validate_table(table_name: str) -> str:
    if not _TABLE_IDENTIFIER.fullmatch(table_name):
        raise ValueError(f"Unsafe table identifier: {table_name!r}")
    if table_name not in _allowed_tables():
        raise ValueError(f"Table is not allowlisted for SOP access: {table_name}")
    return table_name


def load_sop_markdown(path: Path) -> dict[str, Any]:
    """Load a Markdown SOP whose frontmatter is a JSON object."""
    text = path.read_text(encoding="utf-8")
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n?(.*)$", text, re.DOTALL)
    if not match:
        raise ValueError(f"{path} must contain JSON frontmatter between --- markers")
    metadata = json.loads(match.group(1))
    if not isinstance(metadata, dict):
        raise ValueError(f"{path} frontmatter must be a JSON object")
    required = {"sop_id", "title", "reason_patterns", "validated_columns"}
    execution_mode = metadata.get("execution_mode", "lookup_validation")
    if execution_mode not in {"lookup_validation", "guided_review"}:
        raise ValueError(
            f"{path} has unsupported execution_mode: {execution_mode!r}"
        )
    if execution_mode == "lookup_validation":
        required.update({"lookup_table", "lookup_key"})
    missing = sorted(required - metadata.keys())
    if missing:
        raise ValueError(f"{path} is missing SOP fields: {', '.join(missing)}")
    metadata["execution_mode"] = execution_mode
    metadata["body"] = match.group(2).strip()
    metadata["source_path"] = str(path)
    return metadata


def load_markdown_sops() -> list[dict[str, Any]]:
    """Return all valid, active Markdown SOP definitions."""
    sops: list[dict[str, Any]] = []
    if not SOP_DIR.exists():
        logger.warning("SOP Markdown directory does not exist: %s", SOP_DIR)
        return sops
    for path in sorted(SOP_DIR.glob("*.md")):
        try:
            sop = load_sop_markdown(path)
            if sop.get("status", "active") == "active":
                sops.append(sop)
        except (OSError, ValueError, json.JSONDecodeError):
            logger.exception("Skipping invalid SOP Markdown file: %s", path)
    return sops


def match_sop(reason_code: str) -> dict[str, Any] | None:
    """Select the strongest static or successfully learned SOP match."""
    normalized = reason_code.upper()
    best: tuple[int, dict[str, Any]] | None = None
    for sop in load_markdown_sops():
        patterns = [str(value).upper() for value in sop.get("reason_patterns", [])]
        columns = [str(value).upper() for value in sop.get("validated_columns", [])]
        score = sum(3 for pattern in patterns if pattern and pattern in normalized)
        score += sum(1 for column in columns if column in normalized)
        if score and (best is None or score > best[0]):
            best = (score, sop)
    if best:
        return best[1]

    learned = list_successful_remediations(reason_code, limit=1)
    if not learned:
        return None
    row = learned[0]
    try:
        validated_columns = json.loads(row.get("validated_columns_json") or "[]")
    except (TypeError, json.JSONDecodeError):
        return None
    if not validated_columns:
        return None
    return {
        "sop_id": row.get("sop_id"),
        "title": row.get("title"),
        "status": "active",
        "reason_patterns": [row.get("reason_code")],
        "lookup_table": row.get("lookup_table"),
        "lookup_key": row.get("lookup_key"),
        "validated_columns": validated_columns,
        "verification": "lookup_match",
        "body": row.get("resolution_markdown", ""),
        "source_path": SOP_KNOWLEDGE_TABLE,
        "knowledge_source": "unity_catalog_learned_sop",
    }


def query_table(
    table_name: str,
    *,
    columns: list[str] | None = None,
) -> pd.DataFrame:
    """Read an allowlisted UC table using validated identifiers."""
    table = _validate_table(table_name)
    safe_columns = [_validate_identifier(column) for column in columns or []]
    return load_table(table, safe_columns or None)


def get_table_columns(table_name: str) -> list[str]:
    """Return column names for an allowlisted UC table without reading its rows."""
    table = _validate_table(table_name)
    rows = execute_sql(f"DESCRIBE TABLE {table}")
    return [
        str(row["col_name"])
        for row in rows
        if row.get("col_name") and not str(row["col_name"]).startswith("#")
    ]


def lookup_table(
    table_name: str,
    *,
    key_column: str,
    key_values: list[Any],
    columns: list[str],
) -> pd.DataFrame:
    """Return lookup rows for keys from an allowlisted UC table."""
    key = _validate_identifier(key_column)
    selected = list(dict.fromkeys([key, *columns]))
    frame = query_table(table_name, columns=selected)
    if key not in frame.columns:
        return frame.iloc[0:0]
    normalized = {str(value) for value in key_values}
    return frame[frame[key].map(str).isin(normalized)].copy()


def list_successful_remediations(
    reason_code: str, *, limit: int = 5
) -> list[dict[str, Any]]:
    """Retrieve successful learned solutions ranked by reason-code token overlap."""
    try:
        rows = execute_sql(
            f"""
            SELECT knowledge_id, sop_id, title, reason_code, validated_columns_json,
                   lookup_table, lookup_key, resolution_markdown, source_incident,
                   created_at
            FROM {SOP_KNOWLEDGE_TABLE}
            WHERE status = 'active' AND outcome = 'worked'
            ORDER BY created_at DESC
            LIMIT 100
            """
        )
    except Exception:
        logger.warning("Learned remediation lookup unavailable", exc_info=True)
        return []

    query_tokens = set(re.findall(r"[A-Z0-9_]+", reason_code.upper()))
    scored: list[tuple[int, dict[str, Any]]] = []
    for row in rows:
        row_tokens = set(
            re.findall(
                r"[A-Z0-9_]+",
                f"{row.get('reason_code', '')} {row.get('title', '')}".upper(),
            )
        )
        score = len(query_tokens & row_tokens)
        if score:
            scored.append((score, row))
    scored.sort(key=lambda item: item[0], reverse=True)
    return [row for _, row in scored[:limit]]


def _sql(value: Any) -> str:
    if value is None:
        return "NULL"
    return "'" + str(value).replace("'", "''") + "'"


def publish_successful_remediation(
    *,
    reason_code: str,
    validated_columns: list[str],
    lookup_table_name: str,
    lookup_key: str,
    source_incident: str | None,
    updates: list[dict[str, Any]],
    user_confirmation: str,
) -> dict[str, Any]:
    """Persist a verified recommendation as active SOP knowledge in Unity Catalog."""
    _validate_table(lookup_table_name)
    _validate_identifier(lookup_key)
    for column in validated_columns:
        _validate_identifier(column)

    stable_key = "|".join(
        [reason_code.upper(), lookup_table_name, lookup_key, *sorted(validated_columns)]
    )
    sop_id = "SOP-LEARNED-" + str(uuid.uuid5(uuid.NAMESPACE_URL, stable_key))[:8].upper()
    knowledge_id = str(uuid.uuid4())
    title = f"Learned remediation for {reason_code}"
    markdown = "\n".join(
        [
            f"# {title}",
            "",
            f"Validate `{', '.join(validated_columns)}` using "
            f"`{lookup_table_name}` keyed by `{lookup_key}`.",
            "",
            f"Verified corrections: {len(updates)}.",
        ]
    )
    now = datetime.now(timezone.utc).isoformat()
    execute_sql(
        f"""
        MERGE INTO {SOP_KNOWLEDGE_TABLE} target
        USING (
          SELECT {_sql(knowledge_id)} AS knowledge_id,
                 {_sql(sop_id)} AS sop_id,
                 {_sql(title)} AS title,
                 {_sql(reason_code)} AS reason_code,
                 {_sql(json.dumps(validated_columns))} AS validated_columns_json,
                 {_sql(lookup_table_name)} AS lookup_table,
                 {_sql(lookup_key)} AS lookup_key,
                 {_sql(markdown)} AS resolution_markdown,
                 {_sql(source_incident)} AS source_incident,
                 {_sql(json.dumps(updates, default=str))} AS evidence_json,
                 'active' AS status,
                 'worked' AS outcome,
                 {_sql(user_confirmation)} AS user_confirmation,
                 TIMESTAMP({_sql(now)}) AS created_at,
                 TIMESTAMP({_sql(now)}) AS updated_at
        ) source
        ON target.sop_id = source.sop_id
        WHEN MATCHED THEN UPDATE SET
          title = source.title,
          reason_code = source.reason_code,
          validated_columns_json = source.validated_columns_json,
          lookup_table = source.lookup_table,
          lookup_key = source.lookup_key,
          resolution_markdown = source.resolution_markdown,
          source_incident = source.source_incident,
          evidence_json = source.evidence_json,
          status = source.status,
          outcome = source.outcome,
          user_confirmation = source.user_confirmation,
          updated_at = source.updated_at
        WHEN NOT MATCHED THEN INSERT *
        """
    )
    return {
        "knowledge_id": knowledge_id,
        "sop_id": sop_id,
        "title": title,
        "status": "active",
    }
