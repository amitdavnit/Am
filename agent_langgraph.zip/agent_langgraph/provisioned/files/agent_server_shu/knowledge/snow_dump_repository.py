"""Incidents master repository — historical ServiceNow dump for RCA and QA."""

from __future__ import annotations

import os
import re

import pandas as pd

from agent_server.knowledge.uc_tables import load_table

INCIDENT_HISTORY_TABLE = os.getenv(
    "INCIDENT_HISTORY_TABLE", "workspace.aidq.incident_history"
)

# Columns exposed for stats / analytical QA (excludes heavy text fields)
_STATS_COLS = ["incident_number", "category", "state", "created_date", "resolved_date"]

_INC_ID_RE = re.compile(r"\bINC\d+\b", re.IGNORECASE)


def extract_incident_ids(text: str) -> list[str]:
    """Return unique INC-prefixed numeric IDs found in text, uppercased, order-preserved."""
    return list(dict.fromkeys(m.upper() for m in _INC_ID_RE.findall(text)))


def load_snow_dump() -> pd.DataFrame:
    """Load full incidents master (all columns). Used by vectorstore builder."""
    return load_table(INCIDENT_HISTORY_TABLE)


def load_incidents_for_stats() -> pd.DataFrame:
    """
    Load only the 5 structural columns needed for analytical QA questions.
    Keeps token count low when passing rows to the LLM.
    """
    return load_table(INCIDENT_HISTORY_TABLE, columns=_STATS_COLS)


def get_known_categories() -> list[str]:
    """Return the distinct category (reason_code) values present in the master file."""
    df = load_table(INCIDENT_HISTORY_TABLE, columns=["category"])
    return sorted(df["category"].dropna().unique().tolist())


def format_stats_rows(df: pd.DataFrame) -> str:
    """
    Format a (possibly filtered) stats DataFrame as plain text for the LLM prompt.
    Each row is one line: incident_number | category | state | created_date | resolved_date
    """
    header = " | ".join(_STATS_COLS)
    rows = "\n".join(
        " | ".join(str(row[c]) for c in _STATS_COLS)
        for _, row in df.iterrows()
    )
    return f"{header}\n{rows}"
