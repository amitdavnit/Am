"""Supervisor ReAct agent — top-level entry point for the AiDQ system.

Architecture:
  - create_react_agent + MemorySaver (persistent per thread_id)
  - All routing decisions are LLM-driven via tool selection
  - HITL handled via interrupt() inside request_human_approval tool
  - All inter-agent data flows through message history as tool observations
"""

from __future__ import annotations

import logging
from functools import lru_cache

from langgraph.checkpoint.memory import MemorySaver
from langgraph.prebuilt import create_react_agent

from agent_server.orchestration.supervisor.prompts import SUPERVISOR_SYSTEM_PROMPT
from agent_server.orchestration.supervisor.router import (
    SupervisorState,
    analyze_outfile,
    answer_question,
    apply_corrections,
    request_human_approval,
    run_all_remediations,
)
from agent_server.platform.llm import get_bedrock_llm

logger = logging.getLogger(__name__)

_SUPERVISOR_TOOLS = [
    analyze_outfile,
    run_all_remediations,
    request_human_approval,
    apply_corrections,
    answer_question,
]


@lru_cache(maxsize=1)
def get_supervisor_graph():
    """Build and return the supervisor ReAct agent graph (cached singleton).

    Uses MemorySaver so conversation history and interrupt state persist
    across turns for the same thread_id.
    """
    logger.info(
        "[SUPERVISOR] Building supervisor graph with %d tools: %s",
        len(_SUPERVISOR_TOOLS),
        [t.name for t in _SUPERVISOR_TOOLS],
    )
    graph = create_react_agent(
        model=get_bedrock_llm(),
        tools=_SUPERVISOR_TOOLS,
        prompt=SUPERVISOR_SYSTEM_PROMPT,
        state_schema=SupervisorState,
        checkpointer=MemorySaver(),
    )
    logger.info("[SUPERVISOR] Supervisor graph ready (MemorySaver checkpoint)")
    return graph
