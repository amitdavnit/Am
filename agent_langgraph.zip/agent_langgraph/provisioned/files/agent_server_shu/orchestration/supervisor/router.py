"""Supervisor tools — the five callable actions the supervisor ReAct agent can invoke."""

from __future__ import annotations

import json
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

# from langchain_core.messages import HumanMessage
# from langchain_core.tools import tool
# from langgraph.types import interrupt

from agent_server.orchestration.hitl_formatting import format_combined_hitl_summary

logger = logging.getLogger(__name__)

from typing import Annotated

from langchain_core.messages import HumanMessage, ToolMessage
from langchain_core.tools import tool, InjectedToolCallId
from langgraph.prebuilt import InjectedState
from langgraph.prebuilt.chat_agent_executor import AgentState
from langgraph.types import Command, interrupt

class SupervisorState(AgentState):
    """Pipeline state shared across supervisor tools.

    Persisted by the MemorySaver checkpointer, so it survives the HITL interrupt
    with no manual caching. Each tool reads its inputs and writes its outputs here.
    """
    tickets: list
    sop_diagnoses: list
    rca_results: list
    hitl_decision: dict
    corrections_applied: bool
    apply_result: dict
    resolved_tickets: list
# ---------------------------------------------------------------------------
# Helpers for sub-agent invocation
# ---------------------------------------------------------------------------

def _extract_last_ai_text(result: dict) -> str:
    """Extract the final AI message text from a create_react_agent invocation result."""
    messages = result.get("messages", [])
    for msg in reversed(messages):
        if hasattr(msg, "content") and not isinstance(msg, HumanMessage):
            content = msg.content
            if isinstance(content, list):
                return "".join(b.get("text", "") for b in content if isinstance(b, dict))
            return str(content)
    return ""


def _parse_json_from_text(text: str) -> Any:
    """Extract the first JSON object or array from a text block.

    Handles LLM responses that wrap JSON in markdown code fences (```json ... ```)
    as well as responses that mix prose with embedded JSON.

    Strategy:
    1. Strip markdown fences and try to parse the inner content directly.
    2. Try a direct json.loads on the full text.
    3. Bracket scan — find whichever bracket ({ or [) appears FIRST in the text,
       then use a depth counter to find the matching close bracket and parse that block.
       "Leftmost wins" ensures we always grab the outermost container:
         - Agent 1 returns  [ {...}, {...} ]  → [ comes first → full array extracted
         - Agent 3a returns { ..., "correctable": [] } → { comes first → full dict extracted
    """
    text = text.strip()

    # 1. Strip markdown code fences — LLMs often wrap JSON in ```json ... ```
    fence_match = re.search(r"```(?:json|JSON)?\s*\n?([\s\S]*?)\n?```", text)
    if fence_match:
        inner = fence_match.group(1).strip()
        try:
            return json.loads(inner)
        except (json.JSONDecodeError, ValueError):
            text = inner  # fall through to bracket-scan on stripped content

    # 2. Try direct parse
    try:
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        pass

    # 3. Bracket scan — try whichever of { or [ appears first (leftmost = outermost)
    first_brace = text.find("{")
    first_bracket = text.find("[")

    if first_brace == -1 and first_bracket == -1:
        return None

    if first_brace == -1:
        bracket_order = ["["]
    elif first_bracket == -1:
        bracket_order = ["{"]
    elif first_brace < first_bracket:
        bracket_order = ["{", "["]
    else:
        bracket_order = ["[", "{"]

    for start in bracket_order:
        idx = text.find(start)
        if idx >= 0:
            depth = 0
            for i in range(idx, len(text)):
                if text[i] in "([{":
                    depth += 1
                elif text[i] in ")]}":
                    depth -= 1
                    if depth == 0:
                        try:
                            return json.loads(text[idx : i + 1])
                        except (json.JSONDecodeError, ValueError):
                            break
    return None


def _parse_hitl_decision(user_text: str, llm: Any) -> dict:
    """Use LLM to parse free-text HITL approval response into a structured decision."""
    logger.info("[HITL] Parsing human response: %r", user_text[:120])

    # Fast-path: handle clear approve/reject keywords without an LLM round-trip
    _lower = user_text.strip().lower()
    _APPROVE_KEYWORDS = {
        "yes", "y", "approve", "approved", "confirm", "confirmed",
        "ok", "okay", "all", "approve all", "approve all records",
        "yes approve", "yes, approve", "yes please",
    }
    _REJECT_KEYWORDS = {"no", "n", "cancel", "reject", "rejected", "deny", "denied", "none"}
    if _lower in _APPROVE_KEYWORDS or any(_lower.startswith(kw) for kw in ("yes ", "approve ")):
        logger.info("[HITL] Fast-path keyword match — decision=all")
        return {"decision": "all", "approved_esns": None}
    if _lower in _REJECT_KEYWORDS:
        logger.info("[HITL] Fast-path keyword match — decision=none")
        return {"decision": "none", "approved_esns": []}

    prompt = (
        "Parse the following human approval response for a data quality remediation system.\n\n"
        f"Response: \"{user_text}\"\n\n"
        "Return ONLY valid JSON with this exact schema:\n"
        '{"decision": "<all|partial|none|invalid>", "approved_esns": [<int>, ...] or null}\n\n'
        "Rules:\n"
        "- 'all': user said yes/approve/confirm/all — approved_esns must be null\n"
        "- 'none': user said no/cancel/reject — approved_esns must be []\n"
        "- 'partial': user listed specific ENGINE_SERIAL_NUM values — extract them as integers\n"
        "- 'invalid': response is ambiguous or unrelated — approved_esns must be null\n"
        "Return ONLY valid JSON with no markdown formatting."
    )
    try:
        resp = llm.invoke(prompt)
        raw = resp.content if hasattr(resp, "content") else str(resp)
        if isinstance(raw, list):
            raw = "".join(b.get("text", "") for b in raw if isinstance(b, dict))
        # Handle markdown-wrapped JSON or extra prose around the JSON object
        extracted = _parse_json_from_text(raw)
        if extracted is not None:
            logger.info("[HITL] Parsed decision: %s", extracted)
            return extracted
        # Last resort: direct parse (works if LLM returns bare JSON)
        parsed = json.loads(raw)
        logger.info("[HITL] Parsed decision: %s", parsed)
        return parsed
    except Exception:
        logger.warning("[HITL] LLM HITL parse failed for: %r", user_text, exc_info=True)
        return {"decision": "invalid", "approved_esns": None}


# ---------------------------------------------------------------------------
# Supervisor tools
# ---------------------------------------------------------------------------

# @tool
# def analyze_outfile() -> str:
#     """Analyse the Unity Catalog outfile table and raise ServiceNow incidents.

#     Delegates to Agent 1 (Outfile Analysis ReAct agent) which:
#     1. Clusters all error records into canonical reason-code buckets
#     2. Creates one ServiceNow incident per bucket

#     Returns a JSON array of bucket + ticket results:
#     [{"reason_code": "...", "incident_number": "...", "sys_id": "...", "count": N}, ...]

#     Call this first when a user requests DQ remediation."""
#     from agent_server.agents.outfile_analysis.agent import get_agent1

#     logger.info("[AGENT1] analyze_outfile — invoking Agent 1 (Outfile Analysis)")
#     agent = get_agent1()
#     try:
#         result = agent.invoke({"messages": [HumanMessage(content="Analyse the outfile and create ServiceNow tickets.")]})
#         tickets = result.get("tickets", [])
#         logger.info("[AGENT1] Agent 1 complete — %d ticket(s) returned", len(tickets))
#         for item in tickets:
#             logger.info(
#                 "[AGENT1]   reason_code=%r  incident=%s  count=%s",
#                 item.get("reason_code"),
#                 item.get("incident_number"),
#                 item.get("count"),
#             )
#         return json.dumps(tickets)
#     except Exception as exc:
#         logger.exception("[AGENT1] Agent 1 failed with exception")
#         return json.dumps({"error": str(exc)})


@tool
def analyze_outfile(tool_call_id: Annotated[str, InjectedToolCallId]) -> Command:
    """Analyse the outfile and raise ServiceNow incidents for all error buckets (Agent 1).

    Writes the bucket/ticket list into state. Call this FIRST for a remediation run."""
    from agent_server.agents.outfile_analysis.agent import get_agent1

    logger.info("[AGENT1] analyze_outfile — invoking Agent 1 (Outfile Analysis)")
    agent = get_agent1()
    try:
        result = agent.invoke({"messages": [HumanMessage(content="Analyse the outfile and create ServiceNow tickets.")]})
        tickets = result.get("tickets", [])
        logger.info("[AGENT1] Agent 1 complete — %d ticket(s) returned", len(tickets))
        msg = f"Analysed outfile: {len(tickets)} error bucket(s) and {len(tickets)} ServiceNow incident(s) created."
    except Exception as exc:
        logger.exception("[AGENT1] Agent 1 failed with exception")
        tickets = []
        msg = f"analyze_outfile failed: {exc}"
    return Command(update={
        "tickets": tickets,
        "messages": [ToolMessage(msg, tool_call_id=tool_call_id)],
    })

def _build_sop_tool_hints() -> str:
    """Build a human-readable list of available SOP tools for Agent 3a's message context.

    Dynamically reads from SOP_TOOLS so new tools are auto-included.
    Returns the first two lines of each tool's description as a concise hint.
    """
    from agent_server.agents.remediation.tools import SOP_TOOLS

    lines = []
    for t in SOP_TOOLS:
        # First line of the docstring is the SOP id + short purpose
        desc_lines = [ln.strip() for ln in t.description.strip().splitlines() if ln.strip()]
        short_desc = " | ".join(desc_lines[:2]) if len(desc_lines) >= 2 else desc_lines[0]
        lines.append(f"  • {t.name}: {short_desc}")
    return "\n".join(lines)


# @tool
# def run_all_remediations(buckets_json: str) -> str:
#     """Run SOP diagnosis and RCA analysis for all reason-code buckets in parallel.

#     For each bucket:
#     - Tries Agent 3a (SOP Diagnosis) first — LLM reads tool descriptions and picks the match
#     - If Agent 3a returns no_sop_match, falls back to Agent 2 (RCA Recommendation)

#     Args:
#         buckets_json: JSON array from analyze_outfile, each item:
#                       {reason_code, incident_number, sys_id, count}

#     Returns JSON: {
#         "sop_diagnoses": [...],
#         "rca_results": [...],
#         "tickets": [...]   ← original bucket/ticket data passed through for downstream tools
#     }
#     Call this after analyze_outfile, passing its full output as buckets_json."""
#     from agent_server.agents.remediation.agent import get_agent3a
#     from agent_server.agents.rca_recommendations.agent import get_agent2

#     try:
#         buckets: list[dict] = json.loads(buckets_json) if isinstance(buckets_json, str) else buckets_json
#     except (json.JSONDecodeError, TypeError) as exc:
#         logger.error("[REMEDIATION] Invalid buckets_json: %s", exc)
#         return json.dumps({"error": f"Invalid buckets_json: {exc}"})

#     logger.info("[REMEDIATION] run_all_remediations — processing %d bucket(s)", len(buckets))
#     for b in buckets:
#         logger.info("[REMEDIATION]   bucket: reason_code=%r  count=%s  incident=%s",
#                     b.get("reason_code"), b.get("count"), b.get("incident_number"))

#     sop_tool_hints = _build_sop_tool_hints()

#     sop_diagnoses: list[dict] = []
#     no_sop_buckets: list[dict] = []
#     rca_results: list[dict] = []

#     def _run_sop_diagnosis(bucket: dict) -> tuple[dict, bool]:
#         """Invoke Agent 3a for one bucket. Returns (result, is_no_sop_match)."""
#         reason_code = bucket.get("reason_code", "") or ""
#         sys_id = bucket.get("sys_id") or ""
#         incident_number = bucket.get("incident_number") or ""

#         logger.info("[AGENT3a] Starting SOP diagnosis for reason_code=%r  incident=%s", reason_code, incident_number)
#         agent3a = get_agent3a()

#         # Richer context: list the available SOP tools explicitly so the LLM
#         # doesn't have to retrieve them from schema memory — it can match directly.
#         message = (
#             f"Diagnose this DQ issue.\n\n"
#             f"reason_code: {reason_code}\n"
#             f"sys_id: {sys_id if sys_id else 'not available'}\n"
#             f"incident_number: {incident_number if incident_number else 'not available'}\n\n"
#             f"Available SOP tools — read each description and call the one that matches "
#             f"the column names or concept in the reason_code above:\n"
#             f"{sop_tool_hints}\n\n"
#             f"ACTION REQUIRED: Call the matching SOP tool now using the exact reason_code "
#             f"string above. Only return no_sop_match if none of the tool descriptions "
#             f"have any overlap with the reason_code."
#         )
#         try:
#             result = agent3a.invoke({"messages": [HumanMessage(content=message)]})
#             text = _extract_last_ai_text(result)
#             parsed = _parse_json_from_text(text)

#             if isinstance(parsed, dict) and parsed.get("status") == "no_sop_match":
#                 logger.info("[AGENT3a] No SOP match for reason_code=%r → falling back to RCA (Agent 2)", reason_code)
#                 return parsed, True

#             if isinstance(parsed, dict) and "reason_code" in parsed:
#                 parsed["incident_number"] = incident_number
#                 parsed["sys_id"] = sys_id
#                 correctable_count = len(parsed.get("correctable", []))
#                 source_issue_count = len(parsed.get("source_issues", []))
#                 no_source_count = len(parsed.get("no_source", []))
#                 logger.info(
#                     "[AGENT3a] SOP match for reason_code=%r — total=%s  correctable=%d  source_issues=%d  no_source=%d",
#                     reason_code,
#                     parsed.get("total_records"),
#                     correctable_count,
#                     source_issue_count,
#                     no_source_count,
#                 )
#                 return parsed, False

#             logger.warning(
#                 "[AGENT3a] Could not parse JSON from Agent 3a output for reason_code=%r\n"
#                 "  Raw output (first 300 chars): %r",
#                 reason_code, text[:300],
#             )
#             return {"status": "no_sop_match", "reason_code": reason_code}, True

#         except Exception as exc:
#             logger.exception("[AGENT3a] Exception while diagnosing reason_code=%r", reason_code)
#             return {"status": "no_sop_match", "reason_code": reason_code, "error": str(exc)}, True

#     def _run_rca(bucket: dict) -> dict:
#         """Invoke Agent 2 for one bucket. Returns RCA result dict enriched with similar incidents."""
#         reason_code = bucket.get("reason_code", "") or ""
#         sys_id = bucket.get("sys_id") or ""
#         incident_number = bucket.get("incident_number") or ""

#         logger.info("[AGENT2] Starting RCA for reason_code=%r  incident=%s", reason_code, incident_number)
#         agent2 = get_agent2()
#         # message = (
#         #     f"Perform RCA for:\n"
#         #     f"reason_code: {reason_code}\n"
#         #     f"incident_number: {incident_number if incident_number else 'not available'}\n"
#         #     f"sys_id: {sys_id if sys_id else 'not available'}"
#         # )
#         result_dict: dict = {}
#         try:
#             agent2 = get_agent2()
#             result = agent2.invoke({
#             "messages": [HumanMessage(content="Run the RCA steps for the provided incident.")],
#             "reason_code": reason_code,
#             "sys_id": sys_id,
#             "incident_number": incident_number,
#         })
#             result_dict = {
#                 "reason_code": reason_code,
#                 "incident_number": incident_number,
#                 "rca_narrative": result.get("rca_narrative", ""),
#                 "work_note_status": result.get("work_note_status", "unknown"),
#             }
#             logger.info(
#                 "[AGENT2] RCA complete for reason_code=%r — work_note_status=%s",
#                 reason_code,
#                 result_dict["work_note_status"],
#             )
            
#         except Exception as exc:
#             logger.exception("[AGENT2] Exception during RCA for reason_code=%r", reason_code)
#             result_dict = {"reason_code": reason_code, "incident_number": incident_number, "error": str(exc)}

#         # Enrich with top-3 similar incidents from the vector DB so the HITL summary
#         # can display the semantic-match results alongside the synthesised narrative.
#         # The vectorstore is already warm from Agent 2's internal search_similar_incidents call.
#         try:
#             from agent_server.agents.rca_recommendations.tools import _search_incidents
#             raw_results = _search_incidents(reason_code, k=5)
#             seen: set[str] = set()
#             similar: list[dict] = []
#             for doc, score in raw_results:
#                 inc_num = doc.metadata.get("incident_number", "")
#                 if inc_num and inc_num not in seen:
#                     seen.add(inc_num)
#                     similar.append({
#                         "incident_number": inc_num,
#                         "confidence": round((1 / (1 + score)) * 100, 2),
#                         "state": doc.metadata.get("state", ""),
#                         "resolved_date": doc.metadata.get("resolved_date", ""),
#                         "summary": doc.page_content[:300],
#                     })
#             result_dict["similar_incidents"] = similar[:3]
#             logger.info(
#                 "[AGENT2] Similar incidents enriched — top-%d unique incident(s) for reason_code=%r",
#                 len(similar[:3]),
#                 reason_code,
#             )
#         except Exception:
#             logger.warning("[AGENT2] Could not enrich RCA with similar incidents", exc_info=True)
#             result_dict.setdefault("similar_incidents", [])

#         return result_dict

#     # Run Agent 3a in parallel for all buckets
#     logger.info("[REMEDIATION] Running Agent 3a (SOP diagnosis) in parallel for %d bucket(s)", len(buckets))
#     with ThreadPoolExecutor(max_workers=min(len(buckets), 4)) as executor:
#         future_to_bucket = {executor.submit(_run_sop_diagnosis, b): b for b in buckets}
#         for future in as_completed(future_to_bucket):
#             bucket = future_to_bucket[future]
#             try:
#                 diag_result, is_no_sop = future.result()
#                 if is_no_sop:
#                     no_sop_buckets.append(bucket)
#                 else:
#                     sop_diagnoses.append(diag_result)
#             except Exception as exc:
#                 logger.exception("[REMEDIATION] Parallel diagnosis thread failed for bucket=%s", bucket.get("reason_code"))
#                 no_sop_buckets.append(bucket)

#     logger.info(
#         "[REMEDIATION] SOP diagnosis done — matched=%d, no_sop=%d (→ RCA fallback)",
#         len(sop_diagnoses),
#         len(no_sop_buckets),
#     )

#     # Run Agent 2 (RCA) sequentially for no_sop_match buckets
#     if no_sop_buckets:
#         logger.info("[REMEDIATION] Running Agent 2 (RCA) for %d no-SOP bucket(s)", len(no_sop_buckets))
#     for bucket in no_sop_buckets:
#         rca_results.append(_run_rca(bucket))

#     logger.info(
#         "[REMEDIATION] run_all_remediations complete — sop_diagnoses=%d, rca_results=%d",
#         len(sop_diagnoses),
#         len(rca_results),
#     )
#     result_json = json.dumps(
#         {
#             "sop_diagnoses": sop_diagnoses,
#             "rca_results": rca_results,
#             "tickets": buckets,   # pass-through so downstream tools don't need analyze_outfile output
#         },
#         default=str,
#     )
#     # Cache so request_human_approval / apply_corrections can recover it
#     # if the LLM loses the large JSON across the HITL interrupt boundary.
#     _remediation_store["latest"] = result_json
#     # Reset the apply_corrections guard so a new pipeline run can use the tool again.
#     _remediation_store.pop("apply_corrections_done", None)
#     _remediation_store.pop("apply_corrections_result", None)
#     logger.info("[REMEDIATION] Remediation JSON cached (%d chars)", len(result_json))
#     return result_json


@tool
def run_all_remediations(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Run SOP diagnosis (Agent 3a) and RCA fallback (Agent 2) for every bucket.

    Reads the bucket list from state (written by analyze_outfile); writes
    sop_diagnoses and rca_results back to state. Takes no arguments."""
    from agent_server.agents.remediation.agent import get_agent3a
    from agent_server.agents.rca_recommendations.agent import get_agent2

    buckets: list[dict] = state.get("tickets", []) or []
    logger.info("***********************output of tool 1*******************************************")
    logger.info(buckets)
    logger.info("[REMEDIATION] run_all_remediations — processing %d bucket(s)", len(buckets))

    sop_tool_hints = _build_sop_tool_hints()
    sop_diagnoses: list[dict] = []
    no_sop_buckets: list[dict] = []
    rca_results: list[dict] = []

    def _run_sop_diagnosis(bucket: dict) -> tuple[dict, bool]:
        reason_code = bucket.get("reason_code", "") or ""
        sys_id = bucket.get("sys_id") or ""
        incident_number = bucket.get("incident_number") or ""
        esns = bucket.get("esns", []) or []
        logger.info("[AGENT3a] Starting SOP diagnosis for reason_code=%r  incident=%s", reason_code, incident_number)
        agent3a = get_agent3a()
        message = (
            f"Diagnose this DQ issue.\n\n"
            f"reason_code: {reason_code}\n"
            f"sys_id: {sys_id if sys_id else 'not available'}\n"
            f"incident_number: {incident_number if incident_number else 'not available'}\n\n"
            f"Available SOP tools — read each description and call the one that matches "
            f"the column names or concept in the reason_code above:\n{sop_tool_hints}\n\n"
            f"ACTION REQUIRED: Call the matching SOP tool now (it reads reason_code from state), "
            f"then post the work note. Only conclude no_sop_match if nothing overlaps."
        )
        try:
            result = agent3a.invoke({
                "messages": [HumanMessage(content=message)],
                "reason_code": reason_code,
                "sys_id": sys_id,
                "incident_number": incident_number,
                "esns": esns,
            })
            diagnosis = result.get("diagnosis")
            if isinstance(diagnosis, dict) and diagnosis.get("reason_code") is not None:
                diagnosis["incident_number"] = incident_number
                diagnosis["sys_id"] = sys_id
                logger.info(
                    "[AGENT3a] SOP match reason_code=%r — total=%s correctable=%d source_issues=%d no_source=%d work_note=%s",
                    reason_code, diagnosis.get("total_records"),
                    len(diagnosis.get("correctable", [])), len(diagnosis.get("source_issues", [])),
                    len(diagnosis.get("no_source", [])), result.get("work_note_status", "unknown"),
                )
                return diagnosis, False
            text = _extract_last_ai_text(result)
            parsed = _parse_json_from_text(text)
            if isinstance(parsed, dict) and parsed.get("status") == "no_sop_match":
                logger.info("[AGENT3a] No SOP match for reason_code=%r → RCA fallback", reason_code)
                return parsed, True
            logger.warning("[AGENT3a] No diagnosis in state for reason_code=%r; raw=%r", reason_code, text[:300])
            return {"status": "no_sop_match", "reason_code": reason_code}, True
        except Exception as exc:
            logger.exception("[AGENT3a] Exception diagnosing reason_code=%r", reason_code)
            return {"status": "no_sop_match", "reason_code": reason_code, "error": str(exc)}, True

    def _run_rca(bucket: dict) -> dict:
        reason_code = bucket.get("reason_code", "") or ""
        sys_id = bucket.get("sys_id") or ""
        incident_number = bucket.get("incident_number") or ""
        logger.info("[AGENT2] Starting RCA for reason_code=%r  incident=%s", reason_code, incident_number)
        result_dict: dict = {}
        try:
            agent2 = get_agent2()
            result = agent2.invoke({
                "messages": [HumanMessage(content="Run the RCA steps for the provided incident.")],
                "reason_code": reason_code,
                "sys_id": sys_id,
                "incident_number": incident_number,
            })
            result_dict = {
                "reason_code": reason_code,
                "incident_number": incident_number,
                "rca_narrative": result.get("rca_narrative", ""),
                "work_note_status": result.get("work_note_status", "unknown"),
            }
        except Exception as exc:
            logger.exception("[AGENT2] Exception during RCA for reason_code=%r", reason_code)
            result_dict = {"reason_code": reason_code, "incident_number": incident_number, "error": str(exc)}
        try:
            from agent_server.agents.rca_recommendations.tools import _search_incidents
            raw_results = _search_incidents(reason_code, k=5)
            seen: set[str] = set()
            similar: list[dict] = []
            for doc, score in raw_results:
                inc_num = doc.metadata.get("incident_number", "")
                if inc_num and inc_num not in seen:
                    seen.add(inc_num)
                    similar.append({
                        "incident_number": inc_num,
                        "confidence": round((1 / (1 + score)) * 100, 2),
                        "state": doc.metadata.get("state", ""),
                        "resolved_date": doc.metadata.get("resolved_date", ""),
                        "summary": doc.page_content[:300],
                    })
            result_dict["similar_incidents"] = similar[:3]
        except Exception:
            logger.warning("[AGENT2] Could not enrich RCA with similar incidents", exc_info=True)
            result_dict.setdefault("similar_incidents", [])
        return result_dict

    if buckets:
        with ThreadPoolExecutor(max_workers=min(len(buckets), 4)) as executor:
            future_to_bucket = {executor.submit(_run_sop_diagnosis, b): b for b in buckets}
            for future in as_completed(future_to_bucket):
                bucket = future_to_bucket[future]
                try:
                    diag_result, is_no_sop = future.result()
                    (no_sop_buckets if is_no_sop else sop_diagnoses).append(bucket if is_no_sop else diag_result)
                except Exception:
                    logger.exception("[REMEDIATION] Parallel diagnosis failed for %s", bucket.get("reason_code"))
                    no_sop_buckets.append(bucket)

    for bucket in no_sop_buckets:
        rca_results.append(_run_rca(bucket))

    logger.info("[REMEDIATION] Complete — sop_diagnoses=%d, rca_results=%d", len(sop_diagnoses), len(rca_results))
    msg = f"Diagnosis done — {len(sop_diagnoses)} SOP match(es), {len(rca_results)} RCA analysis result(s)."
    return Command(update={
        "sop_diagnoses": sop_diagnoses,
        "rca_results": rca_results,
        "corrections_applied": False,   # reset guard for a fresh run
        "apply_result": {},
        "resolved_tickets": [],
        "messages": [ToolMessage(msg, tool_call_id=tool_call_id)],
    })

# @tool
# def request_human_approval(remediation_json: str) -> str:
#     """Present the pipeline results to the human and wait for their approval decision.

#     Builds a deterministic Markdown table of all correctable records and an LLM-generated
#     narrative, then PAUSES execution (interrupt) until the human replies.

#     The human can reply:
#     - "yes" → approve all correctable records
#     - "no" → cancel, apply nothing
#     - comma-separated ENGINE_SERIAL_NUMs → approve only those records

#     Args:
#         remediation_json: the COMPLETE JSON output from run_all_remediations — contains
#                           sop_diagnoses, rca_results, and tickets (pass it through verbatim).
#                           You may also pass "" — the tool always recovers the authoritative
#                           copy from the internal cache.

#     Returns JSON: {"decision": "all|partial|none|invalid", "approved_esns": [ints] or null}
#     Call this after run_all_remediations, passing its full output as remediation_json."""
#     from agent_server.platform.llm import get_bedrock_llm

#     # ALWAYS prefer the cached copy — it is authoritative.
#     # The LLM frequently truncates or corrupts large JSON strings when passing them as
#     # tool parameters, especially after a long conversation history or HITL interrupt.
#     # The cache was written by run_all_remediations in the same process and is guaranteed
#     # to be complete.  Whatever the LLM passed is used only as a last-resort fallback.
#     cached = _remediation_store.get("latest", "")
#     if cached:
#         if remediation_json and remediation_json.strip() not in ("", "{}", "null", "None") and remediation_json != cached:
#             logger.info("[HITL] Overriding LLM-supplied remediation_json with authoritative cache (%d chars)", len(cached))
#         remediation_json = cached
#     elif not remediation_json or not remediation_json.strip() or remediation_json.strip() in ("{}", "null", "None"):
#         logger.error("[HITL] remediation_json missing and no cache available")
#         return json.dumps({"decision": "invalid", "error": "remediation_json not provided and no cached data"})

#     try:
#         data: dict = json.loads(remediation_json) if isinstance(remediation_json, str) else remediation_json
#     except (json.JSONDecodeError, TypeError) as exc:
#         logger.error("[HITL] Could not parse remediation_json: %s", exc)
#         return json.dumps({"decision": "invalid", "error": f"JSON parse error: {exc}"})

#     sop_diagnoses: list[dict] = data.get("sop_diagnoses", [])
#     rca_results: list[dict] = data.get("rca_results", [])
#     tickets: list[dict] = data.get("tickets", [])

#     total_correctable = sum(len(d.get("correctable", [])) for d in sop_diagnoses)
#     logger.info(
#         "[HITL] request_human_approval — sop_diagnoses=%d  rca_results=%d  tickets=%d  total_correctable=%d",
#         len(sop_diagnoses),
#         len(rca_results),
#         len(tickets),
#         total_correctable,
#     )

#     # Rebuild a buckets dict from the tickets list for the HITL formatter
#     buckets: dict = {t["reason_code"]: {"count": t.get("count", 0)} for t in tickets if "reason_code" in t}

#     summary = format_combined_hitl_summary(
#         buckets=buckets,
#         tickets=tickets,
#         rca_results=rca_results,
#         sop_diagnoses=sop_diagnoses,
#     )
#     logger.info("[HITL] Approval summary built (%d chars) — triggering interrupt", len(summary))

#     # Pause execution and wait for human input
#     human_response: str = interrupt(summary)
#     logger.info("[HITL] Interrupt resumed — human response: %r", str(human_response)[:120])

#     llm = get_bedrock_llm()
#     parsed = _parse_hitl_decision(str(human_response), llm)
#     logger.info(
#         "[HITL] Decision parsed — decision=%s  approved_esns=%s",
#         parsed.get("decision"),
#         parsed.get("approved_esns"),
#     )
#     result = json.dumps(parsed)
#     # Cache the decision so apply_corrections can recover it without relying on
#     # the LLM to pass it correctly across the HITL boundary.
#     _remediation_store["latest_decision"] = result
#     logger.info("[HITL] Decision cached (%d chars)", len(result))
#     return result


@tool
def request_human_approval(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Present pipeline results to the human and pause for their decision.

    Reads sop_diagnoses / rca_results / tickets from state, builds the summary,
    interrupts, then writes the parsed decision back to state. Takes no arguments."""
    from agent_server.platform.llm import get_bedrock_llm

    sop_diagnoses: list[dict] = state.get("sop_diagnoses", []) or []
    rca_results: list[dict] = state.get("rca_results", []) or []
    tickets: list[dict] = state.get("tickets", []) or []
    total_correctable = sum(len(d.get("correctable", [])) for d in sop_diagnoses)
    logger.info("[HITL] request_human_approval — sop=%d rca=%d tickets=%d correctable=%d",
                len(sop_diagnoses), len(rca_results), len(tickets), total_correctable)

    buckets: dict = {t["reason_code"]: {"count": t.get("count", 0)} for t in tickets if "reason_code" in t}
    summary = format_combined_hitl_summary(
        buckets=buckets, tickets=tickets, rca_results=rca_results, sop_diagnoses=sop_diagnoses,
    )
    human_response: str = interrupt(summary)
    logger.info("[HITL] Interrupt resumed — response: %r", str(human_response)[:120])

    parsed = _parse_hitl_decision(str(human_response), get_bedrock_llm())
    logger.info("[HITL] Decision parsed — %s / %s", parsed.get("decision"), parsed.get("approved_esns"))
    return Command(update={
        "hitl_decision": parsed,
        "messages": [ToolMessage(f"Human decision: {parsed.get('decision')}.", tool_call_id=tool_call_id)],
    })

# @tool
# def apply_corrections(remediation_json: str, decision_json: str) -> str:
#     """Apply approved SOP corrections to the Unity Catalog outfile table and resolve incidents.

#     Delegates to Agent 3b (SOP Apply) which:
#     1. Writes source_value corrections to workspace.aidq.outfile deterministically
#     2. Generates LLM-written close notes and resolves each incident

#     Args:
#         remediation_json: the COMPLETE JSON output from run_all_remediations.
#                           You may pass "" — the tool always recovers the authoritative
#                           copy from the internal cache.
#         decision_json: the JSON output from request_human_approval
#                        {"decision": "all|partial", "approved_esns": [...] or null}.
#                        You may pass "" — the tool recovers the cached decision automatically.

#     Returns JSON summary of corrections applied and tickets resolved.
#     Call this after request_human_approval when decision is 'all' or 'partial'."""
#     from agent_server.agents.remediation.agent import get_agent3b

#     # Guard against duplicate calls — the supervisor must call this EXACTLY ONCE per pipeline run.
#     # If the LLM calls it again (e.g. in a loop), return the cached result immediately so no
#     # additional corrections are applied and the Agent 3b is not re-invoked.
#     if _remediation_store.get("apply_corrections_done"):
#         cached_result = _remediation_store.get("apply_corrections_result", "{}")
#         logger.warning(
#             "[AGENT3b] apply_corrections already executed for this pipeline run — "
#             "returning cached result (%d chars) to stop the loop",
#             len(cached_result),
#         )
#         return json.dumps({"status": "ALREADY_DONE", "cached_result": cached_result})

#     # ALWAYS prefer the cached remediation — authoritative, never truncated.
#     cached_remediation = _remediation_store.get("latest", "")
#     if cached_remediation:
#         if remediation_json and remediation_json.strip() not in ("", "{}", "null", "None") and remediation_json != cached_remediation:
#             logger.info("[AGENT3b] Overriding LLM-supplied remediation_json with authoritative cache (%d chars)", len(cached_remediation))
#         remediation_json = cached_remediation
#     elif not remediation_json or not remediation_json.strip() or remediation_json.strip() in ("{}", "null", "None"):
#         logger.error("[AGENT3b] remediation_json missing and no cache available")
#         return json.dumps({"status": "ERROR", "error": "remediation_json not provided and no cached data"})

#     # Recover decision_json from cache if the LLM did not pass it correctly.
#     if not decision_json or not decision_json.strip() or decision_json.strip() in ("{}", "null", "None"):
#         cached_decision = _remediation_store.get("latest_decision", "")
#         if cached_decision:
#             logger.warning("[AGENT3b] decision_json missing/empty — recovering from cache (%d chars)", len(cached_decision))
#             decision_json = cached_decision
#         else:
#             logger.error("[AGENT3b] decision_json missing and no cached decision available")
#             return json.dumps({"status": "ERROR", "error": "decision_json not provided and no cached decision"})

#     try:
#         data: dict = json.loads(remediation_json) if isinstance(remediation_json, str) else {}
#     except (json.JSONDecodeError, TypeError) as exc:
#         logger.error("[AGENT3b] JSON parse error for remediation_json: %s", exc)
#         return json.dumps({"status": "ERROR", "error": f"JSON parse error (remediation_json): {exc}"})

#     try:
#         decision: dict = json.loads(decision_json) if isinstance(decision_json, str) else {}
#     except (json.JSONDecodeError, TypeError) as exc:
#         logger.error("[AGENT3b] JSON parse error for decision_json: %s", exc)
#         return json.dumps({"status": "ERROR", "error": f"JSON parse error (decision_json): {exc}"})

#     sop_diagnoses = data.get("sop_diagnoses", [])
#     tickets = data.get("tickets", [])
#     approved_esns = decision.get("approved_esns")
#     decision_type = decision.get("decision", "unknown")
#     approved_esns_str = "all" if approved_esns is None else json.dumps(approved_esns)

#     logger.info(
#         "[AGENT3b] apply_corrections — decision=%s  approved_esns=%s  sop_diagnoses=%d  tickets=%d",
#         decision_type,
#         approved_esns_str[:80],
#         len(sop_diagnoses),
#         len(tickets),
#     )

#     agent3b = get_agent3b()
#     message = (
#         f"Apply corrections and resolve tickets.\n\n"
#         f"SOP diagnoses:\n{json.dumps(sop_diagnoses, default=str)}\n\n"
#         f"Approved ESNs: {approved_esns_str}\n\n"
#         f"Tickets to resolve:\n{json.dumps(tickets, default=str)}"
#     )
#     try:
#         result = agent3b.invoke({"messages": [HumanMessage(content=message)]})
#         text = _extract_last_ai_text(result)
#         parsed = _parse_json_from_text(text)
#         if parsed is not None:
#             apply_status = parsed.get("apply_result", {}).get("status") if isinstance(parsed, dict) else "?"
#             resolved_count = len(parsed.get("resolved_tickets", [])) if isinstance(parsed, dict) else "?"
#             logger.info(
#                 "[AGENT3b] apply_corrections complete — apply_status=%s  resolved_tickets=%s",
#                 apply_status,
#                 resolved_count,
#             )
#             final_result = json.dumps(parsed, default=str)
#         else:
#             logger.warning("[AGENT3b] Could not parse JSON from Agent 3b output — returning raw text")
#             final_result = text
#     except Exception as exc:
#         logger.exception("[AGENT3b] Agent 3b failed with exception")
#         final_result = json.dumps({"status": "ERROR", "error": str(exc)})

#     # Mark this pipeline run as done so duplicate calls are caught by the guard above.
#     _remediation_store["apply_corrections_done"] = True
#     _remediation_store["apply_corrections_result"] = final_result
#     logger.info("[AGENT3b] apply_corrections marked as done for this pipeline run")
#     return final_result


@tool
def apply_corrections(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Apply approved SOP corrections and resolve all incidents (Agent 3b).

    Reads sop_diagnoses / tickets / hitl_decision from state. Idempotent — the
    corrections_applied flag in state prevents duplicate application. No arguments."""
    from agent_server.agents.remediation.agent import get_agent3b

    if state.get("corrections_applied"):
        logger.warning("[AGENT3b] apply_corrections already ran for this thread — no-op")
        return Command(update={
            "messages": [ToolMessage(
                'apply_corrections already ran (status ALREADY_DONE) — display the summary and STOP.',
                tool_call_id=tool_call_id,
            )],
        })

    sop_diagnoses: list[dict] = state.get("sop_diagnoses", []) or []
    tickets: list[dict] = state.get("tickets", []) or []
    decision: dict = state.get("hitl_decision", {}) or {}
    approved_esns = decision.get("approved_esns")  # None => all
    logger.info("[AGENT3b] apply_corrections — decision=%s sop=%d tickets=%d",
                decision.get("decision", "unknown"), len(sop_diagnoses), len(tickets))

    agent3b = get_agent3b()
    try:
        result = agent3b.invoke({
            "messages": [HumanMessage(content="Apply the approved corrections and resolve all tickets.")],
            "sop_diagnoses": sop_diagnoses,
            "approved_esns": approved_esns,
            "tickets": tickets,
        })
        apply_result = result.get("apply_result", {}) or {}
        resolved_tickets = result.get("resolved_tickets", []) or []
    except Exception as exc:
        logger.exception("[AGENT3b] Agent 3b failed")
        apply_result = {"status": "ERROR", "error": str(exc), "updates": []}
        resolved_tickets = []

    corrections = len(apply_result.get("updates", []))
    resolved_ok = sum(1 for r in resolved_tickets if r.get("status") == "resolved")
    source_issues = sum(len(d.get("source_issues", [])) for d in sop_diagnoses)
    rca_count = len(state.get("rca_results", []) or [])
    summary_msg = (
        f"apply_result.status={apply_result.get('status')} | buckets={len(tickets)} | "
        f"corrections_applied={corrections} | incidents_resolved={resolved_ok} | "
        f"source_issues={source_issues} | rca_analyses={rca_count}"
    )
    logger.info("[AGENT3b] %s", summary_msg)
    return Command(update={
        "corrections_applied": True,
        "apply_result": apply_result,
        "resolved_tickets": resolved_tickets,
        "messages": [ToolMessage(summary_msg, tool_call_id=tool_call_id)],
    })


@tool
def answer_question(question: str) -> str:
    """Answer a question about SOPs, historical incidents, or the AiDQ process.

    Delegates to Agent 4 (General QA) which has access to:
    - Incident stats from Unity Catalog table workspace.aidq.incident_history
    - Semantic search over incident work notes and resolution details
    - Live SOP tool descriptions

    Args:
        question: the user's question verbatim

    Returns a factual, cited answer.
    Use this for any question that is NOT a request to run the remediation pipeline."""
    from agent_server.agents.general_qa.agent import get_agent4

    logger.info("[AGENT4] answer_question — question: %r", question[:120])
    agent4 = get_agent4()
    try:
        result = agent4.invoke({"messages": [HumanMessage(content=question)]})
        answer = _extract_last_ai_text(result)
        logger.info("[AGENT4] Answer ready — %d chars", len(answer))
        return answer
    except Exception as exc:
        logger.exception("[AGENT4] Agent 4 failed with exception")
        return f"I was unable to answer your question due to an error: {exc}"
