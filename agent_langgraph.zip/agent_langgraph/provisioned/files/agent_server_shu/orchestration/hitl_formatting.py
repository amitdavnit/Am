"""HITL summary formatting — fully deterministic table + narrative builders."""

from __future__ import annotations

from typing import Any


# ─────────────────────────────────────────────────────────────────────────────
# Section formatters (deterministic — retained unchanged)
# ─────────────────────────────────────────────────────────────────────────────

def format_sop_section(diagnosis: dict[str, Any]) -> list[str]:
    lines = [
        f"### {diagnosis.get('sop_no', 'SOP-???')} — {diagnosis['reason_code']}",
        f"**Tool:** `{diagnosis.get('tool_name', diagnosis.get('tool_name', 'unknown'))}`  |  "
        f"**Total records:** {diagnosis['total_records']}  |  "
        f"Correctable: {len(diagnosis['correctable'])}  |  "
        f"Source issues: {len(diagnosis['source_issues'])}  |  "
        f"No source: {len(diagnosis['no_source'])}",
    ]

    if diagnosis["correctable"]:
        lines.extend(
            [
                "",
                "| ENGINE_SERIAL_NUM | Column | Current | Source |",
                "|---|---|---|---|",
            ]
        )
        for row in diagnosis["correctable"]:
            for col, vals in row["differences"].items():
                lines.append(
                    f"| {row['ENGINE_SERIAL_NUM']} | {col} | "
                    f"{vals['error_value']} | {vals['source_value']} |"
                )

    if diagnosis["source_issues"]:
        lines.append("")
        lines.append("**Source issues (no auto-fix):**")
        for row in diagnosis["source_issues"]:
            lines.append(f"- ESN {row['ENGINE_SERIAL_NUM']}: {row.get('message', 'same invalid values')}")

    if diagnosis["no_source"]:
        lines.append("")
        lines.append("**No source record:**")
        for row in diagnosis["no_source"]:
            lines.append(f"- ESN {row['ENGINE_SERIAL_NUM']}: {row.get('message', 'no source record found')}")

    return lines


def format_rca_section(result: dict[str, Any]) -> list[str]:
    lines = [f"### {result['reason_code']}"]
    if result.get("incident_number"):
        lines.append(f"**Incident:** {result['incident_number']}")

    # Top similar incidents from vector DB semantic search
    similar = result.get("similar_incidents", [])
    if similar:
        lines += [
            "",
            "**Top Matching Historical Incidents (semantic search):**",
            "",
            "| # | Incident | Confidence | State | Resolved |",
            "|---|---|---|---|---|",
        ]
        for i, inc in enumerate(similar[:3], 1):
            inc_num = inc.get("incident_number", "N/A")
            confidence = inc.get("confidence", 0)
            state = inc.get("state", "—")
            resolved = inc.get("resolved_date", "—")
            lines.append(f"| {i} | {inc_num} | {confidence}% | {state} | {resolved} |")

    lines.extend(["", result.get("rca_narrative", result.get("answer", ""))])
    return lines


# ─────────────────────────────────────────────────────────────────────────────
# Per-step detail builders — streamed to the UI right after each step completes
# so the user sees each step's output directly below that step's confirmation.
# ─────────────────────────────────────────────────────────────────────────────

def format_step1_detail(tickets: list[dict[str, Any]]) -> str:
    """Step 1 output: error buckets found and ServiceNow incidents created.

    ``tickets`` is the JSON array returned by analyze_outfile:
    [{reason_code, incident_number, sys_id, count}, ...]
    """
    created = sum(1 for t in tickets if t.get("incident_number"))
    lines = [
        f"✅ STEP 1 complete. Found {len(tickets)} error bucket(s) and created "
        f"{created} ServiceNow incident(s).",
        "",
        "| # | Reason Code | Records | Incident |",
        "|---|---|---|---|",
    ]
    for i, t in enumerate(tickets, 1):
        rc = t.get("reason_code") or t.get("category", "")
        count = t.get("count", "—")
        inc = t.get("incident_number") or "—"
        lines.append(f"| {i} | {rc} | {count} | {inc} |")

    failed = [t for t in tickets if t.get("error") and not t.get("incident_number")]
    if failed:
        lines.append("")
        lines.append(f"> ⚠️ {len(failed)} incident creation(s) failed and were skipped.")
    return "\n".join(lines)


def format_step2_detail(data: dict[str, Any]) -> str:
    """Step 2 output: SOP diagnosis results + RCA analysis for no-SOP buckets.

    ``data`` is the JSON object returned by run_all_remediations:
    {sop_diagnoses: [...], rca_results: [...], tickets: [...]}
    """
    sop_diagnoses = data.get("sop_diagnoses", [])
    rca_results = data.get("rca_results", [])
    total_correctable = sum(len(d.get("correctable", [])) for d in sop_diagnoses)
    total_source_issues = sum(len(d.get("source_issues", [])) for d in sop_diagnoses)
    total_no_source = sum(len(d.get("no_source", [])) for d in sop_diagnoses)

    lines = [
        f"✅ STEP 2 complete. Diagnosis done — {len(sop_diagnoses)} SOP match(es), "
        f"{len(rca_results)} RCA analysis result(s).",
        "",
        f"Correctable: **{total_correctable}**  |  Source-level issues: "
        f"**{total_source_issues}**  |  No source data: **{total_no_source}**",
    ]

    if sop_diagnoses:
        lines += ["", "### SOP Diagnosis *(actionable on approval)*", ""]
        for diagnosis in sop_diagnoses:
            lines += format_sop_section(diagnosis)
            lines.append("")

    if rca_results:
        lines += [
            "", "### RCA Analysis *(informational — no file changes)*",
            "",
            "> The following reason code(s) have **no SOP mapping**. "
            "RCA analysis is for context only — these will not modify the outfile.",
            "",
        ]
        for result in rca_results:
            lines += format_rca_section(result)
            lines.append("")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Approval prompt builder — slim (the per-step detail was already shown above)
# ─────────────────────────────────────────────────────────────────────────────

def format_combined_hitl_summary(
    buckets: dict[str, Any],
    tickets: list[dict[str, Any]],
    rca_results: list[dict[str, Any]],
    sop_diagnoses: list[dict[str, Any]],
) -> str:
    """Build the HITL approval prompt.

    The per-step detail (buckets/incidents and SOP/RCA diagnosis) is now streamed
    directly under each step as it completes, so this prompt is intentionally slim:
    it only lists the rows that will actually change and asks for the decision.
    """
    total_correctable = sum(len(d.get("correctable", [])) for d in sop_diagnoses)

    lines: list[str] = [
        "## 🛡️ Human Approval Required",
        "",
        f"**Total correctable SOP rows:** {total_correctable}",
        "",
    ]

    if total_correctable > 0:
        lines += [
            "The following row(s) will be corrected in the outfile on approval:",
            "",
            "| ENGINE_SERIAL_NUM | Reason Code | Column | Current | Source |",
            "|---|---|---|---|---|",
        ]
        for diagnosis in sop_diagnoses:
            rc = diagnosis.get("reason_code", "")
            for row in diagnosis.get("correctable", []):
                for col, vals in row.get("differences", {}).items():
                    lines.append(
                        f"| {row['ENGINE_SERIAL_NUM']} | {rc} | {col} | "
                        f"{vals['error_value']} | {vals['source_value']} |"
                    )
        lines.append("")
    else:
        lines += [
            "No correctable records were found — approving will resolve the "
            "ServiceNow incidents without changing the outfile.",
            "",
        ]

    lines += [
        "RCA analysis and source-level issues shown above are informational only — "
        "they do **not** modify any files.",
        "",
        "**Approve SOP corrections to the outfile?**",
        "- Reply `yes` to apply all correctable rows",
        "- Reply `no` to cancel",
        "- Reply comma-separated ENGINE_SERIAL_NUM values to apply specific rows only",
    ]

    return "\n".join(lines)
