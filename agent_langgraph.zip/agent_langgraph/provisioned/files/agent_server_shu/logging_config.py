"""Centralized logging configuration for the agent server.

Call setup_logging() once at startup (in start_server.py) to configure all loggers.
Every module in agent_server uses the standard ``logging.getLogger(__name__)`` pattern
and will automatically inherit this configuration.
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime
from pathlib import Path


# ── ANSI colour codes ──────────────────────────────────────────────────────────
_RESET = "\x1b[0m"
_BOLD = "\x1b[1m"
_GREY = "\x1b[38;5;245m"
_CYAN = "\x1b[36m"
_GREEN = "\x1b[32m"
_YELLOW = "\x1b[33m"
_RED = "\x1b[31m"
_BRIGHT_RED = "\x1b[91m"
_MAGENTA = "\x1b[35m"

_LEVEL_COLOURS = {
    logging.DEBUG: _GREY,
    logging.INFO: _GREEN,
    logging.WARNING: _YELLOW,
    logging.ERROR: _RED,
    logging.CRITICAL: _BRIGHT_RED,
}

_AGENT_COLOURS = {
    "outfile_analysis": _CYAN,
    "rca_recommendations": _MAGENTA,
    "remediation": _YELLOW,
    "general_qa": _GREEN,
    "supervisor": _BOLD,
    "router": _BOLD,
    "agent_server.agent": _CYAN,
}


class _ColourFormatter(logging.Formatter):
    """Custom formatter that colours log levels and highlights agent module names."""

    FMT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    DATEFMT = "%Y-%m-%d %H:%M:%S"

    def format(self, record: logging.LogRecord) -> str:  # noqa: A003
        level_colour = _LEVEL_COLOURS.get(record.levelno, _RESET)
        coloured_level = f"{level_colour}{_BOLD}{record.levelname:<8}{_RESET}"

        # Highlight the agent name segment
        module_colour = _RESET
        for key, colour in _AGENT_COLOURS.items():
            if key in record.name:
                module_colour = colour
                break
        coloured_name = f"{module_colour}{record.name}{_RESET}"

        msg = record.getMessage()
        if record.exc_info:
            msg += "\n" + self.formatException(record.exc_info)
        if record.stack_info:
            msg += "\n" + self.formatStack(record.stack_info)

        ts = self.formatTime(record, self.DATEFMT)
        return f"{_GREY}{ts}{_RESET} | {coloured_level} | {coloured_name} | {msg}"


class _PlainFormatter(logging.Formatter):
    """Plain formatter for non-TTY outputs (log files, CI, etc.)."""

    FMT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    DATEFMT = "%Y-%m-%d %H:%M:%S"

    def format(self, record: logging.LogRecord) -> str:  # noqa: A003
        self._style._fmt = self.FMT
        self.datefmt = self.DATEFMT
        return super().format(record)


def _make_log_file() -> Path:
    """Create a timestamped log file in the project logs/ directory."""
    from agent_server.platform.paths import LOGS_DIR
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return LOGS_DIR / f"run_{timestamp}.log"


def setup_logging(level: int = logging.INFO) -> None:
    """Configure the root logger for the entire agent-server project.

    Call once at process startup. Safe to call multiple times (idempotent).
    Creates a new timestamped log file in logs/ for every server run.
    """
    root = logging.getLogger()
    if root.handlers:
        return  # Already configured

    # Ensure console output can encode Unicode (e.g. → ✅ —) on Windows,
    # whose default console codepage (cp1252) otherwise raises
    # UnicodeEncodeError inside logging handlers.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    # ── Console handler ────────────────────────────────────────────────────────
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    if sys.stdout.isatty():
        console_handler.setFormatter(_ColourFormatter())
    else:
        console_handler.setFormatter(_PlainFormatter())

    # ── File handler — new file per server run ─────────────────────────────────
    log_path = _make_log_file()
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)   # capture DEBUG and above in file
    file_handler.setFormatter(_PlainFormatter())

    root.setLevel(logging.DEBUG)           # root captures everything; handlers filter
    root.addHandler(console_handler)
    root.addHandler(file_handler)

    # Quiet noisy third-party loggers (WARNING and above, i.e. errors only)
    for noisy in (
        "httpx",
        "httpcore",
        "urllib3",
        "botocore",
        "boto3",
        "chromadb",
        "sentence_transformers",
        "mlflow.utils.autologging_utils",
        "mlflow.tracking",
        "uvicorn.access",
    ):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    # opentelemetry floods the terminal with warnings about dict-typed span attributes
    # from MLflow's Bedrock autologging — these are harmless and can be fully silenced.
    for silent in (
        "opentelemetry",
        "opentelemetry.attributes",
        "opentelemetry.sdk",
        "opentelemetry.exporter",
    ):
        logging.getLogger(silent).setLevel(logging.ERROR)

    logging.getLogger("agent_server").setLevel(level)
    logger = logging.getLogger(__name__)
    logger.info("Logging initialised at level %s", logging.getLevelName(level))
    logger.info("Run log file: %s", log_path)
