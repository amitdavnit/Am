"""pgvector-backed incident semantic search (Lakebase)."""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any

from langchain_core.documents import Document

from agent_server.platform.embeddings import get_embedding_model
from agent_server.platform.lakebase import AIDQ_SCHEMA, execute, lakebase_configured
from config import get_embedding_config

logger = logging.getLogger(__name__)

_CONTENT_COLS = ["category", "short_description", "work_notes", "resolution_notes"]
_META_COLS = ["incident_number", "state", "created_date", "resolved_date"]


def _content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:32]


def _row_to_document(row: dict[str, Any]) -> Document:
    page_content = "\n".join(
        f"{col}: {row.get(col)}" for col in _CONTENT_COLS if row.get(col)
    )
    metadata = {col: str(row.get(col) or "") for col in _META_COLS}
    return Document(page_content=page_content, metadata=metadata)


def upsert_incident_documents(docs: list[Document]) -> int:
    """Embed and upsert incident documents into aidq.incident_embeddings (+ history)."""
    if not docs:
        return 0
    if not lakebase_configured():
        raise RuntimeError("Lakebase is required for pgvector incident storage")

    embedding_model = get_embedding_model()
    texts = [d.page_content for d in docs]
    vectors = embedding_model.embed_documents(texts)
    dims = get_embedding_config()["dims"]

    count = 0
    for doc, vector in zip(docs, vectors):
        if len(vector) != dims:
            raise ValueError(
                f"Embedding dim mismatch: got {len(vector)}, expected {dims}. "
                "Update config/agents.yaml embeddings.dims or EMBEDDING_DIMS."
            )
        incident_number = str(doc.metadata.get("incident_number") or "").strip()
        if not incident_number:
            continue
        meta = {k: doc.metadata.get(k) for k in _META_COLS}
        chash = _content_hash(doc.page_content)
        vec_literal = "[" + ",".join(str(float(x)) for x in vector) + "]"

        # Ensure history row exists (minimal upsert from metadata / content)
        execute(
            f"""
            INSERT INTO {AIDQ_SCHEMA}.incident_history (
                incident_number, category, short_description, work_notes,
                resolution_notes, state, created_date, resolved_date, updated_at
            ) VALUES (
                %(incident_number)s, %(category)s, %(short_description)s,
                %(work_notes)s, %(resolution_notes)s, %(state)s,
                %(created_date)s, %(resolved_date)s, NOW()
            )
            ON CONFLICT (incident_number) DO UPDATE SET
                category = COALESCE(EXCLUDED.category, {AIDQ_SCHEMA}.incident_history.category),
                short_description = COALESCE(EXCLUDED.short_description, {AIDQ_SCHEMA}.incident_history.short_description),
                work_notes = COALESCE(EXCLUDED.work_notes, {AIDQ_SCHEMA}.incident_history.work_notes),
                resolution_notes = COALESCE(EXCLUDED.resolution_notes, {AIDQ_SCHEMA}.incident_history.resolution_notes),
                state = COALESCE(EXCLUDED.state, {AIDQ_SCHEMA}.incident_history.state),
                created_date = COALESCE(EXCLUDED.created_date, {AIDQ_SCHEMA}.incident_history.created_date),
                resolved_date = COALESCE(EXCLUDED.resolved_date, {AIDQ_SCHEMA}.incident_history.resolved_date),
                updated_at = NOW()
            """,
            {
                "incident_number": incident_number,
                "category": _extract_field(doc.page_content, "category"),
                "short_description": _extract_field(doc.page_content, "short_description"),
                "work_notes": _extract_field(doc.page_content, "work_notes"),
                "resolution_notes": _extract_field(doc.page_content, "resolution_notes"),
                "state": meta.get("state") or "",
                "created_date": meta.get("created_date") or "",
                "resolved_date": meta.get("resolved_date") or "",
            },
            fetch=False,
        )

        execute(
            f"""
            INSERT INTO {AIDQ_SCHEMA}.incident_embeddings (
                incident_number, content_text, embedding, metadata_json, content_hash, updated_at
            ) VALUES (
                %(incident_number)s, %(content_text)s, %(embedding)s::vector,
                %(metadata_json)s::jsonb, %(content_hash)s, NOW()
            )
            ON CONFLICT (incident_number) DO UPDATE SET
                content_text = EXCLUDED.content_text,
                embedding = EXCLUDED.embedding,
                metadata_json = EXCLUDED.metadata_json,
                content_hash = EXCLUDED.content_hash,
                updated_at = NOW()
            """,
            {
                "incident_number": incident_number,
                "content_text": doc.page_content,
                "embedding": vec_literal,
                "metadata_json": json.dumps(meta),
                "content_hash": chash,
            },
            fetch=False,
        )
        count += 1
    logger.info("[pgvector] Upserted %d incident embedding(s)", count)
    return count


def _extract_field(page_content: str, field: str) -> str:
    prefix = f"{field}: "
    for line in page_content.splitlines():
        if line.startswith(prefix):
            return line[len(prefix) :]
    return ""


def similarity_search(
    query: str,
    k: int = 5,
    incident_ids: list[str] | None = None,
) -> list[tuple[Document, float]]:
    """Cosine-distance search over aidq.incident_embeddings."""
    if not lakebase_configured():
        raise RuntimeError("Lakebase is required for pgvector search")

    embedding_model = get_embedding_model()
    query_vec = embedding_model.embed_query(query)
    vec_literal = "[" + ",".join(str(float(x)) for x in query_vec) + "]"

    if incident_ids:
        rows = execute(
            f"""
            SELECT e.incident_number, e.content_text, e.metadata_json,
                   (e.embedding <=> %(embedding)s::vector) AS distance
            FROM {AIDQ_SCHEMA}.incident_embeddings e
            WHERE e.incident_number = ANY(%(ids)s)
            ORDER BY e.embedding <=> %(embedding)s::vector
            LIMIT %(k)s
            """,
            {
                "embedding": vec_literal,
                "ids": incident_ids,
                "k": max(k, len(incident_ids)),
            },
        )
    else:
        rows = execute(
            f"""
            SELECT e.incident_number, e.content_text, e.metadata_json,
                   (e.embedding <=> %(embedding)s::vector) AS distance
            FROM {AIDQ_SCHEMA}.incident_embeddings e
            ORDER BY e.embedding <=> %(embedding)s::vector
            LIMIT %(k)s
            """,
            {"embedding": vec_literal, "k": k},
        )

    results: list[tuple[Document, float]] = []
    for row in rows:
        meta = row.get("metadata_json") or {}
        if isinstance(meta, str):
            meta = json.loads(meta)
        meta = dict(meta)
        meta.setdefault("incident_number", row["incident_number"])
        doc = Document(page_content=row["content_text"], metadata=meta)
        results.append((doc, float(row["distance"])))
    return results


def documents_from_history_rows(rows: list[dict[str, Any]]) -> list[Document]:
    return [_row_to_document(r) for r in rows]
