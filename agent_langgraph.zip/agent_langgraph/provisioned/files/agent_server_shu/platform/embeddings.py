"""Shared embedding model — Databricks serving endpoint or a local model.

Set ``EMBEDDINGS_PROVIDER=local`` to embed on-device with all-MiniLM-L6-v2 via
chromadb's bundled ONNX runtime. This avoids the Databricks embedding endpoint
(``databricks-gte-large-en``) and its per-workspace QPS rate limit, which makes
local development fast and free. Defaults to the Databricks endpoint so deployed
behaviour is unchanged.
"""

from __future__ import annotations

import os
from functools import lru_cache

from langchain_core.embeddings import Embeddings

_LOCAL_PROVIDERS = {"local", "minilm", "onnx", "sentence-transformers"}


class _LocalMiniLMEmbeddings(Embeddings):
    """all-MiniLM-L6-v2 embeddings via chromadb's bundled ONNX runtime (no torch)."""

    def __init__(self) -> None:
        from chromadb.utils import embedding_functions

        self._ef = embedding_functions.DefaultEmbeddingFunction()

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [list(map(float, vec)) for vec in self._ef(list(texts))]

    def embed_query(self, text: str) -> list[float]:
        return list(map(float, self._ef([text])[0]))


@lru_cache(maxsize=1)
def get_embedding_model() -> Embeddings:
    """Return the shared embedding model used by RCA / vector search."""
    provider = os.getenv("EMBEDDINGS_PROVIDER", "databricks").strip().lower()
    if provider in _LOCAL_PROVIDERS:
        return _LocalMiniLMEmbeddings()

    from databricks_langchain import DatabricksEmbeddings

    return DatabricksEmbeddings(
        endpoint=os.getenv(
            "DATABRICKS_EMBEDDING_ENDPOINT",
            "databricks-gte-large-en",
        )
    )
