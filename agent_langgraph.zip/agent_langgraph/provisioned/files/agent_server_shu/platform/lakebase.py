"""Lakebase (Postgres) connection helpers for AIDQ app state + pgvector."""

from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from functools import lru_cache
from typing import Any, Iterator, Sequence
from urllib.parse import quote_plus

logger = logging.getLogger(__name__)

AIDQ_SCHEMA = os.getenv("AIDQ_PG_SCHEMA", "aidq")


def lakebase_configured() -> bool:
    """True when enough env is set to open a Postgres connection."""
    if os.getenv("POSTGRES_URL") or os.getenv("DATABASE_URL"):
        return True
    return bool(os.getenv("PGHOST") and os.getenv("PGDATABASE"))


def _oauth_token() -> str:
    from databricks.sdk import WorkspaceClient

    w = WorkspaceClient()
    # Prefer database credential API when instance name is known.
    instance = os.getenv("LAKEBASE_INSTANCE_NAME")
    if instance:
        try:
            from databricks.sdk.service.database import (
                GenerateDatabaseCredentialRequest,
            )

            cred = w.database.generate_database_credential(
                request=GenerateDatabaseCredentialRequest(instance_names=[instance])
            )
            if cred and cred.token:
                return cred.token
        except Exception:
            logger.debug(
                "[lakebase] generate_database_credential failed; falling back to workspace token",
                exc_info=True,
            )
    return w.config.authenticate().get("Authorization", "").removeprefix("Bearer ").strip()


def _resolve_username() -> str:
    if os.getenv("PGUSER"):
        return os.environ["PGUSER"]
    try:
        from databricks.sdk import WorkspaceClient

        w = WorkspaceClient()
        me = w.current_user.me()
        return me.user_name or me.emails[0].value if me.emails else "postgres"
    except Exception:
        return os.getenv("USER", "postgres")


@lru_cache(maxsize=1)
def get_connection_dsn() -> str:
    """Build a Postgres DSN for Lakebase / local Postgres."""
    url = os.getenv("POSTGRES_URL") or os.getenv("DATABASE_URL")
    if url:
        return url

    if not lakebase_configured():
        raise RuntimeError(
            "Lakebase is not configured. Set POSTGRES_URL or PGHOST+PGDATABASE "
            "(and LAKEBASE_INSTANCE_NAME for OAuth), then re-run quickstart."
        )

    host = os.environ["PGHOST"]
    database = os.environ.get("PGDATABASE", "databricks_postgres")
    port = os.environ.get("PGPORT", "5432")
    user = _resolve_username()
    password = os.getenv("PGPASSWORD") or _oauth_token()
    sslmode = os.getenv("PGSSLMODE", "require")
    return (
        f"postgresql://{quote_plus(user)}:{quote_plus(password)}"
        f"@{host}:{port}/{database}?sslmode={sslmode}"
    )


@contextmanager
def get_connection() -> Iterator[Any]:
    """Yield a psycopg connection with autocommit off (caller commits)."""
    import psycopg
    from psycopg.rows import dict_row

    # Refresh DSN each call so OAuth tokens can rotate.
    get_connection_dsn.cache_clear()
    dsn = get_connection_dsn()
    conn = psycopg.connect(dsn, row_factory=dict_row)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def execute(
    sql: str,
    params: Sequence[Any] | dict[str, Any] | None = None,
    *,
    fetch: bool = True,
) -> list[dict[str, Any]]:
    """Execute a SQL statement and optionally return rows as dicts."""
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            if not fetch:
                return []
            if cur.description is None:
                return []
            return list(cur.fetchall())


def execute_script(sql_text: str) -> None:
    """Run a multi-statement SQL script."""
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql_text)
