"""Databricks LLM helper (foundation model serving endpoints)."""

from __future__ import annotations

import os
from functools import lru_cache

from databricks_langchain import ChatDatabricks


@lru_cache(maxsize=1)
def get_llm() -> ChatDatabricks:
    """Return the shared ChatDatabricks model used by all agents."""
    return ChatDatabricks(
        endpoint=os.getenv("DATABRICKS_LLM_ENDPOINT", "databricks-gpt-5-2"),
        temperature=float(os.getenv("DATABRICKS_LLM_TEMPERATURE", "0")),
    )


# Backward-compatible alias used throughout the multi-agent stack.
get_bedrock_llm = get_llm
