"""Lakebase AsyncCheckpointSaver lifecycle for durable HITL / short-term memory."""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Optional

from databricks.sdk import WorkspaceClient
from databricks_langchain import AsyncCheckpointSaver

logger = logging.getLogger(__name__)

# Long-lived checkpointer opened once in FastAPI lifespan.
_checkpointer: Optional[AsyncCheckpointSaver] = None


def set_checkpointer(checkpointer: AsyncCheckpointSaver | None) -> None:
    global _checkpointer
    _checkpointer = checkpointer


def get_checkpointer() -> AsyncCheckpointSaver | None:
    return _checkpointer


@dataclass(frozen=True)
class LakebaseConfig:
    instance_name: Optional[str]
    autoscaling_endpoint: Optional[str]
    autoscaling_project: Optional[str]
    autoscaling_branch: Optional[str]
    memory_schema: Optional[str] = None

    @property
    def description(self) -> str:
        return (
            self.autoscaling_endpoint
            or self.instance_name
            or f"{self.autoscaling_project}/{self.autoscaling_branch}"
        )

    @property
    def configured(self) -> bool:
        return bool(
            self.autoscaling_endpoint
            or self.instance_name
            or (self.autoscaling_project and self.autoscaling_branch)
        )


def _is_lakebase_hostname(value: str) -> bool:
    return ".database." in value and value.endswith(".com")


def resolve_lakebase_instance_name(
    instance_name: str, workspace_client: Optional[WorkspaceClient] = None
) -> str:
    if not _is_lakebase_hostname(instance_name):
        return instance_name
    client = workspace_client or WorkspaceClient()
    hostname = instance_name
    instances = list(client.database.list_database_instances())
    for instance in instances:
        rw_dns = getattr(instance, "read_write_dns", None)
        ro_dns = getattr(instance, "read_only_dns", None)
        if hostname in (rw_dns, ro_dns):
            resolved = getattr(instance, "name", None)
            if resolved:
                logger.info(
                    "Resolved Lakebase hostname '%s' to instance '%s'",
                    hostname,
                    resolved,
                )
                return resolved
    raise ValueError(f"Unable to resolve Lakebase hostname '{hostname}' to an instance name")


def init_lakebase_config() -> LakebaseConfig:
    endpoint = os.getenv("LAKEBASE_AUTOSCALING_ENDPOINT") or None
    raw_name = os.getenv("LAKEBASE_INSTANCE_NAME") or None
    project = os.getenv("LAKEBASE_AUTOSCALING_PROJECT") or None
    branch = os.getenv("LAKEBASE_AUTOSCALING_BRANCH") or None
    memory_schema = os.getenv("LAKEBASE_AGENT_MEMORY_SCHEMA") or None

    has_autoscaling = bool(project and branch)
    if endpoint:
        return LakebaseConfig(
            instance_name=None,
            autoscaling_endpoint=endpoint,
            autoscaling_project=None,
            autoscaling_branch=None,
            memory_schema=memory_schema,
        )
    if has_autoscaling:
        return LakebaseConfig(
            instance_name=None,
            autoscaling_endpoint=None,
            autoscaling_project=project,
            autoscaling_branch=branch,
            memory_schema=memory_schema,
        )
    if raw_name:
        return LakebaseConfig(
            instance_name=resolve_lakebase_instance_name(raw_name),
            autoscaling_endpoint=None,
            autoscaling_project=None,
            autoscaling_branch=None,
            memory_schema=memory_schema,
        )
    return LakebaseConfig(
        instance_name=None,
        autoscaling_endpoint=None,
        autoscaling_project=None,
        autoscaling_branch=None,
        memory_schema=memory_schema,
    )


@asynccontextmanager
async def lakebase_checkpointer_context(config: LakebaseConfig):
    """Open AsyncCheckpointSaver for the process lifetime."""
    if not config.configured:
        raise RuntimeError(
            "Lakebase is not configured. Set LAKEBASE_AUTOSCALING_ENDPOINT "
            "or LAKEBASE_INSTANCE_NAME (or project+branch)."
        )
    async with AsyncCheckpointSaver(
        instance_name=config.instance_name,
        autoscaling_endpoint=config.autoscaling_endpoint,
        project=config.autoscaling_project,
        branch=config.autoscaling_branch,
        schema=config.memory_schema,
    ) as checkpointer:
        await checkpointer.setup()
        yield checkpointer


def get_lakebase_access_error_message(description: str) -> str:
    app_name = os.getenv("DATABRICKS_APP_NAME", "<app-name>")
    return (
        f"Failed to connect to Lakebase '{description}'. "
        f"Ensure the app SP for '{app_name}' has CAN_CONNECT_AND_CREATE, "
        "then run: uv run python scripts/grant_lakebase_permissions.py "
        "<sp-client-id> --memory-type langgraph (and --memory-type aidq)."
    )
