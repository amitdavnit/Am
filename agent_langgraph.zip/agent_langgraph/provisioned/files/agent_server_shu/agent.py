"""MLflow agent server entry point — wires to the supervisor ReAct graph."""

import logging
import uuid
from pathlib import Path
from typing import AsyncGenerator

from dotenv import load_dotenv
import mlflow
from langchain_core.messages import HumanMessage
from langgraph.types import Command
from mlflow.genai.agent_server import invoke, stream
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentResponse,
    ResponsesAgentStreamEvent,
    to_chat_completions_input,
)

from agent_server.orchestration.workflows.supervisor_workflow import (
    get_supervisor_graph,
)
from agent_server.utils import get_session_id, process_agent_astream_events

load_dotenv(dotenv_path=Path(__file__).parent.parent / ".env", override=True)

logger = logging.getLogger(__name__)
mlflow.langchain.autolog()
logging.getLogger("mlflow.utils.autologging_utils").setLevel(logging.ERROR)


def _extract_user_text(request: ResponsesAgentRequest) -> str:
    """Extract the latest user message text from the request."""
    user_messages = to_chat_completions_input([item.model_dump() for item in request.input])
    for msg in reversed(user_messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, list):
                return "".join(
                    block.get("text", "") for block in content
                    if isinstance(block, dict) and block.get("type") == "text"
                )
            return str(content)
    return ""


def _graph_input(request: ResponsesAgentRequest) -> dict:
    """Build normal graph input (new human turn)."""
    user_messages = to_chat_completions_input([item.model_dump() for item in request.input])
    langchain_messages = []
    for message in user_messages:
        if message["role"] == "user":
            langchain_messages.append(HumanMessage(content=message["content"]))
    return {"messages": langchain_messages}


def _graph_config(request: ResponsesAgentRequest) -> dict:
    thread_id = get_session_id(request) or str(uuid.uuid4())
    return {"configurable": {"thread_id": thread_id}}


async def _has_pending_interrupt(config: dict) -> bool:
    """Check whether the supervisor graph has a pending interrupt for this thread."""
    try:
        graph = get_supervisor_graph()
        state = await graph.aget_state(config)
        return any(bool(task.interrupts) for task in state.tasks)
    except Exception:
        return False


@invoke()
async def invoke_handler(request: ResponsesAgentRequest) -> ResponsesAgentResponse:
    logger.info("[INVOKE] Non-streaming invocation started — collecting stream events")
    outputs = [
        event.item
        async for event in stream_handler(request)
        if event.type == "response.output_item.done"
    ]
    logger.info("[INVOKE] Complete — %d output item(s) collected", len(outputs))
    return ResponsesAgentResponse(output=outputs)


@stream()
async def stream_handler(
    request: ResponsesAgentRequest,
) -> AsyncGenerator[ResponsesAgentStreamEvent, None]:
    session_id = get_session_id(request)
    if session_id:
        mlflow.update_current_trace(metadata={"mlflow.trace.session": session_id})
        logger.info("[STREAM] Session: %s", session_id)
    else:
        logger.info("[STREAM] No session ID — new thread will be assigned")

    config = _graph_config(request)
    thread_id = config.get("configurable", {}).get("thread_id", "unknown")
    graph = get_supervisor_graph()

    # Detect whether the graph is paused at a HITL interrupt for this thread.
    # If so, resume with the user's message as the interrupt return value.
    # Otherwise, start a new agent turn with the message as input.
    if await _has_pending_interrupt(config):
        user_text = _extract_user_text(request)
        logger.info(
            "[STREAM] thread=%s — HITL interrupt pending; resuming with: %r",
            thread_id,
            user_text[:120],
        )
        graph_input = Command(resume=user_text)
    else:
        user_text = _extract_user_text(request)
        logger.info(
            "[STREAM] thread=%s — New turn; user message: %r",
            thread_id,
            user_text[:120],
        )
        graph_input = _graph_input(request)

    event_count = 0
    safe_config = {**config, "recursion_limit": 25}
    async for event in process_agent_astream_events(
        graph.astream(
            graph_input, config=safe_config, stream_mode=["updates", "messages"]
        )
    ):
        event_count += 1
        yield event

    logger.info(
        "[STREAM] thread=%s — Stream finished (%d event(s) yielded)",
        thread_id,
        event_count,
    )
