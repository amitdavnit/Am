from pathlib import Path

from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from mlflow.genai.agent_server import AgentServer, setup_mlflow_git_based_version_tracking

# Load env vars from .env before importing the agent for proper auth
load_dotenv(dotenv_path=Path(__file__).parent.parent / ".env", override=True)

from agent_server.logging_config import setup_logging  # noqa: E402

setup_logging()

# Register agent invoke/stream handlers
import agent_server.agent  # noqa: E402

# Top-level API package (REST) — separate from agent_server
from api import api_router  # noqa: E402

agent_server = AgentServer("ResponsesAgent", enable_chat_proxy=False)

# Define the app as a module level variable to enable multiple workers
app = agent_server.app  # noqa: F841

app.include_router(api_router)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    """Agent API root — the React AiDQ UI is deployed as a separate Databricks App."""
    return JSONResponse(
        {
            "service": "aidq-agent",
            "ui": "Deploy and open the React AiDQ app (e2e-chatbot-app-next).",
            "endpoints": {
                "invocations": "/invocations",
                "incidents": "/api/v1/incidents",
                "threads": "/api/v1/threads",
                "feedback": "/api/v1/feedback",
                "health": "/api/v1/health",
            },
        }
    )


try:
    setup_mlflow_git_based_version_tracking()
except Exception:
    # git may be unavailable (e.g. local dev without git installed);
    # version tracking is best-effort and must not block server startup.
    pass


def main():
    agent_server.run(app_import_string="agent_server.start_server:app")
