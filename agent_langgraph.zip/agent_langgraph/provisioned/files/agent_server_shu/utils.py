import json
import logging
from typing import Any, AsyncGenerator, AsyncIterator, Optional

from databricks.sdk import WorkspaceClient
from langchain.messages import AIMessage, AIMessageChunk, ToolMessage
from mlflow.genai.agent_server import get_request_headers
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentStreamEvent,
    create_text_delta,
    output_to_responses_items_stream,
)

logger = logging.getLogger(__name__)


def _extract_text_content(content: Any) -> str:
    """Bedrock returns content as [{'type': 'text', 'text': '...'}] blocks."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            block.get("text", "")
            for block in content
            if isinstance(block, dict) and block.get("type") == "text"
        )
    return ""


def _normalize_message_content(msg: Any) -> None:
    if hasattr(msg, "content") and not isinstance(msg.content, str):
        msg.content = _extract_text_content(msg.content)


def _format_step_detail_from_state(node_data: dict) -> str:
    """Build per-step detail markdown from a tool node's state update.

    The pipeline tools now return Command(update={...}) instead of a JSON
    ToolMessage payload, so the step data lives in the node's state diff:
      - Step 2 (run_all_remediations): writes sop_diagnoses / rca_results
      - Step 1 (analyze_outfile):      writes tickets
    Returns "" for any node update that isn't a pipeline step.
    """
    from agent_server.orchestration.hitl_formatting import (
        format_step1_detail,
        format_step2_detail,
    )

    # Check Step 2 first — run_all_remediations is the only node that writes these.
    if "sop_diagnoses" in node_data or "rca_results" in node_data:
        return format_step2_detail(node_data)

    # Step 1 — analyze_outfile is the only node that writes a non-empty tickets list.
    tickets = node_data.get("tickets")
    if isinstance(tickets, list) and tickets:
        return format_step1_detail(tickets)

    return ""


def get_session_id(request: ResponsesAgentRequest) -> str | None:
    if request.context and request.context.conversation_id:
        return request.context.conversation_id
    if request.custom_inputs and isinstance(request.custom_inputs, dict):
        return request.custom_inputs.get("session_id")
    return None


def get_user_workspace_client() -> WorkspaceClient:
    token = get_request_headers().get("x-forwarded-access-token")
    return WorkspaceClient(token=token, auth_type="pat")


def get_databricks_host_from_env() -> Optional[str]:
    try:
        w = WorkspaceClient()
        return w.config.host
    except Exception as e:
        logging.exception(f"Error getting databricks host from env: {e}")
        return None


async def process_agent_astream_events(
    async_stream: AsyncIterator[Any],
) -> AsyncGenerator[ResponsesAgentStreamEvent, None]:
    """
    Generic helper to process agent stream events and yield ResponsesAgentStreamEvent objects.

    All user-facing text is derived from the "updates" event (complete node
    output dicts). Token-level "messages" events are intentionally ignored —
    surfacing them duplicated the deterministic per-step detail blocks. The
    "updates" branch emits:
      - a deterministic per-step detail block for each completed pipeline tool
        (Step 1 buckets/incidents, Step 2 SOP diagnosis + RCA)
      - supervisor free-text ONLY when it does not accompany a tool call
        (final pipeline summary, Q&A answers, clarifications)
      - the LangGraph interrupt() value (HITL approval summary) when an
        "updates" event carries the "__interrupt__" key

    Args:
        async_stream: The async iterator from agent.astream()
    """
    # Monotonic counter so every streamed text block gets a UNIQUE item_id.
    # The frontend (Databricks ai-sdk provider) keys text parts by item_id, so a
    # reused id (e.g. both step details coming from the "tools" node) would be
    # merged into a single part and the second block would not render as its own
    # section. A per-emission sequence guarantees each step renders separately.
    step_seq = 0

    async for event in async_stream:
        if event[0] == "updates":
            update_dict = event[1]

            # ── Interrupt event ────────────────────────────────────────────
            # When interrupt() is called inside a tool, LangGraph emits:
            #   ("updates", {"__interrupt__": (<Interrupt(value=..., resumable=True)>, )})
            # We stream the interrupt value as text so the frontend sees it.
            if "__interrupt__" in update_dict:
                interrupts = update_dict["__interrupt__"]
                if not isinstance(interrupts, (list, tuple)):
                    interrupts = [interrupts]
                logger.info(
                    "[utils] HITL interrupt fired — streaming approval summary to client (%d interrupt(s))",
                    len(interrupts),
                )
                for intr in interrupts:
                    value = getattr(intr, "value", None)
                    if value is None:
                        value = str(intr)
                    if isinstance(value, str) and value.strip():
                        yield ResponsesAgentStreamEvent(
                            **create_text_delta(delta=value, item_id="hitl-interrupt")
                        )
                continue

            # ── Normal updates (state diffs from completed nodes) ──────────
            for node_name, node_data in update_dict.items():
                if not isinstance(node_data, dict):
                    continue

                # Deterministic per-step detail block, derived from the tool's
                # STATE update (Command(update=...)) rather than the ToolMessage
                # content. Step 1 = buckets/incidents, Step 2 = SOP diagnosis + RCA.
                step_detail = _format_step_detail_from_state(node_data)
                if step_detail:
                    step_seq += 1
                    logger.info(
                        "[utils]   Emitting step detail from node %r (%d chars, seq=%d)",
                        node_name,
                        len(step_detail),
                        step_seq,
                    )
                    yield ResponsesAgentStreamEvent(
                        **create_text_delta(
                            delta=step_detail,
                            item_id=f"step-detail-{node_name}-{step_seq}",
                        )
                    )

                messages = node_data.get("messages", [])
                if len(messages) > 0:
                    logger.info(
                        "[utils] Update from node %r — %d message(s)",
                        node_name,
                        len(messages),
                    )
                    for msg in messages:
                        if isinstance(msg, ToolMessage):
                            logger.info(
                                "[utils]   ToolMessage  tool_call_id=%s  content_len=%d",
                                getattr(msg, "tool_call_id", "?"),
                                len(str(msg.content)),
                            )
                            if not isinstance(msg.content, str):
                                msg.content = json.dumps(msg.content)
                            # Step detail is now emitted above from node_data
                            # (the Command state update), so the ToolMessage
                            # content is no longer parsed here.
                        else:
                            _normalize_message_content(msg)
                            # Surface supervisor free-text ONLY when it does NOT
                            # accompany a tool call. Text emitted alongside a
                            # pipeline tool call is the "✅ STEP X complete…"
                            # chatter, which is now rendered deterministically
                            # from the tool result above — streaming it too would
                            # duplicate every step line. Messages with no tool
                            # call are the genuine outputs we want: the final
                            # pipeline summary, Q&A answers, clarifications.
                            if isinstance(msg, (AIMessage, AIMessageChunk)) and not getattr(
                                msg, "tool_calls", None
                            ):
                                text = _extract_text_content(msg.content)
                                if text.strip() and not text.lstrip().startswith("✅ STEP"):
                                    yield ResponsesAgentStreamEvent(
                                        **create_text_delta(
                                            delta=text,
                                            item_id=getattr(msg, "id", None)
                                            or "supervisor-text",
                                        )
                                    )
                    for item in output_to_responses_items_stream(messages):
                        yield item

        # NOTE: token-level "messages" events are intentionally not surfaced.
        # With Bedrock streaming enabled they re-emitted the supervisor's
        # "✅ STEP X complete…" chatter token-by-token, which duplicated the
        # deterministic per-step detail blocks. All user-facing text is now
        # emitted from the "updates" branch above (per-step details from tool
        # results, plus tool-call-free supervisor text such as the final
        # summary and Q&A answers).
