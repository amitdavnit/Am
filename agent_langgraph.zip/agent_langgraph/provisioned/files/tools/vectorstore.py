"""Shared tools package (vectorstore helpers re-exported for clean imports)."""

from agent_server.platform.pgvector_store import (
    documents_from_history_rows,
    similarity_search,
    upsert_incident_documents,
)

__all__ = [
    "documents_from_history_rows",
    "similarity_search",
    "upsert_incident_documents",
]
