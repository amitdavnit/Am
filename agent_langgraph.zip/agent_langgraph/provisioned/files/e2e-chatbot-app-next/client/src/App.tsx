import { Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@/components/theme-provider';
import { SessionProvider } from '@/contexts/SessionContext';
import { AppConfigProvider } from '@/contexts/AppConfigContext';
import { DataStreamProvider } from '@/components/data-stream-provider';
import { Toaster } from 'sonner';
import RootLayout from '@/layouts/RootLayout';
import ChatLayout from '@/layouts/ChatLayout';
import { DashboardContent } from '@/components/dashboard-content';
import { NotificationsContent } from '@/components/notifications-content';
import { PlaceholderPage, PageShell } from '@/components/page-shell';
import { useSession } from '@/contexts/SessionContext';

function IncidentsPage() {
  const { session } = useSession();
  return (
    <PageShell>
      <DashboardContent
        userName={
          session?.user?.name ??
          session?.user?.preferredUsername ??
          session?.user?.email
        }
      />
    </PageShell>
  );
}

function NotificationsPage() {
  return (
    <PageShell>
      <NotificationsContent />
    </PageShell>
  );
}

function App() {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="light"
      enableSystem={false}
      disableTransitionOnChange
    >
      <SessionProvider>
        <AppConfigProvider>
          <DataStreamProvider>
            <Toaster position="top-center" />
            <Routes>
              <Route path="/" element={<RootLayout />}>
                {/* ChatLayout keeps the chat panel mounted across every child page */}
                <Route element={<ChatLayout />}>
                  <Route index element={<IncidentsPage />} />
                  <Route path="chat/:id" element={<IncidentsPage />} />
                  <Route path="notifications" element={<NotificationsPage />} />
                  <Route
                    path="dq-health"
                    element={
                      <PlaceholderPage
                        title="DQ Health Check"
                        description="Dashboard and scorecard views will appear here. The AIDQ assistant stays available on the right."
                      />
                    }
                  />
                  <Route
                    path="rules"
                    element={
                      <PlaceholderPage
                        title="Rule Management"
                        description="Data quality rule configuration will appear here. The AIDQ assistant stays available on the right."
                      />
                    }
                  />
                  <Route
                    path="settings"
                    element={
                      <PlaceholderPage
                        title="Settings"
                        description="Application settings will appear here. The AIDQ assistant stays available on the right."
                      />
                    }
                  />
                </Route>
              </Route>
            </Routes>
          </DataStreamProvider>
        </AppConfigProvider>
      </SessionProvider>
    </ThemeProvider>
  );
}

export default App;
