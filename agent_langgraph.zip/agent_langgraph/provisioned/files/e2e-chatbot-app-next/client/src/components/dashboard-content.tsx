import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ArrowDownRight,
  ArrowUpRight,
  ChevronRight,
  Filter,
  MoreHorizontal,
  RefreshCw,
} from 'lucide-react';

type Incident = {
  incident_id?: string | null;
  title?: string | null;
  description?: string | null;
  priority?: string | null;
  status?: string | null;
  assigned_to?: string | null;
  created_date?: string | null;
};

type IncidentSummary = {
  total: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
  in_progress: number;
  resolved: number;
  new: number;
  by_priority: Record<string, number>;
  by_status: Record<string, number>;
};

const toneStyles = {
  blue: 'bg-blue-50 text-blue-700 border-blue-100',
  red: 'bg-red-50 text-red-600 border-red-100',
  orange: 'bg-orange-50 text-orange-600 border-orange-100',
  amber: 'bg-amber-50 text-amber-600 border-amber-100',
  green: 'bg-emerald-50 text-emerald-600 border-emerald-100',
} as const;

const priorityColors: Record<string, string> = {
  Critical: '#e34b4f',
  High: '#ec8d30',
  Medium: '#e8c846',
  Low: '#5e8ee5',
};

const categoryColors = ['#3767d6', '#7756c7', '#db5b72', '#e29a32', '#66a56c'];

function initials(name?: string) {
  const parts = (name || 'User').trim().split(/\s+/);
  return `${parts[0]?.[0] ?? 'U'}${parts.length > 1 ? parts.at(-1)?.[0] ?? '' : ''}`.toUpperCase();
}

function deriveCategories(items: Incident[]) {
  const buckets: Record<string, number> = {
    'Data Quality Issue': 0,
    'Data Ingestion Failure': 0,
    'Schema / Metadata Issue': 0,
    'Data Pipeline Failure': 0,
    Others: 0,
  };
  for (const item of items) {
    const t = `${item.title || ''} ${item.description || ''}`.toLowerCase();
    if (t.includes('schema') || t.includes('metadata')) buckets['Schema / Metadata Issue'] += 1;
    else if (t.includes('ingest') || t.includes('load') || t.includes('connector'))
      buckets['Data Ingestion Failure'] += 1;
    else if (t.includes('pipeline') || t.includes('job') || t.includes('transform'))
      buckets['Data Pipeline Failure'] += 1;
    else if (
      t.includes('quality') ||
      t.includes('validation') ||
      t.includes('duplicate') ||
      t.includes('pii') ||
      t.includes('retention')
    )
      buckets['Data Quality Issue'] += 1;
    else buckets.Others += 1;
  }
  const total = Math.max(items.length, 1);
  return Object.entries(buckets)
    .map(([label, count]) => ({
      label,
      count,
      pct: Math.round((count / total) * 100),
    }))
    .sort((a, b) => b.count - a.count);
}

function deriveRootCauses(items: Incident[]) {
  const buckets: Record<string, number> = {
    'Upstream source data issue': 0,
    'Missing / incomplete data': 0,
    'Data validation failure': 0,
    'Transformation logic error': 0,
    'Duplicate / stale data': 0,
  };
  for (const item of items) {
    const t = `${item.title || ''} ${item.description || ''}`.toLowerCase();
    if (t.includes('missing') || t.includes('incomplete') || t.includes('null'))
      buckets['Missing / incomplete data'] += 1;
    else if (t.includes('validat') || t.includes('rule') || t.includes('policy'))
      buckets['Data validation failure'] += 1;
    else if (t.includes('transform') || t.includes('logic') || t.includes('encrypt'))
      buckets['Transformation logic error'] += 1;
    else if (t.includes('duplicat') || t.includes('conflict') || t.includes('stale'))
      buckets['Duplicate / stale data'] += 1;
    else buckets['Upstream source data issue'] += 1;
  }
  const total = Math.max(items.length, 1);
  return Object.entries(buckets)
    .map(([label, count]) => ({
      label,
      count,
      pct: Math.round((count / total) * 100),
    }))
    .sort((a, b) => b.count - a.count);
}

function formatDate(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

function priorityBadgeClass(priority?: string | null) {
  const p = (priority || '').toLowerCase();
  if (p === 'critical') return 'bg-red-50 text-red-600';
  if (p === 'high') return 'bg-orange-50 text-orange-600';
  if (p === 'medium') return 'bg-amber-50 text-amber-700';
  return 'bg-sky-50 text-sky-700';
}

export function DashboardContent({ userName }: { userName?: string }) {
  const [summary, setSummary] = useState<IncidentSummary | null>(null);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(false);
  const [statusFilter, setStatusFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ limit: showAll ? '200' : '100' });
      if (statusFilter) params.set('status', statusFilter);
      if (priorityFilter) params.set('priority', priorityFilter);

      const [summaryRes, listRes] = await Promise.all([
        fetch('/api/incidents/summary', { credentials: 'include' }),
        fetch(`/api/incidents?${params.toString()}`, { credentials: 'include' }),
      ]);

      if (!summaryRes.ok) {
        throw new Error(`Summary failed (${summaryRes.status})`);
      }
      if (!listRes.ok) {
        throw new Error(`Incidents failed (${listRes.status})`);
      }

      const summaryJson = (await summaryRes.json()) as IncidentSummary;
      const listJson = (await listRes.json()) as { items?: Incident[] };
      setSummary(summaryJson);
      setIncidents(listJson.items || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load incidents');
      setSummary(null);
      setIncidents([]);
    } finally {
      setLoading(false);
    }
  }, [priorityFilter, showAll, statusFilter]);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const categories = useMemo(() => deriveCategories(incidents), [incidents]);
  const causes = useMemo(() => deriveRootCauses(incidents), [incidents]);

  const summaryCards = useMemo(
    () => [
      {
        label: 'Total Incidents',
        value: summary?.total ?? '—',
        change: 'Live from workspace.aidq.incident',
        tone: 'blue' as const,
        trend: 'up' as const,
      },
      {
        label: 'Critical',
        value: summary?.critical ?? '—',
        change: 'Current open/closed mix',
        tone: 'red' as const,
        trend: 'up' as const,
      },
      {
        label: 'High',
        value: summary?.high ?? '—',
        change: 'Current open/closed mix',
        tone: 'orange' as const,
        trend: 'up' as const,
      },
      {
        label: 'In Progress',
        value: summary?.in_progress ?? '—',
        change: 'By status',
        tone: 'amber' as const,
        trend: 'up' as const,
      },
      {
        label: 'Resolved',
        value: summary?.resolved ?? '—',
        change: 'By status',
        tone: 'green' as const,
        trend: 'down' as const,
      },
    ],
    [summary],
  );

  const priorityEntries = useMemo(() => {
    const by = summary?.by_priority || {
      Critical: summary?.critical ?? 0,
      High: summary?.high ?? 0,
      Medium: summary?.medium ?? 0,
      Low: summary?.low ?? 0,
    };
    return (['Critical', 'High', 'Medium', 'Low'] as const).map((name) => ({
      label: name,
      count: by[name] || 0,
      color: priorityColors[name],
    }));
  }, [summary]);

  const priorityTotal = Math.max(
    priorityEntries.reduce((sum, row) => sum + row.count, 0),
    1,
  );

  const donutGradient = useMemo(() => {
    let cursor = 0;
    const stops = priorityEntries.map((row) => {
      const start = cursor;
      const pct = (row.count / priorityTotal) * 100;
      cursor += pct;
      return `${row.color} ${start}% ${cursor}%`;
    });
    return `conic-gradient(${stops.join(', ')})`;
  }, [priorityEntries, priorityTotal]);

  const tableRows = showAll ? incidents : incidents.slice(0, 5);

  return (
    <main className="min-w-0 flex-1 overflow-y-auto bg-[#f5f7fb] text-[#172033]">
      <header className="sticky top-0 z-10 flex h-14 items-center border-b border-[#e3e8ef] bg-white px-5">
        <div>
          <h1 className="text-[18px] font-bold leading-5">AiDQ</h1>
          <p className="text-[10px] text-[#6e7888]">AI-Powered Data Quality</p>
        </div>
        <div className="ml-auto flex items-center gap-3">
          <button type="button" className="relative rounded-full p-2 text-[#526071] hover:bg-[#f1f4f8]" aria-label="Notifications">
            <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-[#e5484d]" />
            <span className="block size-4 rounded-full border-2 border-current" />
          </button>
          <div
            className="flex size-7 items-center justify-center rounded-full bg-[#e9edf4] text-[10px] font-semibold"
            title={userName}
          >
            {initials(userName)}
          </div>
        </div>
      </header>

      <div className="space-y-4 p-5">
        <section className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-[18px] font-semibold">
              {showAll ? 'All ServiceNow Incidents' : 'RCA / Fix Recommendation Summary'}
            </h2>
            <p className="mt-0.5 text-[11px] text-[#697586]">
              {showAll
                ? 'Live incidents from workspace.aidq.incident with status and priority filters.'
                : 'Overview of incidents, recommended fixes, and root-cause trends.'}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {!showAll && <button type="button" className="dashboard-button">Live data</button>}
            <button
              type="button"
              className="dashboard-button"
              onClick={() => setShowFilters((v) => !v)}
            >
              <Filter className="size-3.5" /> Filter
            </button>
            <button
              type="button"
              className="dashboard-icon-button"
              aria-label="Refresh"
              onClick={() => void loadData()}
              disabled={loading}
            >
              <RefreshCw className={`size-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </section>

        {showFilters && (
          <section className="flex flex-wrap gap-2 rounded-lg border border-[#e4e9f0] bg-white p-3">
            <label className="text-[10px] text-[#667386]">
              Status
              <select
                className="ml-2 rounded border border-[#d7dee8] px-2 py-1 text-[11px]"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="">All</option>
                <option value="New">New</option>
                <option value="In Progress">In Progress</option>
                <option value="Resolved">Resolved</option>
              </select>
            </label>
            <label className="text-[10px] text-[#667386]">
              Priority
              <select
                className="ml-2 rounded border border-[#d7dee8] px-2 py-1 text-[11px]"
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value)}
              >
                <option value="">All</option>
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </label>
          </section>
        )}

        {error && (
          <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-[11px] text-red-700">
            {error}
          </div>
        )}

        {!showAll && (
          <>
            <section className="grid grid-cols-2 gap-3 xl:grid-cols-5">
              {summaryCards.map((card) => (
                <article key={card.label} className="rounded-lg border border-[#e4e9f0] bg-white p-3 shadow-[0_1px_2px_rgba(17,24,39,0.03)]">
                  <div className="flex items-center gap-2">
                    <span className={`flex size-5 items-center justify-center rounded-full border text-[9px] ${toneStyles[card.tone]}`}>●</span>
                    <span className="text-[10px] font-medium text-[#647184]">{card.label}</span>
                  </div>
                  <p className="mt-2 text-[22px] font-bold tracking-tight">{loading ? '…' : card.value}</p>
                  <p className="mt-1 flex items-center gap-1 text-[9px] text-[#7b8797]">
                    {card.trend === 'down' ? <ArrowDownRight className="size-3 text-emerald-600" /> : <ArrowUpRight className="size-3 text-red-500" />}
                    {card.change}
                  </p>
                </article>
              ))}
            </section>

            <section className="grid gap-3 xl:grid-cols-3">
              <article className="dashboard-card">
                <h3 className="dashboard-card-title">Incidents by Priority</h3>
                <div className="flex h-44 items-center gap-5">
                  <div className="relative ml-2 size-28 rounded-full" style={{ background: donutGradient }}>
                    <div className="absolute inset-4 flex flex-col items-center justify-center rounded-full bg-white">
                      <strong className="text-xl">{summary?.total ?? (loading ? '…' : 0)}</strong>
                      <span className="text-[9px] text-[#7b8797]">Total</span>
                    </div>
                  </div>
                  <div className="flex-1 space-y-3 text-[10px]">
                    {priorityEntries.map((row) => (
                      <div key={row.label} className="flex items-center gap-2">
                        <span className="size-2 rounded-full" style={{ backgroundColor: row.color }} />
                        <span className="text-[#667386]">{row.label}</span>
                        <span className="ml-auto font-semibold">
                          {Math.round((row.count / priorityTotal) * 100)}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </article>

              <article className="dashboard-card">
                <h3 className="dashboard-card-title">Top Incident Categories</h3>
                <div className="mt-5 space-y-3">
                  {categories.map((row, index) => (
                    <div key={row.label} className="grid grid-cols-[130px_1fr_28px] items-center gap-2 text-[9px]">
                      <span className="truncate text-[#596678]">{row.label}</span>
                      <div className="h-1.5 overflow-hidden rounded-full bg-[#edf0f4]">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${row.pct}%`,
                            backgroundColor: categoryColors[index % categoryColors.length],
                          }}
                        />
                      </div>
                      <strong className="text-right">{row.pct}</strong>
                    </div>
                  ))}
                </div>
              </article>

              <article className="dashboard-card">
                <h3 className="dashboard-card-title">Top Root Causes</h3>
                <div className="mt-4 space-y-3">
                  {causes.map((row, index) => (
                    <div key={row.label} className="flex items-center gap-3 text-[9px]">
                      <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-[#edf2fb] font-semibold text-[#476aab]">{index + 1}</span>
                      <span className="truncate text-[#596678]">{row.label}</span>
                      <strong className="ml-auto">{row.pct}%</strong>
                    </div>
                  ))}
                </div>
              </article>
            </section>
          </>
        )}

        <section className="dashboard-card overflow-hidden p-0">
          <div className="flex items-center px-4 py-3">
            <h3 className="dashboard-card-title">
              {showAll ? 'Incidents' : 'Recent ServiceNow Incidents'}
            </h3>
            <button type="button" className="ml-auto text-[#6e7989]" aria-label="More options">
              <MoreHorizontal className="size-4" />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[650px] text-left text-[9px]">
              <thead className="border-y border-[#e8ecf1] bg-[#f8fafc] text-[#6b7788]">
                <tr>
                  {['INC Number', 'Short Description', 'Priority', 'Status', 'Assigned To', 'Created On'].map((heading) => (
                    <th key={heading} className="px-4 py-2 font-semibold">{heading}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading && (
                  <tr>
                    <td className="px-4 py-6 text-[#7a8594]" colSpan={6}>
                      Loading incidents…
                    </td>
                  </tr>
                )}
                {!loading && tableRows.length === 0 && (
                  <tr>
                    <td className="px-4 py-6 text-[#7a8594]" colSpan={6}>
                      No incidents found.
                    </td>
                  </tr>
                )}
                {!loading &&
                  tableRows.map((incident) => (
                    <tr key={incident.incident_id || `${incident.title}-${incident.created_date}`} className="border-b border-[#edf0f4] last:border-0">
                      <td className="px-4 py-2 font-semibold text-[#345d9d]">{incident.incident_id || '—'}</td>
                      <td className="max-w-[240px] truncate px-4 py-2">{incident.title || incident.description || '—'}</td>
                      <td className="px-4 py-2">
                        <span className={`rounded-full px-2 py-0.5 ${priorityBadgeClass(incident.priority)}`}>
                          {incident.priority || '—'}
                        </span>
                      </td>
                      <td className="px-4 py-2 text-[#58677a]">{incident.status || '—'}</td>
                      <td className="px-4 py-2">{incident.assigned_to || '—'}</td>
                      <td className="px-4 py-2 text-[#7a8594]">{formatDate(incident.created_date)}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
          <button
            type="button"
            className="flex items-center gap-1 px-4 py-3 text-[10px] font-semibold text-[#3866a8]"
            onClick={() => setShowAll((v) => !v)}
          >
            {showAll ? (
              <>Back to summary</>
            ) : (
              <>
                View all incidents <ChevronRight className="size-3" />
              </>
            )}
          </button>
        </section>
      </div>
    </main>
  );
}
