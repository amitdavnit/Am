import type { CSSProperties } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { AppSidebar } from '@/components/app-sidebar';
import { SidebarInset, SidebarProvider } from '@/components/ui/sidebar';
import { useSession } from '@/contexts/SessionContext';
import { PersistentChatProvider } from '@/contexts/PersistentChatContext';
import { DatabricksLogo } from '@/components/DatabricksLogo';
import { DbIcon } from '@/components/ui/db-icon';
import { UserKeyIconIcon } from '@/components/icons';
import { PersistentChatPanel } from '@/components/persistent-chat-panel';

/** Fixed chat column — same size on every page; never unmounted on nav. */
const CHAT_ASIDE_CLASS =
  'flex h-full w-full max-w-full shrink-0 flex-col overflow-hidden border-l border-[#dfe4eb] bg-white shadow-[-6px_0_18px_rgba(17,24,39,0.06)] sm:w-[min(100%,390px)] sm:max-w-[390px] xl:w-[420px] xl:max-w-[420px]';

export default function ChatLayout() {
  const { session, loading } = useSession();
  const location = useLocation();
  const isCollapsed = localStorage.getItem('sidebar:state') !== 'true';

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!session?.user) {
    return (
      <div className="flex h-screen items-center justify-center bg-secondary">
        <div className="flex flex-col items-center gap-6">
          <DatabricksLogo height={20} />
          <div className="flex w-80 flex-col items-center gap-4 rounded-md border border-border bg-background p-10 shadow-[var(--shadow-db-lg)]">
            <DbIcon icon={UserKeyIconIcon} size={32} color="muted" />
            <div className="flex flex-col items-center gap-1.5 text-center">
              <h3>Authentication Required</h3>
              <p className="text-muted-foreground">
                Please authenticate using Databricks to access this application.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const preferredUsername = session.user.preferredUsername ?? null;

  return (
    <PersistentChatProvider>
      <SidebarProvider
        defaultOpen={!isCollapsed}
        className="enterprise-shell"
        style={{ '--sidebar-width': '210px' } as CSSProperties}
      >
        <AppSidebar user={session.user} preferredUsername={preferredUsername} />
        <SidebarInset className="h-svh overflow-hidden bg-[#f5f7fb]">
          <div className="flex min-h-0 flex-1 overflow-hidden">
            {/* Page content — swaps via <Outlet />; chat stays mounted beside it */}
            <main
              key="page-pane"
              className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden"
              data-pathname={location.pathname}
            >
              <Outlet />
            </main>
            <aside key="chat-pane" className={CHAT_ASIDE_CLASS}>
              <PersistentChatPanel />
            </aside>
          </div>
        </SidebarInset>
      </SidebarProvider>
    </PersistentChatProvider>
  );
}
