import { matchPath } from 'react-router-dom';

/**
 * Soft navigation to a chat ID - updates the browser URL without triggering React Router navigation.
 *
 * This function uses window.history.replaceState to update the URL to /chat/:id
 * without causing React Router to remount components. It's called "soft" navigation
 * because it only updates the URL bar, not the application state.
 *
 * When chat history is disabled (ephemeral mode), this function does nothing,
 * keeping the user on the homepage (/) to prevent creating URLs to chats
 * that won't be persisted.
 *
 * On product pages (Incidents, Notifications, Settings, …) the URL is left
 * alone so the left pane stays put while the fixed chat panel continues the thread.
 *
 * @param chatId - The chat ID to navigate to
 * @param chatHistoryEnabled - Whether chat history persistence is enabled
 */
export function softNavigateToChatId(
  chatId: string,
  chatHistoryEnabled: boolean,
): void {
  if (!chatHistoryEnabled) {
    return;
  }

  const path = window.location.pathname;
  // Keep product pages intact — chat is a fixed side panel on every page.
  if (
    path.startsWith('/notifications') ||
    path.startsWith('/dq-health') ||
    path.startsWith('/rules') ||
    path.startsWith('/settings')
  ) {
    return;
  }

  // On home, update URL for deep-link refresh without remounting the chat shell.
  if (path === '/' || matchPath('/chat/:id', path)) {
    window.history.replaceState({}, '', `/chat/${chatId}`);
  }
}

/**
 * Extract the chat ID from the current browser pathname.
 * Useful after a soft navigation where React Router's useParams()
 * doesn't reflect the replaceState change.
 */
export function getChatIdFromPathname(): string | undefined {
  return matchPath('/chat/:id', window.location.pathname)?.params.id;
}
