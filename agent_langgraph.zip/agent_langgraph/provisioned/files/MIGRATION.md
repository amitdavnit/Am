# Migrating the AiDQ Agent to a New Databricks Workspace / Account

A repeatable runbook for deploying the AiDQ agent (`agent-langgraph`) to a brand-new,
empty Databricks workspace using the `provisioned` Lakebase flavor. It bakes in the
lessons learned during the initial migration.

The flow is driven by `scripts/bootstrap_workspace.py` (phased, idempotent,
config-driven) + a Databricks Asset Bundle (`databricks.yml`, target `provisioned`).

---

## Prerequisites (cannot be auto-created)

Before you start, the new workspace must have:

- A **Unity Catalog catalog** to hold the Delta tables (default `workspace`).
- The **LLM serving endpoint** `databricks-gpt-5-2` and **embedding endpoint**
  `databricks-gte-large-en`. Preflight only *verifies* these — it fails fast if missing.
- **Lakebase enabled / billing active** (creating a provisioned instance needs
  available credits).
- Permission to use (or create) a SQL warehouse.

---

## Step 0 — Authenticate the CLI to the new workspace

```bash
databricks auth login --host https://<new-workspace-url> --profile <profile-name>
```

## Step 1 — Edit the bootstrap config

Update these fields in `workspace.bootstrap.yaml` for the new account (copy the file
per account if you want to keep several):

```yaml
profile: <profile-name>               # from Step 0
catalog: workspace                    # UC catalog that exists in the new WS
schema: aidq
warehouse:
  name: Serverless Starter Warehouse  # existing warehouse name (or one to create)
lakebase:
  instance_name: aidq-postgres        # provisioned Lakebase instance to create
  database: databricks_postgres
experiment:
  name: /Users/<you>@<domain>/aidq-agent   # absolute path under YOUR user
endpoints:
  llm: databricks-gpt-5-2
  embedding: databricks-gte-large-en
secrets:
  servicenow_instance: https://<your-instance>.service-now.com
  servicenow_username: <user>
app_name: agent-langgraph-test-llm    # agent-* prefix; name is immutable once created
```

## Step 2 — Export the ServiceNow secret (never stored in files)

```powershell
$env:SERVICENOW_PASSWORD = "<servicenow-password>"
```

## Step 3 — Preflight (fail fast)

Verifies the LLM + embedding endpoints exist before doing any work:

```bash
uv run python scripts/bootstrap_workspace.py --config workspace.bootstrap.yaml --phase preflight
```

## Step 4 — Provision infra

Creates: MLflow experiment -> SQL warehouse (discover/create) -> **provisioned
Lakebase instance** (create + wait for AVAILABLE) -> apply Lakebase schema -> create +
seed UC Delta tables (incl. `incident`, `chat_threads`, `chat_messages`) -> load
incident history + pgvector embeddings -> secret scope + ServiceNow password.

```bash
uv run python scripts/bootstrap_workspace.py --config workspace.bootstrap.yaml --phase infra
```

> If the embedding endpoint hits `REQUEST_LIMIT_EXCEEDED`, throttle the batch: set
> `$env:EMBED_BATCH_SIZE=4; $env:EMBED_BATCH_DELAY_SECONDS=2` and re-run this phase.

When it finishes, it **prints the exact deploy + run commands** with the resolved
`--var` flags. Copy them.

## Step 5 — Deploy AND run (pass the SAME `--var` flags to BOTH)

**Critical:** `bundle run` re-renders the app's deployment env, so it needs the
**identical** `--var` flags as `bundle deploy`. Omitting them makes
`lakebase_instance_name` empty -> the deployment fails with
*"Must specify environment variable source using either `value` or `valueFrom`."*

```bash
databricks bundle deploy --profile <profile> -t provisioned \
  --var="warehouse_id=<id>" --var="experiment_id=<id>" --var="app_name=agent-langgraph-test-llm" \
  --var="lakebase_instance_name=aidq-postgres" --var="lakebase_database=databricks_postgres"

databricks bundle run agent_langgraph --profile <profile> -t provisioned \
  --var="warehouse_id=<id>" --var="experiment_id=<id>" --var="app_name=agent-langgraph-test-llm" \
  --var="lakebase_instance_name=aidq-postgres" --var="lakebase_database=databricks_postgres"
```

Use `-t provisioned` (the target that swaps the app to the `database` Lakebase
resource + `LAKEBASE_INSTANCE_NAME`). Wait for `App started successfully`.

## Step 6 — Postdeploy grants

Grants the app's service principal access to the Lakebase schemas/tables:

```bash
uv run python scripts/bootstrap_workspace.py --config workspace.bootstrap.yaml --phase postdeploy
```

> Warnings about `checkpoint_*` / `store_*` / `agent_server` tables "not existing"
> are **expected** on a fresh instance — they're created on first agent use. Re-run
> `--phase postdeploy` once after the first conversation to grant those.

## Step 7 — Verify

```bash
databricks apps get agent-langgraph-test-llm --profile <profile> --output json
# expect: app_status.state = RUNNING, compute_status.state = ACTIVE
```

Then open the app URL from that output.

---

## Autoscaling vs. Provisioned Lakebase

`databricks.yml` supports both flavors via bundle variables:

- **Default (`dev`/`prod`) target** = Lakebase **Autoscaling** (`postgres` app resource
  + `LAKEBASE_AUTOSCALING_*` env). Reads the host from the `postgres` resource via
  `value_from`.
- **`provisioned` target** = Lakebase **Provisioned** instance (`database` app resource
  + `LAKEBASE_INSTANCE_NAME`; host/credentials auto-injected by Databricks Apps).

New workspaces in this runbook use `-t provisioned`.

---

## Gotchas baked in (already fixed — just be aware)

- **No `app.yaml`** — `databricks.yml` `config` is the single source of truth. Don't
  re-add a competing `app.yaml`; its env would shadow/duplicate the bundle config.
- **No `valueFrom` in the bundle `config.env`** — the app *deployments* API rejects it
  (DAB sends `value_from` verbatim). IDs are passed as literal `value: ${var...}`
  (e.g. `MLFLOW_EXPERIMENT_ID`), while the app resource still grants access.
- **Every env entry needs a non-empty source** — DAB drops empty `value: ""` fields,
  leaving an entry with no source. The three Lakebase env slots
  (`lakebase_env_1/2/3`) always carry a real value in both targets.
- **`bundle run` needs the `--var` flags too** — see Step 5.
- **CLI**: v1.6.0 is used automatically even though v0.18.0 is on PATH (that PATH
  warning is harmless).
- **App name is immutable** — changing `app_name` forces a destroy + recreate of the app.

---

## Phase reference

| Phase        | What it does                                                        |
|--------------|---------------------------------------------------------------------|
| `preflight`  | Verify LLM + embedding serving endpoints exist (fail fast).         |
| `infra`      | Experiment, warehouse, Lakebase instance + schema, UC tables, seed data, embeddings, secrets. Prints deploy/run commands. |
| `postdeploy` | Grant the deployed app's service principal Lakebase access.         |
| `all`        | Run `preflight` + `infra` (deploy/run + `postdeploy` are manual).   |
