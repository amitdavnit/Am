"""Create AiDQ Unity Catalog tables and migrate legacy local data files."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv

from agent_server.knowledge.uc_tables import merge_dataframe
from api.services.databricks_sql import DatabricksSqlError, execute_sql

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"


DDL = [
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.outfile (
      ENGINE_SERIAL_NUM BIGINT,
      PROGRAM_PAYMENT_CODE DOUBLE,
      PROGRAM_ACCOUNT_CODE DOUBLE,
      ENGINE_SYSTEM_CODE DOUBLE,
      ENGINE_COMPONENT_CODE DOUBLE,
      REASON_CODE STRING
    ) USING DELTA
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.outfile_backups (
      snapshot_id STRING,
      snapshot_at TIMESTAMP,
      ENGINE_SERIAL_NUM BIGINT,
      PROGRAM_PAYMENT_CODE DOUBLE,
      PROGRAM_ACCOUNT_CODE DOUBLE,
      ENGINE_SYSTEM_CODE DOUBLE,
      ENGINE_COMPONENT_CODE DOUBLE,
      REASON_CODE STRING
    ) USING DELTA
    """,
    # Isolated copy used by the enhanced app. Same shape as `outfile` plus
    # ingestion-tracking columns so the reprocess guard can tell batches apart.
    # Kept separate from `workspace.aidq.outfile` so other apps are unaffected.
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.outfile_modified (
      ENGINE_SERIAL_NUM BIGINT,
      PROGRAM_PAYMENT_CODE DOUBLE,
      PROGRAM_ACCOUNT_CODE DOUBLE,
      ENGINE_SYSTEM_CODE DOUBLE,
      ENGINE_COMPONENT_CODE DOUBLE,
      REASON_CODE STRING,
      INGESTION_ID STRING,
      LOADED_AT TIMESTAMP
    ) USING DELTA
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.outfile_modified_backups (
      snapshot_id STRING,
      snapshot_at TIMESTAMP,
      ENGINE_SERIAL_NUM BIGINT,
      PROGRAM_PAYMENT_CODE DOUBLE,
      PROGRAM_ACCOUNT_CODE DOUBLE,
      ENGINE_SYSTEM_CODE DOUBLE,
      ENGINE_COMPONENT_CODE DOUBLE,
      REASON_CODE STRING,
      INGESTION_ID STRING,
      LOADED_AT TIMESTAMP
    ) USING DELTA
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.processing_audit_log (
      audit_id STRING,
      source_identifier STRING,
      source_type STRING,
      source_version STRING,
      processed_date DATE,
      processed_at TIMESTAMP,
      processed_by STRING,
      thread_id STRING,
      status STRING,
      row_count BIGINT,
      bucket_count BIGINT,
      tickets_created BIGINT
    ) USING DELTA
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.source_reference (
      ENGINE_SERIAL_NUM BIGINT,
      PROGRAM_PAYMENT_CODE DOUBLE,
      PROGRAM_ACCOUNT_CODE DOUBLE,
      ENGINE_SYSTEM_CODE DOUBLE,
      ENGINE_COMPONENT_CODE DOUBLE
    ) USING DELTA
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.incident_history (
      incident_number STRING,
      category STRING,
      short_description STRING,
      long_description STRING,
      work_notes STRING,
      resolution_notes STRING,
      state STRING,
      created_date STRING,
      resolved_date STRING
    ) USING DELTA
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.servicenow_incidents (
      ticket_id STRING,
      category STRING,
      short_description STRING,
      description STRING,
      assignment_group STRING,
      priority STRING,
      state STRING,
      RCA STRING,
      Resolution STRING
    ) USING DELTA
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.feedback_events (
      feedback_id STRING,
      conversation_id STRING,
      message_id STRING,
      user_id STRING,
      display_name STRING,
      rating STRING,
      comment STRING,
      question STRING,
      answer_excerpt STRING,
      workflow STRING,
      agent_name STRING,
      event_type STRING,
      timestamp TIMESTAMP
    ) USING DELTA
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.remediation_knowledge (
      knowledge_id STRING,
      sop_id STRING,
      title STRING,
      reason_code STRING,
      validated_columns_json STRING,
      lookup_table STRING,
      lookup_key STRING,
      resolution_markdown STRING,
      source_incident STRING,
      evidence_json STRING,
      status STRING,
      outcome STRING,
      user_confirmation STRING,
      created_at TIMESTAMP,
      updated_at TIMESTAMP
    ) USING DELTA
    """,
    # UC fallback tables. The app uses Lakebase for incidents + chat by default
    # (INCIDENT_TABLE / CHAT_STORE=uc are emergency fallbacks), but databricks.yml
    # declares these as app UC-securable resources, so they must exist at deploy.
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.incident (
      incident_id STRING,
      violation_id STRING,
      title STRING,
      description STRING,
      priority STRING,
      status STRING,
      assigned_to STRING,
      created_date STRING,
      closed_date STRING
    ) USING DELTA
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.chat_threads (
      thread_id STRING,
      user_id STRING,
      title STRING,
      created_at TIMESTAMP,
      updated_at TIMESTAMP
    ) USING DELTA
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace.aidq.chat_messages (
      message_id STRING,
      thread_id STRING,
      role STRING,
      content STRING,
      parts_json STRING,
      attachments_json STRING,
      trace_id STRING,
      created_at TIMESTAMP
    ) USING DELTA
    """,
]


def _table_exists(table: str) -> bool:
    try:
        execute_sql(f"DESCRIBE TABLE {table}")
        return True
    except DatabricksSqlError:
        return False


def _migrate_csv(filename: str, table: str, key: str) -> None:
    frame = pd.read_csv(DATA / filename)
    merge_dataframe(table, frame, key=key)
    print(f"Migrated {len(frame)} rows: {filename} -> {table}")


def _migrate_outfile_modified(filename: str = "outfile.csv") -> None:
    """Load the outfile CSV into workspace.aidq.outfile_modified, stamping every
    row with a fresh INGESTION_ID + LOADED_AT. Each run is a NEW ingestion batch,
    which is what unblocks reprocessing in the reprocess guard: edit the CSV and
    rerun this to make the pipeline process the data again."""
    frame = pd.read_csv(DATA / filename)
    frame["INGESTION_ID"] = str(uuid.uuid4())
    frame["LOADED_AT"] = datetime.now(timezone.utc).replace(tzinfo=None)
    merge_dataframe(
        "workspace.aidq.outfile_modified", frame, key="ENGINE_SERIAL_NUM"
    )
    print(
        f"Migrated {len(frame)} rows: {filename} -> workspace.aidq.outfile_modified "
        f"(INGESTION_ID={frame['INGESTION_ID'].iloc[0] if len(frame) else 'n/a'})"
    )


def _feedback_frame() -> pd.DataFrame:
    rows: list[dict] = []
    source = DATA / "feedback_events.jsonl"
    if not source.exists():
        return pd.DataFrame()
    for line in source.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        event = json.loads(line)
        payload = event.get("payload") or {}
        rows.append(
            {
                "feedback_id": str(uuid.uuid5(uuid.NAMESPACE_URL, line)),
                "conversation_id": event.get("conversation_id"),
                "message_id": payload.get("message_id"),
                "user_id": payload.get("user_id"),
                "display_name": payload.get("display_name"),
                "rating": payload.get("rating"),
                "comment": payload.get("comment"),
                "question": payload.get("question"),
                "answer_excerpt": payload.get("answer_excerpt"),
                "workflow": event.get("workflow"),
                "agent_name": event.get("agent_name"),
                "event_type": event.get("event_type"),
                "timestamp": event.get("timestamp"),
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    load_dotenv(ROOT / ".env", override=False)
    execute_sql("CREATE SCHEMA IF NOT EXISTS workspace.aidq")
    for statement in DDL:
        execute_sql(statement)

    # chat_threads / chat_messages are created by the app on first use. Only an
    # existing deployment needs these newer columns back-filled; on a fresh
    # workspace the table doesn't exist yet, so there is nothing to migrate.
    if _table_exists("workspace.aidq.chat_messages"):
        existing = execute_sql("DESCRIBE TABLE workspace.aidq.chat_messages")
        have = {str(row.get("col_name")) for row in existing}
        for column, data_type in [
            ("parts_json", "STRING"),
            ("attachments_json", "STRING"),
            ("trace_id", "STRING"),
        ]:
            if column not in have:
                execute_sql(
                    f"ALTER TABLE workspace.aidq.chat_messages "
                    f"ADD COLUMNS (`{column}` {data_type})"
                )

    _migrate_csv("outfile.csv", "workspace.aidq.outfile", "ENGINE_SERIAL_NUM")
    _migrate_outfile_modified("outfile.csv")
    _migrate_csv(
        "source_reference.csv",
        "workspace.aidq.source_reference",
        "ENGINE_SERIAL_NUM",
    )
    _migrate_csv(
        "incidents_master.csv",
        "workspace.aidq.incident_history",
        "incident_number",
    )
    _migrate_csv(
        "snow_dump.csv",
        "workspace.aidq.servicenow_incidents",
        "ticket_id",
    )

    feedback = _feedback_frame()
    if not feedback.empty:
        merge_dataframe(
            "workspace.aidq.feedback_events",
            feedback,
            key="feedback_id",
        )
        print(
            f"Migrated {len(feedback)} feedback events -> "
            "workspace.aidq.feedback_events"
        )


if __name__ == "__main__":
    main()
