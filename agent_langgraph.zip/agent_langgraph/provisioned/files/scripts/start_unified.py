# #!/usr/bin/env python3
# """Run React UI + FastAPI/LangGraph agent in one Databricks App process tree.

# Public ingress (DATABRICKS_APP_PORT / PORT) is the Node chat UI.
# The FastAPI agent listens on an internal port; the UI talks to it via
# API_PROXY and AGENT_APP_BASE_URL on localhost.
# """

# from __future__ import annotations

# import os
# import signal
# import subprocess
# import sys
# import time
# import urllib.error
# import urllib.request
# from pathlib import Path

# ROOT = Path(__file__).resolve().parent.parent
# UI_DIR = ROOT / "e2e-chatbot-app-next"
# DEFAULT_AGENT_PORT = 8001


# def _public_port() -> str:
#     return (
#         os.environ.get("DATABRICKS_APP_PORT")
#         or os.environ.get("PORT")
#         or "8000"
#     )


# def _agent_port() -> int:
#     raw = os.environ.get("AGENT_INTERNAL_PORT", str(DEFAULT_AGENT_PORT))
#     return int(raw)


# def _wait_for_agent(url: str, timeout_s: float = 120.0) -> None:
#     deadline = time.time() + timeout_s
#     last_error = "not started"
#     while time.time() < deadline:
#         try:
#             with urllib.request.urlopen(url, timeout=2) as resp:
#                 if 200 <= resp.status < 500:
#                     return
#         except (urllib.error.URLError, TimeoutError) as exc:
#             last_error = str(exc)
#         time.sleep(1)
#     raise RuntimeError(f"Agent did not become ready at {url}: {last_error}")


# def main() -> None:
#     if not UI_DIR.is_dir():
#         raise SystemExit(f"UI directory not found: {UI_DIR}")

#     agent_port = _agent_port()
#     public_port = _public_port()
#     agent_base = f"http://127.0.0.1:{agent_port}"

#     children: list[subprocess.Popen] = []

#     def _shutdown(signum=None, frame=None) -> None:  # noqa: ARG001
#         for child in reversed(children):
#             if child.poll() is None:
#                 child.terminate()
#         for child in reversed(children):
#             try:
#                 child.wait(timeout=10)
#             except subprocess.TimeoutExpired:
#                 child.kill()
#         raise SystemExit(0)

#     signal.signal(signal.SIGTERM, _shutdown)
#     signal.signal(signal.SIGINT, _shutdown)

#     agent_cmd = [
#         "uv",
#         "run",
#         "start-server",
#         "--port",
#         str(agent_port),
#     ]
#     print(f"[unified] starting agent: {' '.join(agent_cmd)}", flush=True)
#     agent_proc = subprocess.Popen(agent_cmd, cwd=str(ROOT))
#     children.append(agent_proc)

#     _wait_for_agent(f"{agent_base}/api/v1/health")
#     print(f"[unified] agent ready on {agent_base}", flush=True)

#     ui_env = os.environ.copy()
#     ui_env["NODE_ENV"] = "production"
#     ui_env["PORT"] = str(public_port)
#     ui_env["CHAT_APP_PORT"] = str(public_port)
#     ui_env["API_PROXY"] = f"{agent_base}/invocations"
#     ui_env["AGENT_APP_BASE_URL"] = agent_base
#     # Avoid nested npm builds at runtime when Databricks already ran npm run build.
#     ui_env.setdefault("CHAT_GREETING", "How can I help with your data quality operations?")

#     ui_cmd = ["npm", "run", "start", "--prefix", str(UI_DIR)]
#     print(
#         f"[unified] starting UI on port {public_port}; "
#         f"API_PROXY={ui_env['API_PROXY']}",
#         flush=True,
#     )
#     ui_proc = subprocess.Popen(ui_cmd, cwd=str(ROOT), env=ui_env)
#     children.append(ui_proc)

#     while True:
#         for child in children:
#             code = child.poll()
#             if code is not None:
#                 print(
#                     f"[unified] child exited with code {code}; shutting down",
#                     flush=True,
#                 )
#                 _shutdown()
#         time.sleep(1)


# if __name__ == "__main__":
#     main()

#!/usr/bin/env python3
"""Run React UI + FastAPI/LangGraph agent in one Databricks App process tree.

Public ingress (DATABRICKS_APP_PORT / PORT) is the Node chat UI.
The FastAPI agent listens on an internal port; the UI talks to it via
API_PROXY and AGENT_APP_BASE_URL on localhost.
"""

from __future__ import annotations

import os
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UI_DIR = ROOT / "e2e-chatbot-app-next"
DEFAULT_AGENT_PORT = 8001


def _public_port() -> str:
    return (
        os.environ.get("DATABRICKS_APP_PORT")
        or os.environ.get("PORT")
        or "8000"
    )


def _agent_port() -> int:
    raw = os.environ.get("AGENT_INTERNAL_PORT", str(DEFAULT_AGENT_PORT))
    return int(raw)


def _resolve_cmd(name: str) -> str:
    """Resolve an executable on PATH (handles npm.cmd / uv.exe on Windows).

    On Windows, shutil.which('npm') often returns the extensionless shim, which
    CreateProcess cannot launch. Prefer the .cmd/.exe form when present.
    """
    if os.name == "nt":
        for candidate in (f"{name}.cmd", f"{name}.exe", name):
            path = shutil.which(candidate)
            if path:
                return path
    else:
        path = shutil.which(name)
        if path:
            return path
    raise SystemExit(
        f"{name} not found on PATH. Install it and retry "
        f"(on Windows, ensure the .cmd/.exe is available)."
    )


def _wait_for_agent(url: str, timeout_s: float = 120.0) -> None:
    deadline = time.time() + timeout_s
    last_error = "not started"
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as resp:
                if 200 <= resp.status < 500:
                    return
        except (urllib.error.URLError, TimeoutError) as exc:
            last_error = str(exc)
        time.sleep(1)
    raise RuntimeError(f"Agent did not become ready at {url}: {last_error}")


def main() -> None:
    if not UI_DIR.is_dir():
        raise SystemExit(f"UI directory not found: {UI_DIR}")

    agent_port = _agent_port()
    public_port = _public_port()
    agent_base = f"http://127.0.0.1:{agent_port}"

    children: list[subprocess.Popen] = []

    def _shutdown(signum=None, frame=None) -> None:  # noqa: ARG001
        for child in reversed(children):
            if child.poll() is None:
                child.terminate()
        for child in reversed(children):
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
        raise SystemExit(0)

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    agent_cmd = [
        _resolve_cmd("uv"),
        "run",
        "start-server",
        "--port",
        str(agent_port),
    ]
    print(f"[unified] starting agent: {' '.join(agent_cmd)}", flush=True)
    agent_proc = subprocess.Popen(agent_cmd, cwd=str(ROOT))
    children.append(agent_proc)

    _wait_for_agent(f"{agent_base}/api/v1/health")
    print(f"[unified] agent ready on {agent_base}", flush=True)

    ui_env = os.environ.copy()
    ui_env["NODE_ENV"] = "production"
    ui_env["PORT"] = str(public_port)
    ui_env["CHAT_APP_PORT"] = str(public_port)
    ui_env["API_PROXY"] = f"{agent_base}/invocations"
    ui_env["AGENT_APP_BASE_URL"] = agent_base
    # Avoid nested npm builds at runtime when Databricks already ran npm run build.
    ui_env.setdefault("CHAT_GREETING", "How can I help with your data quality operations?")

    ui_cmd = [_resolve_cmd("npm"), "run", "start", "--prefix", str(UI_DIR)]
    print(
        f"[unified] starting UI on port {public_port}; "
        f"API_PROXY={ui_env['API_PROXY']}",
        flush=True,
    )
    ui_proc = subprocess.Popen(ui_cmd, cwd=str(ROOT), env=ui_env)
    children.append(ui_proc)

    while True:
        for child in children:
            code = child.poll()
            if code is not None:
                print(
                    f"[unified] child exited with code {code}; shutting down",
                    flush=True,
                )
                _shutdown()
        time.sleep(1)


if __name__ == "__main__":
    main()
 