"""One-time migration: Unity Catalog Delta → Lakebase Postgres for app state.

Migrates:
  - workspace.aidq.chat_threads / chat_messages  → aidq.chat_*
  - workspace.aidq.incident                      → aidq.incidents
  - workspace.aidq.incident_history              → aidq.incident_history (+ optional embeddings)
  - workspace.aidq.feedback_events               → aidq.feedback_events

Does NOT migrate outfile / source_reference / remediation_knowledge (DQ pipeline stays on UC).

Usage:
    uv run python scripts/migrate_uc_to_lakebase.py
    uv run python scripts/migrate_uc_to_lakebase.py --with-embeddings
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env", override=True)


def _uc_rows(sql: str) -> list[dict[str, Any]]:
    from api.services.databricks_sql import execute_sql

    return execute_sql(sql)


def _norm(row: dict[str, Any]) -> dict[str, Any]:
    return {str(k).lower(): v for k, v in row.items()}


def migrate_chat() -> tuple[int, int]:
    from agent_server.platform.lakebase import AIDQ_SCHEMA, execute

    threads = _uc_rows(
        "SELECT thread_id, user_id, title, created_at, updated_at "
        "FROM workspace.aidq.chat_threads"
    )
    for row in threads:
        r = _norm(row)
        execute(
            f"""
            INSERT INTO {AIDQ_SCHEMA}.chat_threads
                (thread_id, user_id, title, created_at, updated_at)
            VALUES (
                %(thread_id)s, %(user_id)s, %(title)s,
                COALESCE(%(created_at)s::timestamptz, NOW()),
                COALESCE(%(updated_at)s::timestamptz, NOW())
            )
            ON CONFLICT (thread_id) DO UPDATE SET
                user_id = EXCLUDED.user_id,
                title = EXCLUDED.title,
                updated_at = EXCLUDED.updated_at
            """,
            {
                "thread_id": r.get("thread_id"),
                "user_id": r.get("user_id"),
                "title": r.get("title") or "New chat",
                "created_at": str(r.get("created_at")) if r.get("created_at") else None,
                "updated_at": str(r.get("updated_at")) if r.get("updated_at") else None,
            },
            fetch=False,
        )

    messages = _uc_rows(
        "SELECT message_id, thread_id, role, content, parts_json, "
        "attachments_json, trace_id, created_at "
        "FROM workspace.aidq.chat_messages"
    )
    for row in messages:
        r = _norm(row)
        parts = r.get("parts_json")
        atts = r.get("attachments_json")
        if parts is not None and not isinstance(parts, str):
            parts = json.dumps(parts)
        if atts is not None and not isinstance(atts, str):
            atts = json.dumps(atts)
        execute(
            f"""
            INSERT INTO {AIDQ_SCHEMA}.chat_messages (
                message_id, thread_id, role, content, parts_json,
                attachments_json, trace_id, created_at
            ) VALUES (
                %(message_id)s, %(thread_id)s, %(role)s, %(content)s,
                %(parts_json)s::jsonb, COALESCE(%(attachments_json)s::jsonb, '[]'::jsonb),
                %(trace_id)s, COALESCE(%(created_at)s::timestamptz, NOW())
            )
            ON CONFLICT (message_id) DO UPDATE SET
                content = EXCLUDED.content,
                parts_json = EXCLUDED.parts_json,
                attachments_json = EXCLUDED.attachments_json,
                trace_id = COALESCE(EXCLUDED.trace_id, {AIDQ_SCHEMA}.chat_messages.trace_id)
            """,
            {
                "message_id": r.get("message_id"),
                "thread_id": r.get("thread_id"),
                "role": r.get("role"),
                "content": r.get("content") or "",
                "parts_json": parts,
                "attachments_json": atts or "[]",
                "trace_id": r.get("trace_id"),
                "created_at": str(r.get("created_at")) if r.get("created_at") else None,
            },
            fetch=False,
        )
    return len(threads), len(messages)


def migrate_incidents() -> int:
    from agent_server.platform.lakebase import AIDQ_SCHEMA, execute

    rows = _uc_rows(
        "SELECT Incident_ID, Violation_ID, Title, Description, Priority, Status, "
        "Assigned_To, Created_Date, Closed_Date FROM workspace.aidq.incident"
    )
    for row in rows:
        r = _norm(row)
        execute(
            f"""
            INSERT INTO {AIDQ_SCHEMA}.incidents (
                incident_id, violation_id, title, description, priority, status,
                assigned_to, created_date, closed_date, updated_at
            ) VALUES (
                %(incident_id)s, %(violation_id)s, %(title)s, %(description)s,
                %(priority)s, %(status)s, %(assigned_to)s,
                %(created_date)s::timestamptz, %(closed_date)s::timestamptz, NOW()
            )
            ON CONFLICT (incident_id) DO UPDATE SET
                violation_id = EXCLUDED.violation_id,
                title = EXCLUDED.title,
                description = EXCLUDED.description,
                priority = EXCLUDED.priority,
                status = EXCLUDED.status,
                assigned_to = EXCLUDED.assigned_to,
                created_date = COALESCE(EXCLUDED.created_date, {AIDQ_SCHEMA}.incidents.created_date),
                closed_date = EXCLUDED.closed_date,
                updated_at = NOW()
            """,
            {
                "incident_id": r.get("incident_id"),
                "violation_id": r.get("violation_id"),
                "title": r.get("title"),
                "description": r.get("description"),
                "priority": r.get("priority"),
                "status": r.get("status"),
                "assigned_to": r.get("assigned_to"),
                "created_date": str(r["created_date"]) if r.get("created_date") else None,
                "closed_date": str(r["closed_date"]) if r.get("closed_date") else None,
            },
            fetch=False,
        )
    return len(rows)


def migrate_incident_history(*, with_embeddings: bool) -> int:
    from agent_server.platform.lakebase import AIDQ_SCHEMA, execute
    from agent_server.platform.pgvector_store import (
        documents_from_history_rows,
        upsert_incident_documents,
    )

    rows = _uc_rows("SELECT * FROM workspace.aidq.incident_history")
    normalized = [_norm(r) for r in rows]
    for r in normalized:
        execute(
            f"""
            INSERT INTO {AIDQ_SCHEMA}.incident_history (
                incident_number, category, short_description, long_description,
                work_notes, resolution_notes, state, created_date, resolved_date, updated_at
            ) VALUES (
                %(incident_number)s, %(category)s, %(short_description)s,
                %(long_description)s, %(work_notes)s, %(resolution_notes)s,
                %(state)s, %(created_date)s, %(resolved_date)s, NOW()
            )
            ON CONFLICT (incident_number) DO UPDATE SET
                category = EXCLUDED.category,
                short_description = EXCLUDED.short_description,
                long_description = EXCLUDED.long_description,
                work_notes = EXCLUDED.work_notes,
                resolution_notes = EXCLUDED.resolution_notes,
                state = EXCLUDED.state,
                created_date = EXCLUDED.created_date,
                resolved_date = EXCLUDED.resolved_date,
                updated_at = NOW()
            """,
            {
                "incident_number": r.get("incident_number"),
                "category": r.get("category"),
                "short_description": r.get("short_description"),
                "long_description": r.get("long_description"),
                "work_notes": r.get("work_notes"),
                "resolution_notes": r.get("resolution_notes"),
                "state": r.get("state"),
                "created_date": str(r.get("created_date") or ""),
                "resolved_date": str(r.get("resolved_date") or ""),
            },
            fetch=False,
        )
    if with_embeddings and normalized:
        docs = documents_from_history_rows(normalized)
        upsert_incident_documents(docs)
    return len(normalized)


def migrate_feedback() -> int:
    from agent_server.platform.lakebase import AIDQ_SCHEMA, execute

    try:
        rows = _uc_rows(
            "SELECT feedback_id, conversation_id, message_id, user_id, display_name, "
            "rating, comment, question, answer_excerpt, workflow, agent_name, "
            "event_type, timestamp FROM workspace.aidq.feedback_events"
        )
    except Exception as exc:
        print(f"  feedback skipped: {exc}")
        return 0
    for row in rows:
        r = _norm(row)
        execute(
            f"""
            INSERT INTO {AIDQ_SCHEMA}.feedback_events (
                feedback_id, conversation_id, message_id, user_id, display_name,
                rating, comment, question, answer_excerpt, workflow, agent_name,
                event_type, timestamp
            ) VALUES (
                %(feedback_id)s, %(conversation_id)s, %(message_id)s, %(user_id)s,
                %(display_name)s, %(rating)s, %(comment)s, %(question)s,
                %(answer_excerpt)s, %(workflow)s, %(agent_name)s, %(event_type)s,
                COALESCE(%(timestamp)s::timestamptz, NOW())
            )
            ON CONFLICT (feedback_id) DO NOTHING
            """,
            {
                "feedback_id": r.get("feedback_id"),
                "conversation_id": r.get("conversation_id"),
                "message_id": r.get("message_id"),
                "user_id": r.get("user_id"),
                "display_name": r.get("display_name"),
                "rating": r.get("rating"),
                "comment": r.get("comment"),
                "question": r.get("question"),
                "answer_excerpt": r.get("answer_excerpt"),
                "workflow": r.get("workflow"),
                "agent_name": r.get("agent_name"),
                "event_type": r.get("event_type"),
                "timestamp": str(r.get("timestamp")) if r.get("timestamp") else None,
            },
            fetch=False,
        )
    return len(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Migrate UC Delta app state → Lakebase")
    parser.add_argument(
        "--with-embeddings",
        action="store_true",
        help="Also embed incident_history into pgvector",
    )
    args = parser.parse_args()

    from agent_server.platform.lakebase import lakebase_configured

    if not lakebase_configured():
        print("ERROR: Lakebase not configured (PGHOST/POSTGRES_URL).")
        return 1

    print("Migrating chat threads/messages...")
    try:
        n_t, n_m = migrate_chat()
        print(f"  threads={n_t} messages={n_m}")
    except Exception as exc:
        print(f"  chat skipped/failed: {exc}")

    print("Migrating operational incidents...")
    try:
        n = migrate_incidents()
        print(f"  incidents={n}")
    except Exception as exc:
        print(f"  incidents skipped/failed: {exc}")

    print("Migrating incident_history...")
    try:
        n = migrate_incident_history(with_embeddings=args.with_embeddings)
        print(f"  incident_history={n} embeddings={args.with_embeddings}")
    except Exception as exc:
        print(f"  incident_history skipped/failed: {exc}")

    print("Migrating feedback...")
    try:
        n = migrate_feedback()
        print(f"  feedback={n}")
    except Exception as exc:
        print(f"  feedback skipped/failed: {exc}")

    print("Done.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
