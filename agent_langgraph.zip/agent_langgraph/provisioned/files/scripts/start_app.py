#!/usr/bin/env python3
"""
Start the AiDQ agent server (FastAPI: /invocations + /api/v1).

The React AiDQ UI lives in ./e2e-chatbot-app-next and is deployed as its own
Databricks App. Point AGENT_APP_BASE_URL / API_PROXY at this server.

Usage:
    start-app [OPTIONS]

All options are passed through to the backend server (start-server).
See 'uv run start-server --help' for available options.
"""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        description="Start AiDQ agent API (no embedded HTML UI)",
        usage="%(prog)s [OPTIONS]\n\nAll options are passed through to start-server. "
        "Use 'uv run start-server --help' for available options.",
    )
    parser.add_argument(
        "--no-ui",
        action="store_true",
        help="Deprecated no-op (HTML UI removed; use the React app).",
    )
    _, backend_args = parser.parse_known_args()

    from agent_server.start_server import main as start_server_main

    sys.argv = ["start-server", *backend_args]
    start_server_main()


if __name__ == "__main__":
    main()
