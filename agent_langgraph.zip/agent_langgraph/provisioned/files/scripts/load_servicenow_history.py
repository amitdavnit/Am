"""One-time (or incremental) load of ServiceNow / incident history into Lakebase + pgvector.

Sources (first available wins):
  1. --csv path
  2. Unity Catalog table (INCIDENT_HISTORY_TABLE / workspace.aidq.incident_history)
  3. Local data/incidents_master.csv

Usage:
    uv run python scripts/load_servicenow_history.py
    uv run python scripts/load_servicenow_history.py --csv data/incidents_master.csv
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent


def _load_frame(csv_path: str | None) -> pd.DataFrame:
    if csv_path:
        path = Path(csv_path)
        if not path.exists():
            raise FileNotFoundError(path)
        return pd.read_csv(path)

    # Prefer UC table via existing repository
    try:
        from agent_server.knowledge.snow_dump_repository import load_snow_dump

        df = load_snow_dump()
        if not df.empty:
            return df
    except Exception as exc:
        print(f"UC load skipped: {exc}")

    fallback = ROOT / "data" / "incidents_master.csv"
    if fallback.exists():
        return pd.read_csv(fallback)
    raise RuntimeError(
        "No incident history source found. Pass --csv or ensure UC table / data/incidents_master.csv exists."
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Load incident history into Lakebase pgvector")
    parser.add_argument("--csv", help="Path to incidents CSV export")
    parser.add_argument("--limit", type=int, default=0, help="Optional row cap for smoke tests")
    args = parser.parse_args()

    from agent_server.platform.lakebase import lakebase_configured
    from agent_server.platform.pgvector_store import (
        documents_from_history_rows,
        upsert_incident_documents,
    )

    if not lakebase_configured():
        print(
            "ERROR: Lakebase not configured. Set POSTGRES_URL or PGHOST+PGDATABASE first."
        )
        return 1

    df = _load_frame(args.csv)
    if args.limit and args.limit > 0:
        df = df.head(args.limit)

    required = ["incident_number"]
    for col in required:
        if col not in df.columns:
            print(f"ERROR: CSV/table missing required column: {col}")
            return 1

    rows = df.fillna("").to_dict(orient="records")
    docs = documents_from_history_rows(rows)
    print(f"Embedding and upserting {len(docs)} incident(s)...")
    n = upsert_incident_documents(docs)
    print(f"Done. Upserted {n} incident embedding(s) into aidq.incident_embeddings.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
