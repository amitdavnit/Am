"""One-shot, idempotent bootstrap for a fresh Databricks workspace/account.

Provisions every prerequisite the AiDQ agent needs, then leaves the workspace
ready for `databricks bundle deploy`. Re-runnable (discover-or-create) and
reusable per account via a config file.

Phases:
  preflight  — verify LLM + embedding serving endpoints exist; check auth.
  infra      — experiment, SQL warehouse, Lakebase instance (+schema),
               UC tables (+seed data), incident history (+pgvector),
               ServiceNow secret. Writes resolved IDs to bootstrap.output.json.
  postdeploy — grant the deployed app's service principal Lakebase access.
  all        — preflight + infra (run BEFORE bundle deploy).

Usage:
    uv run python scripts/bootstrap_workspace.py --config workspace.bootstrap.yaml --phase all
    # ... then (provisioned Lakebase target — bootstrap prints the exact vars):
    #   databricks bundle deploy --profile <p> -t provisioned --var="lakebase_instance_name=..." ...
    #   databricks bundle run agent_langgraph --profile <p> -t provisioned
    uv run python scripts/bootstrap_workspace.py --config workspace.bootstrap.yaml --phase postdeploy

The ServiceNow password is read from the env var named in the config
(secrets.servicenow_password_env); it is never stored in the config file.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
OUTPUT_PATH = ROOT / "bootstrap.output.json"


# --------------------------------------------------------------------------- #
# Config                                                                       #
# --------------------------------------------------------------------------- #
@dataclass
class BootstrapConfig:
    profile: str
    catalog: str
    schema: str
    warehouse: dict[str, Any]
    lakebase: dict[str, Any]
    experiment: dict[str, Any]
    endpoints: dict[str, Any]
    secrets: dict[str, Any]
    app_name: str
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def load(cls, path: Path) -> "BootstrapConfig":
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        required = [
            "profile",
            "catalog",
            "schema",
            "warehouse",
            "lakebase",
            "experiment",
            "endpoints",
            "secrets",
            "app_name",
        ]
        missing = [k for k in required if k not in data]
        if missing:
            raise SystemExit(f"Config {path} is missing keys: {', '.join(missing)}")
        return cls(
            profile=data["profile"],
            catalog=data["catalog"],
            schema=data["schema"],
            warehouse=data["warehouse"],
            lakebase=data["lakebase"],
            experiment=data["experiment"],
            endpoints=data["endpoints"],
            secrets=data["secrets"],
            app_name=data["app_name"],
            raw=data,
        )


def _log(msg: str) -> None:
    print(f"[bootstrap] {msg}", flush=True)


def _fail(msg: str) -> None:
    raise SystemExit(f"[bootstrap] ERROR: {msg}")


# --------------------------------------------------------------------------- #
# Databricks client                                                            #
# --------------------------------------------------------------------------- #
def _workspace_client(cfg: BootstrapConfig):
    from databricks.sdk import WorkspaceClient

    return WorkspaceClient(profile=cfg.profile)


# --------------------------------------------------------------------------- #
# Phase: preflight                                                             #
# --------------------------------------------------------------------------- #
def verify_endpoints(w, cfg: BootstrapConfig) -> None:
    for label, name in (
        ("LLM", cfg.endpoints.get("llm")),
        ("embedding", cfg.endpoints.get("embedding")),
    ):
        if not name:
            _fail(f"endpoints.{label.lower()} is not set in config")
        try:
            w.serving_endpoints.get(name)
            _log(f"OK  {label} serving endpoint '{name}' exists")
        except Exception as exc:  # noqa: BLE001
            _fail(
                f"{label} serving endpoint '{name}' not found in workspace "
                f"({exc}). Create it (or fix the name in config) before deploying — "
                "the agent cannot run without it."
            )


# --------------------------------------------------------------------------- #
# Phase: infra                                                                 #
# --------------------------------------------------------------------------- #
def ensure_experiment(w, cfg: BootstrapConfig) -> str:
    name = cfg.experiment.get("name")
    if not name or "CHANGE_ME" in name:
        _fail("experiment.name must be set to an absolute workspace path")
    try:
        existing = w.experiments.get_by_name(name)
        exp_id = existing.experiment.experiment_id if existing and existing.experiment else None
        if exp_id:
            _log(f"OK  experiment '{name}' exists (id={exp_id})")
            return exp_id
    except Exception:  # noqa: BLE001
        pass
    created = w.experiments.create_experiment(name)
    exp_id = created.experiment_id
    _log(f"created experiment '{name}' (id={exp_id})")
    return exp_id


def ensure_warehouse(w, cfg: BootstrapConfig) -> str:
    name = cfg.warehouse["name"]
    for wh in w.warehouses.list():
        if wh.name == name:
            _log(f"OK  SQL warehouse '{name}' exists (id={wh.id})")
            return wh.id
    _log(f"creating SQL warehouse '{name}' (this can take a few minutes)...")
    from databricks.sdk.service.sql import CreateWarehouseRequestWarehouseType

    created = w.warehouses.create(
        name=name,
        cluster_size=cfg.warehouse.get("cluster_size", "2X-Small"),
        max_num_clusters=1,
        auto_stop_mins=int(cfg.warehouse.get("auto_stop_mins", 10)),
        enable_serverless_compute=bool(cfg.warehouse.get("enable_serverless", True)),
        warehouse_type=CreateWarehouseRequestWarehouseType.PRO,
    ).result()
    _log(f"created SQL warehouse '{name}' (id={created.id})")
    return created.id


def ensure_lakebase(w, cfg: BootstrapConfig) -> dict[str, str]:
    name = cfg.lakebase["instance_name"]
    from databricks.sdk.service.database import DatabaseInstance

    inst = None
    try:
        inst = w.database.get_database_instance(name)
        _log(f"OK  Lakebase instance '{name}' exists (state={inst.state})")
    except Exception:  # noqa: BLE001
        _log(f"creating Lakebase instance '{name}' (provisioning, please wait)...")
        inst = w.database.create_database_instance_and_wait(
            DatabaseInstance(name=name, capacity=cfg.lakebase.get("capacity", "CU_1"))
        )
        _log(f"created Lakebase instance '{name}' (state={inst.state})")

    host = getattr(inst, "read_write_dns", None)
    if not host:
        # Instance may still be initializing its DNS — poll briefly.
        for _ in range(30):
            time.sleep(10)
            inst = w.database.get_database_instance(name)
            host = getattr(inst, "read_write_dns", None)
            if host:
                break
    if not host:
        _fail(f"Lakebase instance '{name}' has no read_write_dns yet; re-run shortly")
    _log(f"Lakebase host: {host}")
    return {"instance_name": name, "host": host}


def _child_env(cfg: BootstrapConfig, resolved: dict[str, Any]) -> dict[str, str]:
    """Environment for the reused helper scripts (schema/seed/history)."""
    env = os.environ.copy()
    env["DATABRICKS_CONFIG_PROFILE"] = cfg.profile
    env["DATABRICKS_SQL_WAREHOUSE_ID"] = resolved["warehouse_id"]
    env["AIDQ_PG_SCHEMA"] = cfg.lakebase.get("pg_schema", "aidq")
    env["PGHOST"] = resolved["lakebase_host"]
    env["PGDATABASE"] = cfg.lakebase.get("database", "databricks_postgres")
    env["PGPORT"] = env.get("PGPORT", "5432")
    env["LAKEBASE_INSTANCE_NAME"] = resolved["lakebase_instance_name"]
    # Provisioned instance path: clear autoscaling hints so lakebase.py uses
    # LAKEBASE_INSTANCE_NAME for OAuth credential generation.
    env.pop("LAKEBASE_AUTOSCALING_ENDPOINT", None)
    env.pop("LAKEBASE_AUTOSCALING_PROJECT", None)
    env.pop("LAKEBASE_AUTOSCALING_BRANCH", None)
    env["DATABRICKS_EMBEDDING_ENDPOINT"] = cfg.endpoints.get(
        "embedding", "databricks-gte-large-en"
    )
    env["EMBEDDING_DIMS"] = str(cfg.endpoints.get("embedding_dims", 1024))
    return env


def _run_script(script: str, env: dict[str, str], args: list[str] | None = None) -> None:
    path = ROOT / "scripts" / script
    cmd = [sys.executable, str(path), *(args or [])]
    _log(f"running {script} {' '.join(args or [])}".strip())
    result = subprocess.run(cmd, cwd=str(ROOT), env=env)
    if result.returncode != 0:
        _fail(f"{script} failed with exit code {result.returncode}")
    _log(f"OK  {script}")


def ensure_secret(w, cfg: BootstrapConfig) -> None:
    sec = cfg.secrets
    scope = sec.get("scope")
    if not scope:
        _log("no secret scope configured — skipping ServiceNow secret")
        return
    pwd_env = sec.get("servicenow_password_env", "SERVICENOW_PASSWORD")
    pwd = os.getenv(pwd_env, "")
    try:
        w.secrets.create_scope(scope)
        _log(f"created secret scope '{scope}'")
    except Exception:  # noqa: BLE001 — already exists
        _log(f"OK  secret scope '{scope}' exists")
    if pwd:
        w.secrets.put_secret(scope=scope, key="servicenow_password", string_value=pwd)
        _log(f"stored servicenow_password in scope '{scope}'")
    else:
        _log(
            f"WARN {pwd_env} not set — skipped storing servicenow_password "
            f"(set it and re-run, or add the secret manually)"
        )


def phase_infra(w, cfg: BootstrapConfig) -> dict[str, Any]:
    resolved: dict[str, Any] = {
        "profile": cfg.profile,
        "catalog": cfg.catalog,
        "schema": cfg.schema,
        "app_name": cfg.app_name,
        "llm_endpoint": cfg.endpoints.get("llm"),
        "embedding_endpoint": cfg.endpoints.get("embedding"),
    }
    resolved["experiment_id"] = ensure_experiment(w, cfg)
    resolved["warehouse_id"] = ensure_warehouse(w, cfg)
    lb = ensure_lakebase(w, cfg)
    resolved["lakebase_instance_name"] = lb["instance_name"]
    resolved["lakebase_host"] = lb["host"]
    resolved["lakebase_database"] = cfg.lakebase.get("database", "databricks_postgres")

    env = _child_env(cfg, resolved)

    # 1. Lakebase schema (extensions + aidq tables + indexes)
    _run_script("apply_lakebase_schema.py", env)
    # 2. UC catalog/schema + Delta tables + seed data from data/*.csv
    _run_script("migrate_data_to_uc.py", env)
    # 3. Incident history + pgvector embeddings
    _run_script("load_servicenow_history.py", env)
    # 4. ServiceNow secret
    ensure_secret(w, cfg)

    OUTPUT_PATH.write_text(json.dumps(resolved, indent=2), encoding="utf-8")
    _log(f"wrote resolved IDs to {OUTPUT_PATH.name}")
    _print_deploy_command(resolved)
    return resolved


def _print_deploy_command(resolved: dict[str, Any]) -> None:
    var_flags = " ".join(
        f'--var="{k}={resolved[k]}"'
        for k in (
            "warehouse_id",
            "experiment_id",
            "app_name",
            "lakebase_instance_name",
            "lakebase_database",
        )
        if resolved.get(k)
    )
    profile = resolved["profile"]
    print("\n" + "=" * 72)
    print("Infra ready. Deploy with the `provisioned` target. Pass the SAME --var")
    print("flags to BOTH deploy and run — `bundle run` also renders the app")
    print("deployment env, and an empty instance name breaks it:\n")
    print(f"  databricks bundle deploy --profile {profile} -t provisioned {var_flags}")
    print(f"  databricks bundle run agent_langgraph --profile {profile} -t provisioned {var_flags}\n")
    print("Then grant the app service principal Lakebase access:")
    print(
        f"  uv run python scripts/bootstrap_workspace.py "
        f"--config <config> --phase postdeploy"
    )
    print("=" * 72 + "\n")


# --------------------------------------------------------------------------- #
# Phase: postdeploy                                                            #
# --------------------------------------------------------------------------- #
def phase_postdeploy(w, cfg: BootstrapConfig) -> None:
    try:
        app = w.apps.get(name=cfg.app_name)
        sp_id = getattr(app, "service_principal_client_id", None)
    except Exception as exc:  # noqa: BLE001
        _fail(f"could not read app '{cfg.app_name}' ({exc}); deploy it first")
    if not sp_id:
        _fail(f"app '{cfg.app_name}' has no service_principal_client_id yet")
    _log(f"app service principal: {sp_id}")

    env = os.environ.copy()
    env["DATABRICKS_CONFIG_PROFILE"] = cfg.profile
    env["AIDQ_PG_SCHEMA"] = cfg.lakebase.get("pg_schema", "aidq")
    instance = cfg.lakebase["instance_name"]
    # We grant against a provisioned instance (--instance-name). The grant
    # script re-loads .env, so its autoscaling flags default to any
    # LAKEBASE_AUTOSCALING_* still present there. Pass explicit empty overrides
    # so the Lakebase client never sees both modes ("Choose one mode").
    for memory_type in ("langgraph", "aidq"):
        _run_script(
            "grant_lakebase_permissions.py",
            env,
            args=[
                sp_id,
                "--memory-type",
                memory_type,
                "--instance-name",
                instance,
                "--autoscaling-endpoint",
                "",
                "--project",
                "",
                "--branch",
                "",
            ],
        )
    _log("postdeploy grants complete")


# --------------------------------------------------------------------------- #
# main                                                                         #
# --------------------------------------------------------------------------- #
def main() -> int:
    load_dotenv(ROOT / ".env", override=False)
    parser = argparse.ArgumentParser(description="Bootstrap a Databricks workspace for AiDQ.")
    parser.add_argument("--config", default="workspace.bootstrap.yaml", help="Path to bootstrap config YAML")
    parser.add_argument(
        "--phase",
        choices=["preflight", "infra", "postdeploy", "all"],
        default="all",
        help="Which phase(s) to run. 'all' = preflight + infra (run before deploy).",
    )
    args = parser.parse_args()

    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path
    if not config_path.exists():
        _fail(f"config not found: {config_path}")

    cfg = BootstrapConfig.load(config_path)
    _log(f"target profile: {cfg.profile}  catalog: {cfg.catalog}.{cfg.schema}")
    w = _workspace_client(cfg)

    if args.phase in ("preflight", "all"):
        verify_endpoints(w, cfg)
    if args.phase in ("infra", "all"):
        phase_infra(w, cfg)
    if args.phase == "postdeploy":
        phase_postdeploy(w, cfg)

    _log("done")
    return 0


if __name__ == "__main__":
    sys.exit(main())
