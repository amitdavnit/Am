"""Apply AIDQ Lakebase SQL schema scripts (extensions, tables, indexes).

Usage:
    uv run python scripts/apply_lakebase_schema.py

Requires PGHOST+PGDATABASE (or POSTGRES_URL) and Databricks auth for OAuth.
"""

from __future__ import annotations

import sys
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent
SQL_DIR = ROOT / "scripts" / "sql"

SCRIPTS = [
    "001_extensions.sql",
    "002_schema_aidq.sql",
    "003_indexes.sql",
    "004_incidents_feedback.sql",
]


def main() -> int:
    from agent_server.platform.lakebase import execute_script, lakebase_configured

    if not lakebase_configured():
        print(
            "ERROR: Lakebase not configured. Set POSTGRES_URL or PGHOST+PGDATABASE "
            "(and LAKEBASE_INSTANCE_NAME for OAuth), then retry."
        )
        return 1

    for name in SCRIPTS:
        path = SQL_DIR / name
        if not path.exists():
            print(f"ERROR: missing {path}")
            return 1
        print(f"Applying {name}...")
        execute_script(path.read_text(encoding="utf-8"))
        print(f"  OK: {name}")

    print("Lakebase AIDQ schema applied successfully.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
