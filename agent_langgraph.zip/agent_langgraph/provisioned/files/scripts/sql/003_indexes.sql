-- Indexes for chat, notifications, and vector search.

CREATE INDEX IF NOT EXISTS idx_chat_threads_user_updated
    ON aidq.chat_threads (user_id, updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_chat_messages_thread_created
    ON aidq.chat_messages (thread_id, created_at, message_id);

CREATE INDEX IF NOT EXISTS idx_notifications_assignee_status
    ON aidq.notifications (assignee, status, requested_on DESC);

CREATE INDEX IF NOT EXISTS idx_notifications_type_status
    ON aidq.notifications (type, status);

CREATE INDEX IF NOT EXISTS idx_notifications_thread
    ON aidq.notifications (thread_id);

CREATE INDEX IF NOT EXISTS idx_incident_history_category
    ON aidq.incident_history (category);

-- HNSW index for cosine similarity search (pgvector)
CREATE INDEX IF NOT EXISTS idx_incident_embeddings_hnsw
    ON aidq.incident_embeddings
    USING hnsw (embedding vector_cosine_ops);
