-- Access provisioning template for the Databricks App service principal.
-- Replace :sp_client_id with the app's service_principal_client_id (UUID).
-- Prefer running: uv run python scripts/grant_lakebase_permissions.py <sp-client-id> --memory-type aidq

-- Example (run as Lakebase admin / owner):
-- GRANT USAGE, CREATE ON SCHEMA aidq TO ":sp_client_id";
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA aidq TO ":sp_client_id";
-- GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA aidq TO ":sp_client_id";
-- ALTER DEFAULT PRIVILEGES IN SCHEMA aidq
--   GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO ":sp_client_id";

GRANT USAGE, CREATE ON SCHEMA aidq TO CURRENT_USER;

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA aidq TO CURRENT_USER;
GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA aidq TO CURRENT_USER;
