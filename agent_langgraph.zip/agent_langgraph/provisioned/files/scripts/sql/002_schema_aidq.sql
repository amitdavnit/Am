-- AIDQ application schema (chat, notifications, incident history + embeddings).
CREATE SCHEMA IF NOT EXISTS aidq;

-- Chat threads (replaces workspace.aidq.chat_threads Delta table for app state)
CREATE TABLE IF NOT EXISTS aidq.chat_threads (
    thread_id       TEXT PRIMARY KEY,
    user_id         TEXT NOT NULL,
    title           TEXT NOT NULL DEFAULT 'New chat',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS aidq.chat_messages (
    message_id      TEXT PRIMARY KEY,
    thread_id       TEXT NOT NULL REFERENCES aidq.chat_threads(thread_id) ON DELETE CASCADE,
    role            TEXT NOT NULL,
    content         TEXT NOT NULL DEFAULT '',
    parts_json      JSONB,
    attachments_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    trace_id        TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- HITL notifications / approval inbox
CREATE TABLE IF NOT EXISTS aidq.notifications (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_number   TEXT,
    type              TEXT NOT NULL CHECK (type IN ('approval', 'review', 'information')),
    message           TEXT NOT NULL,
    summary_markdown  TEXT,
    payload_json      JSONB NOT NULL DEFAULT '{}'::jsonb,
    requested_by      TEXT NOT NULL,
    assignee          TEXT NOT NULL,
    requested_on      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    priority          TEXT NOT NULL DEFAULT 'medium'
                        CHECK (priority IN ('high', 'medium', 'low')),
    status            TEXT NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending', 'approved', 'rejected', 'read', 'cancelled')),
    thread_id         TEXT,
    interrupt_id      TEXT,
    decision_json     JSONB,
    read_at           TIMESTAMPTZ,
    decided_at        TIMESTAMPTZ,
    decided_by        TEXT
);

-- Historical ServiceNow incidents (structured)
CREATE TABLE IF NOT EXISTS aidq.incident_history (
    incident_number     TEXT PRIMARY KEY,
    category            TEXT,
    short_description   TEXT,
    long_description    TEXT,
    work_notes          TEXT,
    resolution_notes    TEXT,
    state               TEXT,
    created_date        TEXT,
    resolved_date       TEXT,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- pgvector embeddings for incident semantic search (dim must match embedding endpoint)
-- Default: databricks-gte-large-en = 1024
CREATE TABLE IF NOT EXISTS aidq.incident_embeddings (
    incident_number TEXT PRIMARY KEY
        REFERENCES aidq.incident_history(incident_number) ON DELETE CASCADE,
    content_text    TEXT NOT NULL,
    embedding       vector(1024) NOT NULL,
    metadata_json   JSONB NOT NULL DEFAULT '{}'::jsonb,
    content_hash    TEXT,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
