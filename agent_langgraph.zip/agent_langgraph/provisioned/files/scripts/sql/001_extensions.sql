-- Enable pgvector for semantic incident search (Lakebase / Postgres).
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
