-- Operational incidents (replaces workspace.aidq.incident Delta) + feedback.

CREATE TABLE IF NOT EXISTS aidq.incidents (
    incident_id     TEXT PRIMARY KEY,
    violation_id    TEXT,
    title           TEXT,
    description     TEXT,
    priority        TEXT,
    status          TEXT,
    assigned_to     TEXT,
    created_date    TIMESTAMPTZ,
    closed_date     TIMESTAMPTZ,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_incidents_status
    ON aidq.incidents (status);
CREATE INDEX IF NOT EXISTS idx_incidents_priority
    ON aidq.incidents (priority);
CREATE INDEX IF NOT EXISTS idx_incidents_created
    ON aidq.incidents (created_date DESC NULLS LAST);

CREATE TABLE IF NOT EXISTS aidq.feedback_events (
    feedback_id     TEXT PRIMARY KEY,
    conversation_id TEXT,
    message_id      TEXT,
    user_id         TEXT,
    display_name    TEXT,
    rating          TEXT,
    comment         TEXT,
    question        TEXT,
    answer_excerpt  TEXT,
    workflow        TEXT,
    agent_name      TEXT,
    event_type      TEXT,
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_feedback_conversation_user
    ON aidq.feedback_events (conversation_id, user_id, timestamp);
