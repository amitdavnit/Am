from __future__ import annotations

import pandas as pd
import pytest

from agent_server.agents.remediation import tools as remediation_tools
from agent_server.knowledge import sop_repository


def test_markdown_sop_matches_reason_code() -> None:
    sop = sop_repository.match_sop(
        "ENGINE_SYSTEM_CODE AND ENGINE_COMPONENT_CODE: invalid combination"
    )

    assert sop is not None
    assert sop["sop_id"] == "SOP-002"
    assert sop["validated_columns"] == [
        "ENGINE_SYSTEM_CODE",
        "ENGINE_COMPONENT_CODE",
    ]


@pytest.mark.parametrize(
    ("reason_code", "expected_sop"),
    [
        (
            "ESN 60854517 has design phase 73 and QSOL horsepower 450",
            "SOP-003",
        ),
        (
            "ESN 60359304 marketing application is Bus (No ECM), not firetruck",
            "SOP-004",
        ),
    ],
)
def test_guided_review_sops_match(
    reason_code: str, expected_sop: str
) -> None:
    sop = sop_repository.match_sop(reason_code)

    assert sop is not None
    assert sop["sop_id"] == expected_sop
    assert sop["execution_mode"] == "guided_review"
    assert sop["reference_tables"]
    assert "recycle" in sop["body"].lower()


def test_query_table_rejects_non_allowlisted_table() -> None:
    with pytest.raises(ValueError, match="not allowlisted"):
        sop_repository.query_table("workspace.secret.credentials")


def test_successful_catalog_solution_becomes_sop(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(sop_repository, "load_markdown_sops", lambda: [])
    monkeypatch.setattr(
        sop_repository,
        "list_successful_remediations",
        lambda reason_code, limit=1: [
            {
                "sop_id": "SOP-LEARNED-1234",
                "title": "Learned claim-year correction",
                "reason_code": reason_code,
                "validated_columns_json": '["CLAIM_YEAR"]',
                "lookup_table": "workspace.aidq.source_reference",
                "lookup_key": "ENGINE_SERIAL_NUM",
                "resolution_markdown": "Use the approved claim year.",
            }
        ],
    )

    sop = sop_repository.match_sop("CLAIM_YEAR is invalid")

    assert sop is not None
    assert sop["sop_id"] == "SOP-LEARNED-1234"
    assert sop["knowledge_source"] == "unity_catalog_learned_sop"


def test_verify_applied_updates_passes(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        remediation_tools,
        "load_outfile",
        lambda: pd.DataFrame(
            [
                {
                    "ENGINE_SERIAL_NUM": 1001,
                    "REASON_CODE": "bad engine code",
                    "ENGINE_SYSTEM_CODE": 42,
                }
            ]
        ),
    )

    result = remediation_tools.verify_applied_updates(
        [
            {
                "ENGINE_SERIAL_NUM": 1001,
                "reason_code": "bad engine code",
                "column": "ENGINE_SYSTEM_CODE",
                "new_value": 42,
            }
        ]
    )

    assert result == {
        "status": "PASSED",
        "verified": True,
        "checked": 1,
        "failures": [],
    }


def test_publish_successful_remediation_uses_merge(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    statements: list[str] = []
    monkeypatch.setattr(
        sop_repository, "execute_sql", lambda statement: statements.append(statement) or []
    )

    result = sop_repository.publish_successful_remediation(
        reason_code="NEW_CODE invalid",
        validated_columns=["ENGINE_SYSTEM_CODE"],
        lookup_table_name="workspace.aidq.source_reference",
        lookup_key="ENGINE_SERIAL_NUM",
        source_incident="INC001",
        updates=[{"ENGINE_SERIAL_NUM": 1, "new_value": 7}],
        user_confirmation="yes",
    )

    assert result["sop_id"].startswith("SOP-LEARNED-")
    assert "MERGE INTO workspace.aidq.remediation_knowledge" in statements[0]
