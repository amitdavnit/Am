---
{
  "sop_id": "SOP-002",
  "title": "Validate engine system and component combination",
  "status": "active",
  "reason_patterns": [
    "ENGINE_SYSTEM_CODE",
    "ENGINE_COMPONENT_CODE",
    "FE ET",
    "ENGINE SYSTEM COMPONENT"
  ],
  "lookup_table": "workspace.aidq.source_reference",
  "lookup_key": "ENGINE_SERIAL_NUM",
  "validated_columns": [
    "ENGINE_SYSTEM_CODE",
    "ENGINE_COMPONENT_CODE"
  ],
  "verification": "lookup_match"
}
---
# Engine system and component remediation

For each error record, use `ENGINE_SERIAL_NUM` to retrieve the approved
`ENGINE_SYSTEM_CODE` and `ENGINE_COMPONENT_CODE` from the source-reference
table. Propose only values returned by that lookup. Apply changes only after
human approval and verify the written values against the same lookup.
