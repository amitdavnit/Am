---
{
  "sop_id": "SOP-001",
  "title": "Validate payment and account code combination",
  "status": "active",
  "reason_patterns": [
    "PROGRAM_PAYMENT_CODE",
    "PROGRAM_ACCOUNT_CODE",
    "PAYMENT ACCOUNT"
  ],
  "lookup_table": "workspace.aidq.source_reference",
  "lookup_key": "ENGINE_SERIAL_NUM",
  "validated_columns": [
    "PROGRAM_PAYMENT_CODE",
    "PROGRAM_ACCOUNT_CODE"
  ],
  "verification": "lookup_match"
}
---
# Payment and account code remediation

For each error record, use `ENGINE_SERIAL_NUM` to retrieve the approved
`PROGRAM_PAYMENT_CODE` and `PROGRAM_ACCOUNT_CODE` from the source-reference
table. Propose only values returned by that lookup. Apply changes only after
human approval and verify the written values against the same lookup.
