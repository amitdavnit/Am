---
{
  "sop_id": "SOP-003",
  "title": "Review design phase and horsepower configuration",
  "status": "active",
  "execution_mode": "guided_review",
  "reason_patterns": [
    "DESIGN_PHASE_CODE",
    "DESIGN PHASE",
    "DESIGN PHASE AND HORSEPOWER",
    "QSOL HORSEPOWER"
  ],
  "validated_columns": [
    "DESIGN_PHASE_CODE",
    "HORSEPOWER",
    "MARKETING_ENGINE_FAMILY_CODE",
    "ENGINE_NAME",
    "MARKETING_ASPIRATION_ID",
    "CRITICAL_PARTS_LIST_NUMBER",
    "MARKETING_APPLICATION"
  ],
  "reference_tables": [
    "cmiquality_prod.Fldrel.engine",
    "fldrel.rld_design_phase",
    "fldrel.rld_engine",
    "fldrel.exception_view"
  ],
  "verification": "guided_configuration_review",
  "example_case": {
    "engine_serial_number": 60854517,
    "observed_design_phase": 73,
    "observed_horsepower": 450,
    "candidate_design_phase": 71
  }
}
---
# Design phase review and Engine Recycle procedure

Use this SOP when an engine's Design Phase Code, horsepower, CPL, or marketing
configuration appears inconsistent. This is a guided review: do not make an
automatic correction from the example alone.

## Procedure

1. Retrieve the ESN from `cmiquality_prod.Fldrel.engine`, including Design Phase
   Code, horsepower, Marketing Engine Family Code, Engine Name, Marketing
   Aspiration ID, Critical Parts List Number, marketing application, and the
   available technical-configuration attributes.
2. Verify the current marketing configuration and current horsepower in QSOL.
3. Inspect the marketing application. If it ends in `RB`, `RU`, or another value
   beginning with `R`, treat the record as a possible legacy synchronization
   exception: Design Phase and CPL may not have updated when the configuration
   changed.
4. Cross-reference the technical configuration against
   `fldrel.rld_design_phase`, `fldrel.rld_engine`, and the implemented
   `fldrel.exception_view`.
5. Confirm which critical-parts combination and CPL correspond to the current
   horsepower. Do not select a Design Phase solely because another ESN used it.
6. For ESN `60854517`, specifically verify whether horsepower `450` and its
   critical-parts combination resolve to Design Phase `71` rather than the
   observed value `73`.
7. If the references confirm the change, obtain human approval and update both
   Design Phase and horsepower in the Engine Recycle screen.
8. Recycle the record.

## Validation after recycle

- Re-query the engine record and verify Design Phase, horsepower, CPL, and
  marketing configuration.
- Confirm QSOL and the reference mappings now agree.
- If any reference source disagrees, do not close the issue; escalate it for
  configuration-data review.
