---
{
  "sop_id": "SOP-004",
  "title": "Review and correct marketing application",
  "status": "active",
  "execution_mode": "guided_review",
  "reason_patterns": [
    "MARKETING_APPLICATION",
    "MARKETING APPLICATION",
    "BUS (NO ECM)",
    "FIRETRUCK APPLICATION"
  ],
  "validated_columns": [
    "MARKETING_APPLICATION_CODE",
    "MARKETING_CONFIGURATION",
    "RPM",
    "HORSEPOWER"
  ],
  "reference_tables": [
    "Engine Recycle form",
    "Marketing Configuration form",
    "CSSNA user evidence"
  ],
  "verification": "guided_configuration_review",
  "example_case": {
    "engine_serial_number": 60359304,
    "observed_marketing_application": "Bus (No ECM)",
    "reported_application": "Firetruck"
  }
}
---
# Marketing application review and Engine Recycle procedure

Use this SOP when the recorded marketing application conflicts with the
customer's stated application or the engine's technical configuration. This is
a guided review and requires evidence before an update.

## Procedure

1. Retrieve the ESN in the Engine Recycle form and record its current marketing
   application, marketing configuration, RPM, and horsepower.
2. Compare the stored configuration with the expected application from the
   user's comments and any available CSSNA evidence.
3. In the Marketing Configuration form, search using the engine's configuration
   components to identify valid Application Codes.
4. If one Application Code is valid, select it only after confirming that its
   RPM and horsepower ranges match the engine.
5. If multiple codes are valid, choose the code that best matches both RPM and
   horsepower and document why it was selected.
6. If no candidate code is valid or the evidence conflicts, do not update the
   record. Request a customer photograph of the engine dataplate for
   verification.
7. For ESN `60359304`, verify whether `Bus (No ECM)` conflicts with the
   firetruck application reported by CSSNA and determine the valid firetruck
   Application Code from the Marketing Configuration form.
8. After human approval, update the ESN's Application Code in the Engine Recycle
   form and recycle the record.

## Validation after recycle

- Re-open the ESN and verify that the selected Application Code persisted.
- Confirm the resulting marketing application, RPM, and horsepower are
  compatible.
- Retain the user comments, CSSNA evidence, selected-code rationale, and
  dataplate evidence when one was required.
