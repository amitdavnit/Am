---
{
  "sop_id": "SOP-005",
  "title": "Fill missing warranty year with the current year",
  "status": "active",
  "execution_mode": "computed_fill",
  "reason_patterns": ["WARRANTY_YEAR", "WARRANTY YEAR"],
  "fill_strategy": "current_year",
  "validated_columns": ["WARRANTY_YEAR"],
  "verification": "computed_fill"
}
---
# Warranty year backfill

When `WARRANTY_YEAR` is null for an error record, populate it with the current
calendar year. Applies only to rows where the value is missing; rows that
already have a warranty year are left unchanged. Apply changes only after human
approval and verify the written value equals the current year.
