"""Databricks managed long-term memory (UC memory-store) tools for LangGraph."""

import os

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import DatabricksError
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import tool
from mlflow.genai.agent_server import get_request_headers

from agent_server.utils import get_user_workspace_client

# API: BASE = /api/2.1/unity-catalog/memory-stores/{DATABRICKS_MEMORY_STORE}
#   create  POST {BASE}/entries?scope=…   {path,contents,description,creation_reason,creation_source}
#   get     GET  {BASE}/entries:get       ?scope,path
#   list    GET  {BASE}/entries           ?scope
#   update  PATCH{BASE}/entries          {scope, path, [description], [one contents edit op]}
#   delete  DELETE {BASE}/entries         ?scope,path

_client: WorkspaceClient | None = None


def _ws() -> WorkspaceClient:
    """The memory caller — the app SP when deployed, the developer when local. Per-user isolation is via
    `scope`, NEVER this identity (the SP can see every scope)."""
    global _client
    if _client is None:
        _client = WorkspaceClient()
    return _client


def _entries(suffix: str = "") -> str:
    store = os.getenv("DATABRICKS_MEMORY_STORE")
    if not store:
        raise RuntimeError("DATABRICKS_MEMORY_STORE is not set — it must be the full catalog.schema.name.")
    return f"/api/2.1/unity-catalog/memory-stores/{store}/entries{suffix}"


def resolve_scope(request=None) -> str | None:
    """End-user id used as memory `scope`, or None if it can't be determined (fail closed).

    Prefer OBO (`x-forwarded-access-token` → current_user.me().id). When that isn't present,
    fall back to gateway-injected identity headers that Databricks Apps sets on the request
    (`x-forwarded-user` / `x-forwarded-email`). Local-only: `custom_inputs.user_id`.
    """
    headers = {str(k).lower(): v for k, v in (get_request_headers() or {}).items()}
    if headers.get("x-forwarded-access-token"):
        try:
            return get_user_workspace_client().current_user.me().id
        except Exception:
            # Token present but unusable — continue to gateway header fallbacks
            pass

    gateway_user = headers.get("x-forwarded-user") or headers.get("x-forwarded-email")
    if gateway_user:
        return gateway_user

    # Local / non-Apps only: allow client-supplied user_id for preflight & curl tests
    if not os.getenv("DATABRICKS_APP_NAME"):
        ci = dict(getattr(request, "custom_inputs", None) or {})
        return ci.get("user_id")
    return None


def _save(scope, path, description, contents=""):
    try:
        _ws().api_client.do(
            "POST",
            _entries(),
            query={"scope": scope},
            body={
                "path": path,
                "contents": contents,
                "description": description,
                "creation_reason": "CREATION_REASON_AGENT_INFERRED",
                "creation_source": "CREATION_SOURCE_ONLINE_AGENT",
            },
        )
    except DatabricksError as e:
        if e.error_code == "ALREADY_EXISTS":
            return f"A memory already exists at {path}; use update_memory to revise it."
        return f"Could not save {path}: {getattr(e, 'message', str(e))}"
    return f"Saved memory at {path}."


def _get(scope, path):
    try:
        entry = _ws().api_client.do("GET", _entries(":get"), query={"scope": scope, "path": path})
    except DatabricksError as e:
        if e.error_code == "NOT_FOUND":
            return f"No memory at {path}."
        return f"Could not read {path}: {getattr(e, 'message', str(e))}"
    # A brief memory may have empty contents — its description is then the memory.
    return entry.get("contents") or entry.get("description") or f"(empty memory at {path})"


def _list(scope):
    try:
        resp = _ws().api_client.do("GET", _entries(), query={"scope": scope})
    except DatabricksError as e:
        return f"Could not list memories: {getattr(e, 'message', str(e))}"
    items = resp.get("entries", [])
    if not items:
        return "No memories yet."
    # Count header; `[has_contents]` marks entries whose body must be read with get_memory.
    lines = [
        ("[has_contents] " if e.get("has_contents") else "")
        + f"- {e['path']}: {e.get('description', '')}"
        for e in items
    ]
    return f"{len(items)} memories total:\n" + "\n".join(lines)


def _update(scope, path, op=None, description=None):  # op = at most one of str_replace/insert/replace_all
    op = op or {}
    if len(op) > 1:
        return "Pass at most one contents edit (str_replace / insert / replace_all)."
    if not op and description is None:
        return "Provide a new description and/or one contents edit (str_replace / insert / replace_all)."
    body = {"scope": scope, "path": path, **op}
    if description is not None:
        body["description"] = description
    try:
        _ws().api_client.do("PATCH", _entries(), body=body)
    except DatabricksError as e:
        if e.error_code == "NOT_FOUND":
            return f"No memory at {path} to update — check list_memories or save it first."
        return f"Could not update {path}: {getattr(e, 'message', str(e))}"
    return f"Updated {path}."


def _delete(scope, path):
    try:
        _ws().api_client.do("DELETE", _entries(), query={"scope": scope, "path": path})
    except DatabricksError as e:
        if e.error_code == "NOT_FOUND":
            return f"No memory at {path} (already gone)."
        return f"Could not delete {path}: {getattr(e, 'message', str(e))}"
    return f"Deleted {path}."


def _scope(config: RunnableConfig) -> str:
    s = (config.get("configurable") or {}).get("memory_scope")
    if not s:
        raise RuntimeError("No end-user scope in config — refusing a shared memory bucket.")
    return s


def memory_tools():
    @tool
    async def save_memory(path: str, config: RunnableConfig, description: str, contents: str = "") -> str:
        """Create ONE durable memory — a stable preference, fact, decision, or ongoing project; not one-off
        chatter or secrets. Create-only (an existing path errors), so check list_memories first and use
        update_memory to revise a topic. path: a SHORT, STABLE topic bucket (lowercase-hyphenated, starts
        /memories/, ends .md) — keep it broad and reusable (e.g. /memories/preferences/food.md); put the
        specifics in description/contents, NOT the path, so related facts share one path and you update it
        instead of minting near-duplicates (avoid over-specific paths like /memories/preferences/coffee-oat-milk.md).
        description: a one-line statement; for a brief fact this IS the memory (leave contents empty).
        contents: OPTIONAL — only when the memory needs more than one line; detailed; never echo the description."""
        return _save(_scope(config), path, description, contents)

    @tool
    async def get_memory(path: str, config: RunnableConfig) -> str:
        """Read the FULL contents of ONE memory by its exact path (from list_memories). The only way to see
        what a memory says — always get_memory before stating a remembered fact; a description is just a
        label. Not found means it isn't stored, not that the fact is false."""
        return _get(_scope(config), path)

    @tool
    async def list_memories(config: RunnableConfig) -> str:
        """List EVERY saved memory as (path, description) — the index; returns NO contents. Your first step
        for recall (scan → pick the relevant path(s)) and before saving (so you update an existing topic rather
        than duplicate). An entry prefixed `[has_contents]` has a fuller body — get_memory(path) to read it
        before stating specifics; an entry without that prefix is fully captured by its description. One call per turn."""
        return _list(_scope(config))

    @tool
    async def update_memory(
        path: str,
        config: RunnableConfig,
        description: str | None = None,
        str_replace: dict | None = None,
        insert: dict | None = None,
        replace_all: dict | None = None,
    ) -> str:
        """Revise an EXISTING memory in place (same path; the path can't change). Pass description="..." to
        replace its one-line description (use this to correct a brief, description-only memory), and/or EXACTLY
        ONE contents edit op — str_replace={"old_str": ..., "new_str": ...} (old_str must occur once) ·
        insert={"insert_text": ..., "insert_line": <optional>} · replace_all={"contents": ...}. get_memory first
        so a contents edit matches; at least one of description / an edit op is required."""
        op = {
            k: v
            for k, v in (
                ("str_replace", str_replace),
                ("insert", insert),
                ("replace_all", replace_all),
            )
            if v
        }
        return _update(_scope(config), path, op, description)

    @tool
    async def delete_memory(path: str, config: RunnableConfig) -> str:
        """Permanently remove ONE memory by its exact path. Use for stale/wrong/superseded/duplicate entries
        or when the user asks to forget something. Don't delete to rewrite a valid fact — use update_memory."""
        return _delete(_scope(config), path)

    return [save_memory, get_memory, list_memories, update_memory, delete_memory]
