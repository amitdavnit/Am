"""Package marker for domain services."""
