﻿"""Supervisor tools — the five callable actions the supervisor ReAct agent can invoke."""

from __future__ import annotations

import json
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from agent_server.orchestration.hitl_formatting import format_incident_hitl_summary

logger = logging.getLogger(__name__)

from typing import Annotated

from langchain_core.messages import HumanMessage, ToolMessage
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import tool, InjectedToolCallId
from langgraph.prebuilt import InjectedState
from langgraph.prebuilt.chat_agent_executor import AgentState
from langgraph.types import Command, interrupt


class SupervisorState(AgentState):
    """Pipeline state shared across supervisor tools.

    Persisted by the Lakebase AsyncCheckpointSaver, so it survives HITL interrupts
    and process restarts. Each tool reads its inputs and writes its outputs here.
    """
    outfile_source: str
    buckets: dict
    tickets: list
    incident_creation_decision: dict
    sop_diagnoses: list
    rca_results: list
    recommended_diagnoses: list
    hitl_decision: dict
    corrections_applied: bool
    apply_result: dict
    resolved_tickets: list
    verification_result: dict
    success_confirmation: dict
    promoted_sops: list


def _extract_last_ai_text(result: dict) -> str:
    """Extract the final AI message text from a create_react_agent invocation result."""
    messages = result.get("messages", [])
    for msg in reversed(messages):
        if not hasattr(msg, "content"):
            continue
        if isinstance(msg, HumanMessage):
            continue
        content = msg.content
        if isinstance(content, list):
            return "".join(
                b.get("text", "") for b in content if isinstance(b, dict)
            )
        return str(content)
    return ""


def _parse_json_from_text(text: str) -> Any | None:
    """Extract the first JSON object or array from a text block.

    Handles LLM responses that wrap JSON in markdown code fences (```json ... ```)
    as well as responses that mix prose with embedded JSON.

    Strategy:
    1. Strip markdown fences and try to parse the inner content directly.
    2. Try a direct json.loads on the full text.
    3. Bracket scan — find whichever bracket ({ or [) appears FIRST in the text,
       then use a depth counter to find the matching close bracket and parse that block.
       "Leftmost wins" ensures we always grab the outermost container:
         - Agent 1 returns  [ {...}, {...} ]  → [ comes first → full array extracted
         - Agent 3a returns { ..., "correctable": [] } → { comes first → full dict extracted
    """
    text = text.strip()
    fence_match = re.search(r"```(?:json|JSON)?\s*\n?([\s\S]*?)\n?```", text)
    if fence_match:
        inner = fence_match.group(1).strip()
        try:
            return json.loads(inner)
        except (json.JSONDecodeError, ValueError):
            text = inner

    try:
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        pass

    first_brace = text.find("{")
    first_bracket = text.find("[")
    if first_brace == -1 and first_bracket == -1:
        return None

    if first_brace == -1:
        bracket_order = ["["]
    elif first_bracket == -1:
        bracket_order = ["{"]
    elif first_brace < first_bracket:
        bracket_order = ["{", "["]
    else:
        bracket_order = ["[", "{"]

    for start in bracket_order:
        idx = text.find(start)
        if idx < 0:
            continue
        depth = 0
        for i in range(idx, len(text)):
            if text[i] in "([{":
                depth += 1
            elif text[i] in ")]}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[idx : i + 1])
                    except (json.JSONDecodeError, ValueError):
                        break
    return None


def _parse_hitl_decision(user_text: str, llm: Any) -> dict:
    """Parse HITL approval into a structured decision (JSON, keywords, or LLM)."""
    logger.info("[HITL] Parsing human response: %r", user_text[:120])
    text = (user_text or "").strip()

    # Structured resume from the aggregation gate / Notifications Approve/Reject API
    if text.startswith("{"):
        try:
            payload = json.loads(text)
            if isinstance(payload, dict) and payload.get("decision") in (
                "all",
                "partial",
                "none",
                "invalid",
            ):
                parsed = {
                    "decision": payload["decision"],
                    "approved_esns": payload.get("approved_esns"),
                }
                if parsed["decision"] == "none":
                    parsed["approved_esns"] = payload.get("approved_esns") or []
                # Per-incident gate carries which incidents were approved/rejected so
                # apply_corrections resolves only the approved incidents' tickets.
                if payload.get("approved_incidents") is not None:
                    parsed["approved_incidents"] = payload.get("approved_incidents")
                if payload.get("rejected_incidents") is not None:
                    parsed["rejected_incidents"] = payload.get("rejected_incidents")
                logger.info("[HITL] Structured JSON decision: %s", parsed)
                return parsed
        except json.JSONDecodeError:
            pass

    # Fast-path: handle clear approve/reject keywords without an LLM round-trip
    _lower = text.lower()
    _APPROVE_KEYWORDS = {
        "yes", "y", "approve", "approved", "confirm", "confirmed",
        "ok", "okay", "all", "approve all", "approve all records",
        "yes approve", "yes, approve", "yes please",
    }
    _REJECT_KEYWORDS = {"no", "n", "cancel", "reject", "rejected", "deny", "denied", "none"}
    if _lower in _APPROVE_KEYWORDS or any(_lower.startswith(kw) for kw in ("yes ", "approve ")):
        logger.info("[HITL] Fast-path keyword match — decision=all")
        return {"decision": "all", "approved_esns": None}
    if _lower in _REJECT_KEYWORDS:
        logger.info("[HITL] Fast-path keyword match — decision=none")
        return {"decision": "none", "approved_esns": []}

    prompt = (
        "Parse the following human approval response for a data quality remediation system.\n\n"
        f"Response: \"{user_text}\"\n\n"
        "Return ONLY valid JSON with this exact schema:\n"
        '{"decision": "<all|partial|none|invalid>", "approved_esns": [<int>, ...] or null}\n\n'
        "Rules:\n"
        "- 'all': user said yes/approve/confirm/all — approved_esns must be null\n"
        "- 'none': user said no/cancel/reject — approved_esns must be []\n"
        "- 'partial': user listed specific ENGINE_SERIAL_NUM values — extract them as integers\n"
        "- 'invalid': response is ambiguous or unrelated — approved_esns must be null\n"
        "Return ONLY valid JSON with no markdown formatting."
    )
    try:
        resp = llm.invoke(prompt)
        raw = resp.content if hasattr(resp, "content") else str(resp)
        if isinstance(raw, list):
            raw = "".join(b.get("text", "") for b in raw if isinstance(b, dict))
        # Handle markdown-wrapped JSON or extra prose around the JSON object
        extracted = _parse_json_from_text(raw)
        if extracted is not None:
            logger.info("[HITL] Parsed decision: %s", extracted)
            return extracted
        # Last resort: direct parse (works if LLM returns bare JSON)
        parsed = json.loads(raw)
        logger.info("[HITL] Parsed decision: %s", parsed)
        return parsed
    except Exception:
        logger.warning("[HITL] LLM HITL parse failed for: %r", user_text, exc_info=True)
        return {"decision": "invalid", "approved_esns": None}


@tool
def analyze_outfile(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
    config: RunnableConfig,
    source: str | None = None,
    force: bool = False,
) -> Command:
    """Analyse a DQ error outfile, bucket errors by REASON_CODE, and create ServiceNow incidents.

    Args:
        source: Optional Unity Catalog table FQN (catalog.schema.table) OR a file path
                (CSV/Parquet/Excel, local or /Volumes/...). When omitted, uses the
                configured default OUTFILE_TABLE.
        force: Set True ONLY when the user explicitly asks to reprocess a source that
               was already processed (e.g. "force reprocess", "reprocess anyway").
               Otherwise leave False so already-processed sources are skipped.

    Buckets the errors AND creates one ServiceNow incident per bucket in a single step,
    then writes the resulting tickets into state. Call this FIRST for a remediation run,
    then immediately call run_all_remediations.

    If the source was already processed and force is not set, this returns a message
    saying so and does NOT run the pipeline — in that case, report the message to the
    user and STOP (do not call run_all_remediations)."""
    from agent_server.agents.outfile_analysis.tools import (
        bucket_outfile,
        create_tickets_from_buckets,
    )
    from agent_server.knowledge import processing_audit
    from agent_server.knowledge.outfile_repository import (
        is_file_source,
        set_outfile_source,
    )

    existing_tickets = state.get("tickets") or []
    # Mid-run guard: buckets analysed + incidents created but remediation not started.
    if (
        existing_tickets
        and any(t.get("incident_number") for t in existing_tickets)
        and not (state.get("sop_diagnoses") or [])
        and not (state.get("rca_results") or [])
        and not state.get("corrections_applied")
    ):
        logger.warning(
            "[AGENT1] analyze_outfile already completed this run (%d ticket(s)) — skipping",
            len(existing_tickets),
        )
        return Command(update={
            "messages": [ToolMessage(
                f"STEP 1 already complete ({len(existing_tickets)} incident(s) in state). "
                "Do NOT call analyze_outfile again. Immediately call run_all_remediations.",
                tool_call_id=tool_call_id,
            )],
        })

    resolved_source = set_outfile_source(source or state.get("outfile_source"))
    logger.info("[AGENT1] analyze_outfile — bucketing source=%r", resolved_source)

    # Reprocess guard — decide what (if anything) to process. For tables this is
    # per-INGESTION_ID incremental: only batches not seen in a prior run are
    # processed; files are blocked forever until forced.
    source_type = "file" if is_file_source(resolved_source) else "table"
    configurable = (config or {}).get("configurable") or {}
    thread_id = configurable.get("thread_id")
    user_id = configurable.get("user_id") or "unknown"
    try:
        plan = processing_audit.plan_processing(
            source_identifier=resolved_source,
            source_type=source_type,
            force=force,
        )
    except Exception:
        logger.exception("[AGENT1] Reprocess guard planning failed — processing whole source")
        plan = {"blocked": False, "processed_on": None,
                "allowed_ingestion_ids": None, "source_version": ""}

    if plan.get("blocked"):
        processed_on = plan.get("processed_on") or "an earlier date"
        label = "file" if source_type == "file" else "table"
        logger.info(
            "[AGENT1] %s %r has no new data (last processed %s) — blocking (force=%s)",
            label, resolved_source, processed_on, force,
        )
        return Command(update={
            "messages": [ToolMessage(
                f"'{resolved_source}' has no new data to process — every batch was "
                f"already remediated (most recently on {processed_on}). "
                "If you want to run it again anyway, ask to 'force reprocess'. "
                "Do NOT call run_all_remediations — report this to the user and STOP.",
                tool_call_id=tool_call_id,
            )],
        })

    allowed_ingestion_ids = plan.get("allowed_ingestion_ids")
    source_version = plan.get("source_version") or ""
    if allowed_ingestion_ids is not None:
        logger.info(
            "[AGENT1] Incremental run — processing %d new ingestion batch(es): %s",
            len(allowed_ingestion_ids), allowed_ingestion_ids,
        )

    buckets: dict = {}
    tickets: list[dict] = []
    try:
        buckets = json.loads(
            bucket_outfile(resolved_source, allowed_ingestion_ids=allowed_ingestion_ids)
        )
        bucket_count = len(buckets)
        total_rows = sum(int(v.get("count", 0)) for v in buckets.values())
        logger.info(
            "[AGENT1] analyze_outfile complete — %d bucket(s), %d row(s)",
            bucket_count,
            total_rows,
        )
        if bucket_count == 0:
            msg = (
                f"No error rows found in {resolved_source}. "
                "Pipeline has nothing to remediate — STOP."
            )
        else:
            tickets = create_tickets_from_buckets(buckets)
            nums = [t.get("incident_number") for t in tickets if t.get("incident_number")]
            logger.info("[AGENT1] Created %d ServiceNow incident(s): %s", len(nums), nums)
            msg = (
                f"Analysed {resolved_source}: {bucket_count} error bucket(s), "
                f"{total_rows} record(s); created {len(nums)} ServiceNow incident(s). "
                "NEXT: call run_all_remediations immediately (no text)."
            )
        processing_audit.record_processing(
            source_identifier=resolved_source,
            source_type=source_type,
            source_version=source_version,
            processed_by=user_id,
            thread_id=thread_id,
            status="completed",
            row_count=total_rows,
            bucket_count=bucket_count,
            tickets_created=len(tickets),
        )
    except Exception as exc:
        logger.exception("[AGENT1] analyze_outfile failed")
        buckets = {}
        tickets = []
        msg = f"analyze_outfile failed for {resolved_source}: {exc}"

    return Command(update={
        "outfile_source": resolved_source,
        "buckets": buckets,
        "tickets": tickets,
        "incident_creation_decision": {},
        "sop_diagnoses": [],
        "rca_results": [],
        "recommended_diagnoses": [],
        "hitl_decision": {},
        "corrections_applied": False,
        "apply_result": {},
        "resolved_tickets": [],
        "verification_result": {},
        "success_confirmation": {},
        "promoted_sops": [],
        "messages": [ToolMessage(msg, tool_call_id=tool_call_id)],
    })


@tool
def run_all_remediations(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Run SOP diagnosis (Agent 3a) for every bucket, with RCA (Agent 2) as an
    analysis-only fallback for buckets that have no matching SOP.

    Reads the ticket list from state (written by analyze_outfile); writes
    sop_diagnoses and rca_results back to state. Takes no arguments.

    SOP-matched buckets produce deterministic, lookup-backed correction candidates
    (sop_diagnoses). Buckets with no SOP match go to RCA, which is informational
    only (narrative + ServiceNow work note) and never proposes auto-corrections.
    """
    from agent_server.agents.remediation.agent import get_agent3a
    from agent_server.agents.rca_recommendations.agent import get_agent2
    from agent_server.knowledge.outfile_repository import set_outfile_source

    buckets: list[dict] = state.get("tickets") or []
    # The active outfile source lives in a ContextVar that does NOT propagate into
    # ThreadPoolExecutor worker threads, so capture it here and re-apply it inside
    # each worker; otherwise SOP diagnosis silently falls back to the default table.
    outfile_source = state.get("outfile_source")
    set_outfile_source(outfile_source)
    logger.info(
        "[REMEDIATION] run_all_remediations — SOP diagnosis for %d bucket(s), RCA fallback for no-SOP",
        len(buckets),
    )

    sop_diagnoses: list[dict] = []
    no_sop_buckets: list[dict] = []
    rca_results: list[dict] = []

    def _run_sop_diagnosis(bucket: dict) -> tuple[dict, bool]:
        """Return (result, is_no_sop). result is a diagnosis dict on SOP match,
        or a {status: no_sop_match} marker when nothing matches."""
        set_outfile_source(outfile_source)  # worker thread has its own context
        reason_code = bucket.get("reason_code", "") or ""
        sys_id = bucket.get("sys_id") or ""
        incident_number = bucket.get("incident_number") or ""
        esns = bucket.get("esns", []) or []
        logger.info("[AGENT3a] Starting SOP diagnosis for reason_code=%r  incident=%s", reason_code, incident_number)
        message = (
            f"Diagnose this DQ issue.\n\n"
            f"reason_code: {reason_code}\n"
            f"sys_id: {sys_id if sys_id else 'not available'}\n"
            f"incident_number: {incident_number if incident_number else 'not available'}\n\n"
            f"ACTION REQUIRED: Call validate_markdown_sop now (it reads reason_code and ESNs "
            f"from state), then post the diagnosis work note. Only conclude no_sop_match if "
            f"nothing matches."
        )
        try:
            agent3a = get_agent3a()
            result = agent3a.invoke({
                "messages": [HumanMessage(content=message)],
                "reason_code": reason_code,
                "sys_id": sys_id,
                "incident_number": incident_number,
                "esns": esns,
            })
            diagnosis = result.get("diagnosis")
            if (
                isinstance(diagnosis, dict)
                and diagnosis.get("reason_code") is not None
                and diagnosis.get("status") != "no_sop_match"
            ):
                diagnosis["incident_number"] = incident_number
                diagnosis["sys_id"] = sys_id
                logger.info(
                    "[AGENT3a] SOP match reason_code=%r — total=%s correctable=%d source_issues=%d no_source=%d",
                    reason_code, diagnosis.get("total_records"),
                    len(diagnosis.get("correctable", [])), len(diagnosis.get("source_issues", [])),
                    len(diagnosis.get("no_source", [])),
                )
                return diagnosis, False
            text = _extract_last_ai_text(result)
            parsed = _parse_json_from_text(text)
            if isinstance(parsed, dict) and parsed.get("status") == "no_sop_match":
                logger.info("[AGENT3a] No SOP match for reason_code=%r → RCA fallback", reason_code)
                return parsed, True
            logger.warning("[AGENT3a] No diagnosis in state for reason_code=%r; raw=%r", reason_code, text[:300])
            return {"status": "no_sop_match", "reason_code": reason_code}, True
        except Exception as exc:
            logger.exception("[AGENT3a] Exception diagnosing reason_code=%r", reason_code)
            return {"status": "no_sop_match", "reason_code": reason_code, "error": str(exc)}, True

    def _run_rca(bucket: dict) -> dict:
        """Analysis-only RCA — narrative + work note + similar incidents, no corrections."""
        set_outfile_source(outfile_source)  # ensure outfile source is set in this context
        reason_code = bucket.get("reason_code") or ""
        sys_id = bucket.get("sys_id") or ""
        incident_number = bucket.get("incident_number") or ""
        logger.info("[AGENT2] Starting RCA (analysis-only) for reason_code=%r  incident=%s", reason_code, incident_number)
        result_dict: dict = {}
        try:
            agent2 = get_agent2()
            result = agent2.invoke({
                "messages": [HumanMessage(content="Run the RCA steps for the provided incident.")],
                "reason_code": reason_code,
                "sys_id": sys_id,
                "incident_number": incident_number,
            })
            result_dict = {
                "reason_code": reason_code,
                "incident_number": incident_number,
                "rca_narrative": result.get("rca_narrative", ""),
                "work_note_status": result.get("work_note_status", "unknown"),
            }
        except Exception as exc:
            logger.exception("[AGENT2] Exception during RCA for reason_code=%r", reason_code)
            result_dict = {
                "reason_code": reason_code,
                "incident_number": incident_number,
                "error": str(exc),
            }

        try:
            from agent_server.agents.rca_recommendations.tools import _search_incidents

            raw_results = _search_incidents(reason_code, k=5)
            seen: set = set()
            similar: list[dict] = []
            for doc, score in raw_results:
                inc_num = doc.metadata.get("incident_number", "")
                if not inc_num or inc_num in seen:
                    continue
                seen.add(inc_num)
                similar.append({
                    "incident_number": inc_num,
                    "confidence": round((1 / (1 + score)) * 100, 2),
                    "state": doc.metadata.get("state", ""),
                    "resolved_date": doc.metadata.get("resolved_date", ""),
                    "summary": doc.page_content[:300],
                })
            result_dict["similar_incidents"] = similar[:3]
        except Exception:
            logger.warning(
                "[AGENT2] Could not enrich RCA with similar incidents",
                exc_info=True,
            )
            result_dict.setdefault("similar_incidents", [])

        return result_dict

    # Phase 1 — SOP diagnosis for every bucket in parallel.
    if buckets:
        with ThreadPoolExecutor(max_workers=min(len(buckets), 4)) as executor:
            future_to_bucket = {
                executor.submit(_run_sop_diagnosis, b): b for b in buckets
            }
            for future in as_completed(future_to_bucket):
                bucket = future_to_bucket[future]
                try:
                    diag_result, is_no_sop = future.result()
                except Exception:
                    logger.exception(
                        "[REMEDIATION] Parallel SOP diagnosis failed for %s",
                        bucket.get("reason_code"),
                    )
                    no_sop_buckets.append(bucket)
                    continue
                if is_no_sop:
                    no_sop_buckets.append(bucket)
                else:
                    sop_diagnoses.append(diag_result)

    # Phase 2 — RCA analysis-only fallback for buckets with no SOP match.
    for bucket in no_sop_buckets:
        rca_results.append(_run_rca(bucket))

    logger.info(
        "[REMEDIATION] Complete — sop_diagnoses=%d rca_results=%d",
        len(sop_diagnoses),
        len(rca_results),
    )
    msg = (
        f"Diagnosis done — {len(sop_diagnoses)} SOP match(es), "
        f"{len(rca_results)} RCA analysis result(s). "
        "NEXT: call request_human_approval immediately (no text)."
    )
    return Command(update={
        "sop_diagnoses": sop_diagnoses,
        "rca_results": rca_results,
        "recommended_diagnoses": [],  # RCA is analysis-only; corrections come from SOP diagnosis
        "corrections_applied": False,
        "apply_result": {},
        "resolved_tickets": [],
        "verification_result": {},
        "success_confirmation": {},
        "promoted_sops": [],
        "messages": [ToolMessage(msg, tool_call_id=tool_call_id)],
    })


def _create_review_notifications(
    *,
    actionable_diagnoses: list[dict],
    rca_results: list[dict],
    thread_id: str | None,
    user_id: str,
    existing_keys: set,
) -> None:
    """Create 'For Review' inbox rows for incidents that CANNOT be auto-fixed.

    These are acknowledgement-only (they never pause the graph):
      - SOP diagnoses whose rows are source-level issues / have no source record
        (the source already holds the same invalid values → manual escalation).
      - RCA-only analyses (no matching SOP → informational recommendation).

    Idempotent: skips any (incident_number, 'review') pair already present for the
    thread so a HITL resume does not spawn duplicates.
    """
    from agent_server.orchestration.hitl_formatting import (
        format_rca_section,
        format_sop_section,
    )
    from api.services import notifications as notification_service

    for diagnosis in actionable_diagnoses:
        if diagnosis.get("correctable"):
            continue  # correctable rows belong in the approval inbox instead
        source_issues = diagnosis.get("source_issues") or []
        no_source = diagnosis.get("no_source") or []
        if not (source_issues or no_source):
            continue
        incident_number = diagnosis.get("incident_number")
        if incident_number and (incident_number, "review") in existing_keys:
            continue
        reason_code = diagnosis.get("reason_code", "") or ""
        n_rows = len(source_issues) + len(no_source)
        try:
            notification_service.create_notification(
                type="review",
                message=(
                    f"Source-level issue for '{reason_code}'"
                    + (f" ({incident_number})" if incident_number else "")
                    + f" — {n_rows} record(s) need manual escalation (no auto-fix)"
                ),
                requested_by=user_id,
                assignee=user_id,
                incident_number=incident_number,
                summary_markdown=(
                    "## 🔎 Manual review — source-level issue\n\n"
                    "These rows cannot be auto-corrected because the source system holds "
                    "the same invalid values (or has no matching record). Escalate for a "
                    "manual data fix at the source; the ServiceNow incident stays open.\n\n"
                    + "\n".join(format_sop_section(diagnosis))
                ),
                payload={
                    "thread_id": thread_id,
                    "reason_code": reason_code,
                    "incident_number": incident_number,
                    "kind": "source_issue",
                },
                priority="medium",
                thread_id=thread_id,
            )
        except Exception:
            logger.exception(
                "[HITL] Failed to create source-issue review notification for %s",
                incident_number,
            )

    for result in rca_results:
        incident_number = result.get("incident_number")
        if incident_number and (incident_number, "review") in existing_keys:
            continue
        reason_code = result.get("reason_code", "") or ""
        try:
            notification_service.create_notification(
                type="review",
                message=(
                    f"RCA analysis for '{reason_code}'"
                    + (f" ({incident_number})" if incident_number else "")
                    + " — review recommended actions (no auto-fix)"
                ),
                requested_by=user_id,
                assignee=user_id,
                incident_number=incident_number,
                summary_markdown=(
                    "## 🔎 Manual review — RCA analysis\n\n"
                    + "\n".join(format_rca_section(result))
                ),
                payload={
                    "thread_id": thread_id,
                    "reason_code": reason_code,
                    "incident_number": incident_number,
                    "kind": "rca",
                },
                priority="low",
                thread_id=thread_id,
            )
        except Exception:
            logger.exception(
                "[HITL] Failed to create RCA review notification for %s",
                incident_number,
            )


@tool
def request_human_approval(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
    config: RunnableConfig,
) -> Command:
    """Present pipeline results to the human and pause for their decision.

    Reads sop_diagnoses / rca_results / tickets from state, builds a per-incident
    approval summary, creates ONE Notifications inbox row PER SOP-correctable incident
    (all sharing a group_id), interrupts, then writes the parsed decision back to
    state. Takes no arguments.

    The graph resumes only once every per-incident notification for this round has
    been decided; the aggregation gate in api/routers/notifications.py builds the
    combined decision and resumes with it. A user may also approve/reject in chat
    (per-incident controls) — those call the same notification endpoints.
    """
    import uuid as _uuid
    from langchain_core.runnables import RunnableConfig as _RC  # noqa: F401

    from agent_server.platform.lakebase import lakebase_configured
    from agent_server.platform.llm import get_bedrock_llm
    from api.services import notifications as notification_service

    sop_diagnoses: list[dict] = state.get("sop_diagnoses", []) or []
    recommended_diagnoses: list[dict] = (
        state.get("recommended_diagnoses", []) or []
    )
    actionable_diagnoses = [*sop_diagnoses, *recommended_diagnoses]
    rca_results: list[dict] = state.get("rca_results", []) or []
    tickets: list[dict] = state.get("tickets", []) or []

    # Only SOP-correctable incidents (non-empty correctable rows) need approval.
    correctable_diagnoses = [
        d for d in actionable_diagnoses if d.get("correctable")
    ]
    total_correctable = sum(len(d.get("correctable", [])) for d in correctable_diagnoses)
    logger.info(
        "[HITL] request_human_approval — sop=%d rca=%d tickets=%d correctable_incidents=%d correctable_rows=%d",
        len(sop_diagnoses),
        len(rca_results),
        len(tickets),
        len(correctable_diagnoses),
        total_correctable,
    )

    configurable = (config or {}).get("configurable") or {}
    thread_id = configurable.get("thread_id")
    user_id = configurable.get("user_id") or "unknown"

    # On HITL resume, LangGraph re-runs this tool from the top (everything before
    # interrupt() executes again). Look up notifications that already exist for this
    # thread so we never recreate a row — that is what previously spawned duplicate
    # approval notifications after an approve/reject.
    existing_notifications = (
        notification_service.list_for_thread(thread_id, type=None)
        if (lakebase_configured() and thread_id)
        else []
    )
    existing_keys = {
        (n.get("incident_number"), n.get("type")) for n in existing_notifications
    }

    # Source-level issues / RCA-only analyses → "For Review" inbox (no pause).
    if lakebase_configured():
        _create_review_notifications(
            actionable_diagnoses=actionable_diagnoses,
            rca_results=rca_results,
            thread_id=thread_id,
            user_id=user_id,
            existing_keys=existing_keys,
        )

    # Nothing correctable → no approval needed. Skip the pause and finish.
    if not correctable_diagnoses:
        # apply_corrections will NOT run in this path, so compute the real summary
        # numbers here — otherwise the LLM fills the final template with fabricated
        # zeros for source_issues / rca_analyses.
        source_issues = sum(len(d.get("source_issues") or []) for d in actionable_diagnoses)
        rca_count = len(rca_results)
        outfile_source = state.get("outfile_source") or ""
        logger.info(
            "[HITL] No SOP-correctable incidents — skipping approval pause "
            "(buckets=%d source_issues=%d rca_analyses=%d)",
            len(tickets), source_issues, rca_count,
        )
        return Command(update={
            "hitl_decision": {"decision": "none", "approved_esns": [], "approved_incidents": []},
            "messages": [ToolMessage(
                "No SOP-correctable incidents were found (RCA analysis is informational only). "
                "NEXT: output the final '## ✅ Pipeline Complete' summary using EXACTLY these "
                "numbers and STOP:\n"
                f"- Source: {outfile_source}\n"
                f"- Buckets analyzed: {len(tickets)}\n"
                "- Corrections applied: 0\n"
                "- ServiceNow incidents resolved: 0\n"
                f"- Source-level issues (escalation needed): {source_issues}\n"
                f"- RCA analyses: {rca_count}",
                tool_call_id=tool_call_id,
            )],
        })

    group_id = str(_uuid.uuid4())
    combined_summary = format_incident_hitl_summary(correctable_diagnoses)

    if lakebase_configured():
        for diagnosis in correctable_diagnoses:
            reason_code = diagnosis.get("reason_code", "") or ""
            incident_number = diagnosis.get("incident_number")
            if incident_number and (incident_number, "approval") in existing_keys:
                logger.info(
                    "[HITL] Approval notification already exists for %s — skipping (resume)",
                    incident_number,
                )
                continue
            correctable_rows = diagnosis.get("correctable", [])
            esns = [
                r.get("ENGINE_SERIAL_NUM")
                for r in correctable_rows
                if r.get("ENGINE_SERIAL_NUM") is not None
            ]
            n_rows = len(correctable_rows)
            priority = "high" if n_rows >= 10 else ("medium" if n_rows else "low")
            try:
                notification_service.create_notification(
                    type="approval",
                    message=(
                        f"SOP fix for '{reason_code}'"
                        + (f" ({incident_number})" if incident_number else "")
                        + f" — {n_rows} correctable row(s) — requires your approval"
                    ),
                    requested_by=user_id,
                    assignee=user_id,
                    incident_number=incident_number,
                    summary_markdown=format_incident_hitl_summary([diagnosis]),
                    payload={
                        "group_id": group_id,
                        "thread_id": thread_id,
                        "reason_code": reason_code,
                        "incident_number": incident_number,
                        "sys_id": diagnosis.get("sys_id"),
                        "esns": esns,
                        "correctable": correctable_rows,
                        "total_incidents": len(correctable_diagnoses),
                    },
                    priority=priority,
                    thread_id=thread_id,
                    interrupt_id=group_id,
                )
            except Exception:
                logger.exception(
                    "[HITL] Failed to persist per-incident notification for %s",
                    incident_number,
                )

    human_response: str = interrupt(combined_summary)
    logger.info("[HITL] Interrupt resumed — response: %r", str(human_response)[:120])

    parsed = _parse_hitl_decision(str(human_response), get_bedrock_llm("supervisor"))
    logger.info("[HITL] Decision parsed — %s / %s", parsed.get("decision"), parsed.get("approved_esns"))
    decision = parsed.get("decision")
    if decision in ("all", "partial"):
        next_hint = "NEXT: call apply_corrections immediately (no text)."
    elif decision == "none":
        next_hint = "NEXT: output 'Pipeline cancelled — no changes were made.' and STOP."
    else:
        next_hint = "NEXT: ask the user to reply with yes, no, or specific ESN numbers."
    return Command(update={
        "hitl_decision": parsed,
        "messages": [ToolMessage(
            f"Human decision: {decision}. {next_hint}",
            tool_call_id=tool_call_id,
        )],
    })


@tool
def apply_corrections(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Apply approved SOP corrections and resolve all incidents (Agent 3b).

    Reads sop_diagnoses / tickets / hitl_decision from state. Idempotent — the
    corrections_applied flag in state prevents duplicate application. No arguments."""
    from agent_server.agents.remediation.agent import get_agent3b

    if state.get("corrections_applied"):
        logger.warning("[AGENT3b] apply_corrections already ran for this thread — no-op")
        return Command(update={
            "messages": [ToolMessage(
                "apply_corrections already ran (status ALREADY_DONE). "
                "NEXT: output the final '## ✅ Pipeline Complete' summary and STOP.",
                tool_call_id=tool_call_id,
            )],
        })

    from agent_server.knowledge.outfile_repository import set_outfile_source

    set_outfile_source(state.get("outfile_source"))

    sop_diagnoses: list[dict] = state.get("sop_diagnoses", []) or []
    recommended_diagnoses: list[dict] = (
        state.get("recommended_diagnoses", []) or []
    )
    actionable_diagnoses = [*sop_diagnoses, *recommended_diagnoses]
    tickets: list[dict] = state.get("tickets", []) or []

    manual_review_codes = {
        diagnosis.get("reason_code")
        for diagnosis in actionable_diagnoses
        if diagnosis.get("status") == "manual_review_required"
    }

    decision = state.get("hitl_decision") or {}
    approved_esns = decision.get("approved_esns")
    # Per-incident gate: resolve ONLY the incidents the user approved. Rejected
    # incidents are skipped — their ServiceNow ticket stays open for manual review.
    approved_incidents = decision.get("approved_incidents")
    tickets_to_resolve = [
        ticket for ticket in tickets
        if ticket.get("reason_code") not in manual_review_codes
        and (
            approved_incidents is None
            or ticket.get("incident_number") in approved_incidents
        )
    ]
    logger.info(
        "[AGENT3b] apply_corrections — decision=%s sop=%d recommendations=%d tickets=%d",
        decision.get("decision", "unknown"),
        len(sop_diagnoses),
        len(recommended_diagnoses),
        len(tickets),
    )

    try:
        agent3b = get_agent3b()
        result = agent3b.invoke({
            "messages": [HumanMessage(content="Apply the approved corrections and resolve all tickets.")],
            "sop_diagnoses": actionable_diagnoses,
            "approved_esns": approved_esns,
            "tickets": tickets_to_resolve,
        })
        apply_result = result.get("apply_result") or {}
        resolved_tickets = result.get("resolved_tickets") or []
    except Exception as exc:
        logger.exception("[AGENT3b] Agent 3b failed")
        apply_result = {"status": "ERROR", "error": str(exc), "updates": []}
        resolved_tickets = []

    corrections = len(apply_result.get("updates") or [])
    resolved_ok = sum(1 for t in resolved_tickets if t.get("status") != "error")
    source_issues = sum(len(d.get("source_issues") or []) for d in actionable_diagnoses)
    rca_count = len(state.get("rca_results") or [])
    summary_msg = (
        f"apply_result.status={apply_result.get('status')} | buckets={len(tickets)} "
        f"| corrections_applied={corrections} | incidents_resolved={resolved_ok} "
        f"| source_issues={source_issues} | rca_analyses={rca_count}. "
        "This is the FINAL step — output the '## ✅ Pipeline Complete' summary and STOP."
    )
    logger.info("[AGENT3b] %s", summary_msg)
    return Command(update={
        "corrections_applied": True,
        "apply_result": apply_result,
        "resolved_tickets": resolved_tickets,
        "messages": [ToolMessage(summary_msg, tool_call_id=tool_call_id)],
    })


@tool
def answer_question(question: str, config: RunnableConfig) -> str:
    """Answer a question about SOPs, incidents, notifications, or the AiDQ process.

    Delegates to Agent 4 (General QA) which has access to:
    - Historical incident stats + semantic search (past ServiceNow incidents)
    - SOP summaries AND full SOP steps/body
    - Operational incidents raised by the AiDQ pipeline (open/high-priority, by id)
    - The current user's notification inbox (pending approvals, reviews, information)

    Args:
        question: the user's question verbatim

    Returns a factual, cited answer.
    Use this for any question that is NOT a request to run the remediation pipeline —
    including "what's pending my approval?", "show my notifications", "what incidents
    are open?", and "show me the full steps for SOP-001".
    """
    from agent_server.agents.general_qa.agent import get_agent4

    logger.info("[AGENT4] answer_question — question: %r", question[:120])
    try:
        agent4 = get_agent4()
        result = agent4.invoke(
            {"messages": [HumanMessage(content=question)]},
            config=config,
        )
        answer = _extract_last_ai_text(result)
        logger.info("[AGENT4] Answer ready — %d chars", len(answer))
        return answer
    except Exception as exc:
        logger.exception("[AGENT4] Agent 4 failed with exception")
        return f"I was unable to answer your question due to an error: {exc}"
