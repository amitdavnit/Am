"""Supervisor routing — LLM-guided intent classification with deterministic bypass."""
