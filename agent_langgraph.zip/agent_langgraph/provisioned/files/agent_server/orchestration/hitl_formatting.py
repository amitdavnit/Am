"""HITL summary formatting — fully deterministic table + narrative builders."""

from __future__ import annotations

from typing import Any


# ─────────────────────────────────────────────────────────────────────────────
# Section formatters (deterministic — retained unchanged)
# ─────────────────────────────────────────────────────────────────────────────

def format_sop_section(diagnosis: dict[str, Any]) -> list[str]:
    lines = [
        f"### {diagnosis.get('sop_no', 'SOP-???')} — {diagnosis['reason_code']}",
        f"**Tool:** `{diagnosis.get('tool_name', diagnosis.get('tool_name', 'unknown'))}`  |  "
        f"**Total records:** {diagnosis['total_records']}  |  "
        f"Correctable: {len(diagnosis['correctable'])}  |  "
        f"Source issues: {len(diagnosis['source_issues'])}  |  "
        f"No source: {len(diagnosis['no_source'])}",
    ]

    if diagnosis["correctable"]:
        lines.extend(
            [
                "",
                "| ENGINE_SERIAL_NUM | Column | Current | Source |",
                "|---|---|---|---|",
            ]
        )
        for row in diagnosis["correctable"]:
            for col, vals in row["differences"].items():
                lines.append(
                    f"| {row['ENGINE_SERIAL_NUM']} | {col} | "
                    f"{vals['error_value']} | {vals['source_value']} |"
                )

    if diagnosis["source_issues"]:
        lines.append("")
        lines.append("**Source issues (no auto-fix):**")
        for row in diagnosis["source_issues"]:
            lines.append(f"- ESN {row['ENGINE_SERIAL_NUM']}: {row.get('message', 'same invalid values')}")

    if diagnosis["no_source"]:
        lines.append("")
        lines.append("**No source record:**")
        for row in diagnosis["no_source"]:
            lines.append(f"- ESN {row['ENGINE_SERIAL_NUM']}: {row.get('message', 'no source record found')}")

    if diagnosis.get("status") == "manual_review_required":
        lines.extend(
            [
                "",
                "**Guided review procedure:**",
                "",
                diagnosis.get("procedure", "Follow the referenced SOP document."),
            ]
        )

    return lines


def format_rca_section(result: dict[str, Any]) -> list[str]:
    lines = [f"### {result['reason_code']}"]
    if result.get("incident_number"):
        lines.append(f"**Incident:** {result['incident_number']}")

    # Top similar incidents from vector DB semantic search
    similar = result.get("similar_incidents", [])
    if similar:
        lines += [
            "",
            "**Top Matching Historical Incidents (semantic search):**",
            "",
            "| # | Incident | Confidence | State | Resolved |",
            "|---|---|---|---|---|",
        ]
        for i, inc in enumerate(similar[:3], 1):
            inc_num = inc.get("incident_number", "N/A")
            confidence = inc.get("confidence", 0)
            state = inc.get("state", "—")
            resolved = inc.get("resolved_date", "—")
            lines.append(f"| {i} | {inc_num} | {confidence}% | {state} | {resolved} |")

    lines.extend(["", result.get("rca_narrative", result.get("answer", ""))])
    recommendation = result.get("actionable_diagnosis") or {}
    if recommendation.get("correctable"):
        lines += [
            "",
            "**Lookup-backed actionable recommendation:**",
            *format_sop_section(recommendation),
        ]
    return lines


# ─────────────────────────────────────────────────────────────────────────────
# Per-step detail builders — streamed to the UI right after each step completes
# so the user sees each step's output directly below that step's confirmation.
# ─────────────────────────────────────────────────────────────────────────────

def format_step1_detail(buckets_or_tickets: dict | list[dict[str, Any]]) -> str:
    """Step 1 output: error buckets found (incidents not created yet).

    Accepts either the buckets dict from analyze_outfile or a ticket list.
    """
    if isinstance(buckets_or_tickets, dict):
        items = [
            {"reason_code": k, "count": v.get("count", 0), "incident_number": None}
            for k, v in buckets_or_tickets.items()
        ]
        header = f"✅ STEP 1 complete. Found {len(items)} error bucket(s)."
    else:
        items = list(buckets_or_tickets)
        created = sum(1 for t in items if t.get("incident_number"))
        header = (
            f"✅ STEP 1 complete. Found {len(items)} error bucket(s) and created "
            f"{created} ServiceNow incident(s). Now running SOP diagnosis and RCA analysis..."
        )

    lines = [
        header,
        "",
        "| # | Reason Code | Records | Incident |",
        "|---|---|---|---|",
    ]
    for i, t in enumerate(items, 1):
        rc = t.get("reason_code") or t.get("category", "")
        count = t.get("count", "—")
        inc = t.get("incident_number") or "—"
        lines.append(f"| {i} | {rc} | {count} | {inc} |")
    return "\n".join(lines)


def format_incident_creation_detail(tickets: list[dict[str, Any]]) -> str:
    """Detail after create_servicenow_incidents."""
    created = sum(1 for t in tickets if t.get("incident_number"))
    lines = [
        f"✅ Incidents created. {created} ServiceNow incident(s) saved for the UI.",
        "",
        "| # | Reason Code | Records | Incident | Priority |",
        "|---|---|---|---|---|",
    ]
    for i, t in enumerate(tickets, 1):
        lines.append(
            f"| {i} | {t.get('reason_code', '')} | {t.get('count', '—')} | "
            f"{t.get('incident_number') or '—'} | {t.get('priority', '—')} |"
        )
    failed = [t for t in tickets if t.get("error") and not t.get("incident_number")]
    if failed:
        lines.append("")
        lines.append(f"> ⚠️ {len(failed)} incident creation(s) failed and were skipped.")
    return "\n".join(lines)


def format_incident_creation_hitl(
    *,
    buckets: dict[str, Any],
    outfile_source: str,
) -> str:
    """HITL prompt asking the user to approve creating ServiceNow incidents."""
    total = sum(int(v.get("count", 0)) for v in buckets.values())
    lines: list[str] = [
        "## 🛎️ Approve ServiceNow Incident Creation",
        "",
        f"**Source:** `{outfile_source or 'default outfile'}`",
        f"**Buckets:** {len(buckets)}",
        f"**Total error records:** {total}",
        "",
        "The agent is ready to create the following ServiceNow incidents:",
        "",
        "| # | Reason Code | Records | Proposed Priority |",
        "|---|---|---|---|",
    ]
    for i, (reason_code, data) in enumerate(buckets.items(), 1):
        count = int(data.get("count", 0))
        priority = "Critical" if count > 10 else ("High" if count > 5 else "Medium")
        lines.append(f"| {i} | {reason_code} | {count} | {priority} |")
    lines += [
        "",
        "**Create these ServiceNow incidents?**",
        "- Reply `yes` / Approve to create them (they will also appear in the Incidents UI)",
        "- Reply `no` / Reject to cancel the pipeline without creating incidents",
    ]
    return "\n".join(lines)


def format_step2_detail(data: dict[str, Any]) -> str:
    """Step 2 output: SOP diagnosis results + RCA analysis for no-SOP buckets.

    ``data`` is the JSON object returned by run_all_remediations:
    {sop_diagnoses: [...], rca_results: [...], tickets: [...]}
    """
    sop_diagnoses = data.get("sop_diagnoses", [])
    rca_results = data.get("rca_results", [])
    recommendations = data.get("recommended_diagnoses", [])
    actionable = [*sop_diagnoses, *recommendations]
    total_correctable = sum(len(d.get("correctable", [])) for d in actionable)
    total_source_issues = sum(len(d.get("source_issues", [])) for d in actionable)
    total_no_source = sum(len(d.get("no_source", [])) for d in actionable)

    lines = [
        f"✅ STEP 2 complete. Diagnosis done — {len(sop_diagnoses)} SOP match(es), "
        f"{len(rca_results)} RCA analysis result(s) (no-SOP buckets).",
        "",
        f"Correctable: **{total_correctable}**  |  Source-level issues: "
        f"**{total_source_issues}**  |  No source data: **{total_no_source}**",
    ]

    if actionable:
        lines += ["", "### SOP diagnosis *(correctable rows applied on approval)*", ""]
        for diagnosis in actionable:
            lines += format_sop_section(diagnosis)
            lines.append("")

    if rca_results:
        lines += [
            "",
            "### RCA analysis *(informational only — no auto-correction)*",
            "",
        ]
        for result in rca_results:
            lines += format_rca_section(result)
            lines.append("")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Approval prompt builder — slim (the per-step detail was already shown above)
# ─────────────────────────────────────────────────────────────────────────────

def format_combined_hitl_summary(
    buckets: dict[str, Any],
    tickets: list[dict[str, Any]],
    rca_results: list[dict[str, Any]],
    sop_diagnoses: list[dict[str, Any]],
    recommended_diagnoses: list[dict[str, Any]] | None = None,
) -> str:
    """Build the HITL approval prompt.

    The per-step detail (buckets/incidents and SOP/RCA diagnosis) is now streamed
    directly under each step as it completes, so this prompt is intentionally slim:
    it only lists the rows that will actually change and asks for the decision.
    """
    actionable = [*sop_diagnoses, *(recommended_diagnoses or [])]
    total_correctable = sum(len(d.get("correctable", [])) for d in actionable)
    manual_review_count = sum(
        d.get("status") == "manual_review_required" for d in actionable
    )

    lines: list[str] = [
        "## 🛡️ Human Approval Required",
        "",
        f"**Total correctable SOP rows:** {total_correctable}",
        f"**Guided reviews requiring manual action:** {manual_review_count}",
        "",
    ]

    if total_correctable > 0:
        lines += [
            "The following row(s) will be corrected in the active outfile source on approval:",
            "",
            "| ENGINE_SERIAL_NUM | Reason Code | Column | Current | Source |",
            "|---|---|---|---|---|",
        ]
        for diagnosis in actionable:
            rc = diagnosis.get("reason_code", "")
            for row in diagnosis.get("correctable", []):
                for col, vals in row.get("differences", {}).items():
                    lines.append(
                        f"| {row['ENGINE_SERIAL_NUM']} | {rc} | {col} | "
                        f"{vals['error_value']} | {vals['source_value']} |"
                    )
        lines.append("")
    else:
        if manual_review_count:
            lines += [
                "No automatic corrections are available. Complete the guided "
                "review procedure before resolving its ServiceNow incident.",
                "",
            ]
        else:
            lines += [
                "No correctable records were found — approving will resolve the "
                "ServiceNow incidents without changing the outfile source.",
                "",
            ]

    lines += [
        "Narrative RCA text and source-level issues are informational only. "
        "Only the lookup-backed rows listed above can be changed.",
        "",
        "**Approve SOP corrections to the outfile source?**",
        "- Use **Approve** / **Reject** in chat, or reply `yes` / `no`",
        "- Reply comma-separated ENGINE_SERIAL_NUM values to apply specific rows only",
    ]

    return "\n".join(lines)


def format_incident_hitl_summary(diagnoses: list[dict[str, Any]]) -> str:
    """Build a per-incident HITL approval prompt.

    Each SOP-correctable incident is shown as its own section with its correctable
    rows. Used both for the combined chat interrupt (all incidents) and for the
    per-incident Notifications inbox row (a single diagnosis).
    """
    n = len(diagnoses)
    total_correctable = sum(len(d.get("correctable", [])) for d in diagnoses)
    lines: list[str] = [
        "## 🛡️ Human Approval Required",
        "",
        f"**Incident(s) with SOP-correctable rows:** {n}",
        f"**Total correctable rows:** {total_correctable}",
        "",
    ]

    for diagnosis in diagnoses:
        reason_code = diagnosis.get("reason_code", "")
        incident_number = diagnosis.get("incident_number") or "—"
        sop_no = diagnosis.get("sop_no", "SOP-???")
        correctable = diagnosis.get("correctable", [])
        lines += [
            f"### {incident_number} · {reason_code}  ({sop_no})",
            f"Correctable rows: {len(correctable)}",
            "",
            "| ENGINE_SERIAL_NUM | Column | Current | Source |",
            "|---|---|---|---|",
        ]
        for row in correctable:
            for col, vals in row.get("differences", {}).items():
                lines.append(
                    f"| {row['ENGINE_SERIAL_NUM']} | {col} | "
                    f"{vals['error_value']} | {vals['source_value']} |"
                )
        lines.append("")

    lines += [
        "Approve or reject each incident — in the **Notifications / Approval** page or "
        "with the per-incident controls in chat. Corrections are applied only after "
        "**every** listed incident has been decided.",
        "",
        "- Approve an incident to apply its corrections and resolve its ServiceNow ticket.",
        "- Reject an incident to skip it (no changes; its ticket stays open for manual review).",
    ]
    return "\n".join(lines)
