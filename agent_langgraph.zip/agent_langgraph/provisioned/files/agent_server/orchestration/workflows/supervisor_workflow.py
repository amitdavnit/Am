"""Supervisor ReAct agent — top-level entry point for the AiDQ system.

Architecture:
  - create_react_agent + AsyncCheckpointSaver (durable HITL across restarts)
  - All routing decisions are LLM-driven via tool selection
  - HITL handled via interrupt() inside request_human_approval tool
  - All inter-agent data flows through message history as tool observations
"""

from __future__ import annotations

import logging
from typing import Any

from langgraph.checkpoint.memory import MemorySaver
from langgraph.prebuilt import create_react_agent

from agent_server.orchestration.supervisor.prompts import SUPERVISOR_SYSTEM_PROMPT
from agent_server.orchestration.supervisor.router import (
    SupervisorState,
    analyze_outfile,
    answer_question,
    apply_corrections,
    request_human_approval,
    run_all_remediations,
)
from agent_server.platform.checkpoint import get_checkpointer
from agent_server.platform.llm import get_bedrock_llm

logger = logging.getLogger(__name__)

_SUPERVISOR_TOOLS = [
    analyze_outfile,
    run_all_remediations,
    request_human_approval,
    apply_corrections,
    answer_question,
]

_graph: Any = None
_graph_checkpointer_id: int | None = None


def get_supervisor_graph():
    """Build and return the supervisor ReAct agent graph.

    Uses Lakebase AsyncCheckpointSaver when opened at app startup (durable HITL).
    Falls back to in-memory MemorySaver only if Lakebase is unavailable.
    """
    global _graph, _graph_checkpointer_id

    checkpointer = get_checkpointer()
    checkpointer_id = id(checkpointer) if checkpointer is not None else None

    if _graph is not None and _graph_checkpointer_id == checkpointer_id:
        return _graph

    if checkpointer is None:
        logger.warning(
            "[SUPERVISOR] No Lakebase checkpointer — using MemorySaver "
            "(HITL will NOT survive process restarts)"
        )
        checkpointer = MemorySaver()
        checkpointer_id = id(checkpointer)
        saver_label = "MemorySaver"
    else:
        saver_label = "AsyncCheckpointSaver(Lakebase)"

    logger.info(
        "[SUPERVISOR] Building supervisor graph with %d tools (%s): %s",
        len(_SUPERVISOR_TOOLS),
        saver_label,
        [t.name for t in _SUPERVISOR_TOOLS],
    )
    _graph = create_react_agent(
        model=get_bedrock_llm("supervisor"),
        tools=_SUPERVISOR_TOOLS,
        prompt=SUPERVISOR_SYSTEM_PROMPT,
        state_schema=SupervisorState,
        checkpointer=checkpointer,
    )
    _graph_checkpointer_id = checkpointer_id
    logger.info("[SUPERVISOR] Supervisor graph ready (%s)", saver_label)
    return _graph


def reset_supervisor_graph() -> None:
    """Clear cached graph so the next call rebuilds with the current checkpointer."""
    global _graph, _graph_checkpointer_id
    _graph = None
    _graph_checkpointer_id = None
