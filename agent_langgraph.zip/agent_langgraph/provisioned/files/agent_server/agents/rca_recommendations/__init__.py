"""Agent 2: RCA Recommendations package."""
from agent_server.agents.rca_recommendations.agent import get_agent2

__all__ = ["get_agent2"]
