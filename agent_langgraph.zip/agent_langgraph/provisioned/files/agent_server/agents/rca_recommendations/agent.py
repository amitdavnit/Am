"""Agent 2: RCA Recommendations — ReAct agent."""

from __future__ import annotations

import logging

from langgraph.prebuilt import create_react_agent
from agent_server.agents.rca_recommendations.tools import RcaAgentState
from agent_server.agents.rca_recommendations.tools import (
    lookup_catalog_values,
    post_work_note,
    query_catalog_table,
    search_incidents,
    synthesize_rca,
)
    
from agent_server.platform.llm import get_bedrock_llm

logger = logging.getLogger(__name__)
NAME = "rca_recommendations"


SYSTEM_PROMPT = """You are Agent 2: RCA Recommendation Agent.

You run for incidents that have NO matching SOP, so your job is analysis-only:
you explain the likely root cause and document it. You do NOT propose or apply
automatic corrections — deterministic corrections are only produced by SOP diagnosis.

Follow these steps strictly in order:
1. Call `search_incidents` to find similar historical incidents and verified learned solutions.
2. Call `synthesize_rca` to produce the root-cause-analysis narrative.
3. Call `post_work_note` to document the RCA on the ServiceNow incident.
Do not skip or reorder steps. Do not pass any arguments — the tools read what
they need from state. After the steps are done, give a one-line summary.
Never invent correction values.
`query_catalog_table` and `lookup_catalog_values` are optional read-only evidence
tools. Use them only if additional inspection is necessary; they do not replace
the required sequence.
"""
_agent = None
def get_agent2():
    global _agent
    if _agent is None:
        _agent = create_react_agent(
            model=get_bedrock_llm("rca_recommendations"),
            tools=[
                search_incidents,
                synthesize_rca,
                post_work_note,
                query_catalog_table,
                lookup_catalog_values,
            ],
            state_schema=RcaAgentState,
            prompt=SYSTEM_PROMPT,
        )
    return _agent