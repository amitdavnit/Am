"""Agent 4: General QA tools."""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from langchain_core.runnables import RunnableConfig
from langchain_core.tools import tool

from agent_server.knowledge.snow_dump_repository import (
    extract_incident_ids,
    format_stats_rows,
    get_known_categories,
    load_incidents_for_stats,
)

logger = logging.getLogger(__name__)

_INC_ID_RE = re.compile(r"\bINC\d+\b", re.IGNORECASE)


@tool
def query_incident_stats(question: str, category_filter: str = "") -> str:
    """Query structured statistics from Lakebase table aidq.incident_history.

    Use this tool for questions about counts, totals, aggregations, listings, or trends
    over historical ServiceNow incidents (e.g. 'how many incidents?', 'list all categories',
    'which category has the most incidents?').

    Args:
        question: the user's question (used for context)
        category_filter: optional category string to filter rows; if provided, only rows
                         matching this category are returned. Leave empty to get all rows.

    Returns a plain-text table of incident records (incident_number, category, state,
    created_date, resolved_date) for the LLM to analyse and answer the question."""
    logger.info("[query_incident_stats] question=%r  category_filter=%r", question[:80], category_filter)
    df = load_incidents_for_stats()
    logger.info(
        "[query_incident_stats] Loaded %d incident row(s) from Lakebase aidq.incident_history",
        len(df),
    )

    if category_filter:
        # Fuzzy match: try exact first, then substring
        exact = df[df["category"].str.strip() == category_filter.strip()]
        if not exact.empty:
            filtered = exact
            label = f'category="{category_filter}" (exact match)'
        else:
            filtered = df[df["category"].str.contains(category_filter.strip(), case=False, na=False)]
            label = f'category contains "{category_filter}" (partial match)'
        result_df = filtered if not filtered.empty else df
        prefix = (
            f"INCIDENT DATA for {label} ({len(result_df)} of {len(df)} total rows):\n"
        )
        logger.info("[query_incident_stats] Filter applied — returning %d of %d rows", len(result_df), len(df))
    else:
        result_df = df
        prefix = f"INCIDENT DATA — all {len(df)} rows:\n"
        logger.info("[query_incident_stats] No filter — returning all %d rows", len(df))

    known_cats = get_known_categories()
    categories_block = f"Known categories ({len(known_cats)}): " + ", ".join(known_cats[:20])
    if len(known_cats) > 20:
        categories_block += f" ... and {len(known_cats) - 20} more"

    return f"{categories_block}\n\n{prefix}{format_stats_rows(result_df)}"


@tool
def search_incidents_semantically(query: str, k: int = 5) -> str:
    """Semantically search historical incidents for root cause, resolution details, or similar issues.

    Use this tool for questions about root cause, how an error was resolved in the past,
    or when the user asks for similar historical incidents.
    Also use it when the user mentions specific INC numbers (e.g. INC0001234) — the tool
    will perform an exact metadata lookup for those IDs.

    Args:
        query: the user's question or search text; may contain INC IDs
        k: number of incidents to return (default 5)

    Returns a formatted text block of the most relevant historical incidents with
    their incident numbers, notes, and confidence scores."""
    from agent_server.agents.rca_recommendations.tools import (
        _format_incident_results,
        _search_incidents,
    )

    mentioned_ids = extract_incident_ids(query)
    if mentioned_ids:
        logger.info("[search_incidents_semantically] Exact lookup for INC IDs: %s", mentioned_ids)
        results = _search_incidents(query, k=k, incident_ids=mentioned_ids)
        label = "DIRECTLY REQUESTED INCIDENTS (exact lookup):"
    else:
        logger.info("[search_incidents_semantically] Semantic search: k=%d  query=%r", k, query[:80])
        results = _search_incidents(query, k=k)
        label = "SEMANTICALLY SIMILAR INCIDENTS:"

    logger.info("[search_incidents_semantically] Returning %d result(s)", len(results))
    formatted = _format_incident_results(results)
    return f"{label}\n{formatted}"


@tool
def get_sop_tools_knowledge() -> str:
    """Get live knowledge about all available SOP validation tools.

    Returns the name and description of each SOP tool defined in the remediation agent.
    Use this to answer questions about:
    - Which SOPs exist and what they validate
    - Which columns are compared for each SOP
    - Which reason codes have SOP coverage

    Returns a JSON array: [{tool_name, description}]
    This list auto-updates whenever new SOP tools are added."""
    from agent_server.agents.remediation.tools import SOP_TOOLS

    knowledge = []
    for sop_tool in SOP_TOOLS:
        knowledge.append(
            {
                "tool_name": sop_tool.name,
                "description": sop_tool.description,
            }
        )
    logger.info("[get_sop_tools_knowledge] Returning knowledge for %d SOP tool(s): %s",
                len(knowledge), [k["tool_name"] for k in knowledge])
    return json.dumps(knowledge, indent=2)


def _format_sop(sop: dict[str, Any]) -> str:
    """Render a single SOP definition (metadata + full body) as readable text."""
    reason_patterns = ", ".join(str(p) for p in sop.get("reason_patterns", []) or [])
    validated_columns = ", ".join(str(c) for c in sop.get("validated_columns", []) or [])
    lines = [
        f"SOP: {sop.get('sop_id')} — {sop.get('title')}",
        f"Execution mode: {sop.get('execution_mode', 'lookup_validation')}",
        f"Reason patterns: {reason_patterns or '(none)'}",
        f"Validated columns: {validated_columns or '(none)'}",
    ]
    if sop.get("lookup_table"):
        lines.append(f"Lookup table: {sop.get('lookup_table')} (key: {sop.get('lookup_key')})")
    lines.append("")
    lines.append("Steps / body:")
    lines.append(str(sop.get("body") or "(no body)"))
    return "\n".join(lines)


@tool
def get_sop_details(sop_id_or_reason_code: str = "") -> str:
    """Get the full content (steps/body) of one or all Standard Operating Procedures.

    Use this when the user wants the actual remediation steps, validation logic, or
    detailed instructions of an SOP — not just its name/summary (use
    get_sop_tools_knowledge for the summary list).

    Args:
        sop_id_or_reason_code: an SOP id (e.g. "SOP-001") or a reason code to match the
            most relevant SOP. Leave empty to return the full body of every SOP.

    Returns the SOP metadata plus the complete markdown body for the matched SOP(s)."""
    from agent_server.knowledge.sop_repository import load_markdown_sops, match_sop

    sops = load_markdown_sops()
    if not sops:
        logger.warning("[get_sop_details] No SOP markdown definitions found")
        return "No SOP definitions are currently available."

    query = (sop_id_or_reason_code or "").strip()
    if not query:
        logger.info("[get_sop_details] Returning all %d SOP(s)", len(sops))
        return "\n\n---\n\n".join(_format_sop(sop) for sop in sops)

    normalized = query.upper()
    for sop in sops:
        if str(sop.get("sop_id", "")).upper() == normalized:
            logger.info("[get_sop_details] Matched SOP by id: %s", sop.get("sop_id"))
            return _format_sop(sop)

    matched = match_sop(query)
    if matched:
        logger.info(
            "[get_sop_details] Matched SOP by reason code %r: %s",
            query,
            matched.get("sop_id"),
        )
        return _format_sop(matched)

    logger.info("[get_sop_details] No SOP matched %r", query)
    available = ", ".join(str(s.get("sop_id")) for s in sops)
    return (
        f"No SOP matched '{query}'. Available SOPs: {available}. "
        "Call with an empty argument to see all SOP details."
    )


@tool
def query_operational_incidents(
    status: str = "", priority: str = "", incident_id: str = ""
) -> str:
    """Query AiDQ operational incidents raised by the remediation pipeline (Lakebase aidq.incidents).

    These are the app's own operational incidents (created when the outfile-analysis
    pipeline flags a data-quality violation) — this is DIFFERENT from historical
    ServiceNow incidents (use query_incident_stats / search_incidents_semantically for
    those).

    Use this for questions like "what incidents are open?", "show high priority
    incidents", or details of a specific operational incident id.

    Args:
        status: optional status filter (e.g. "open", "closed").
        priority: optional priority filter (e.g. "high", "medium", "low").
        incident_id: optional — return the details of one specific incident id.

    Returns a formatted list (or single record) of operational incidents."""
    from api.services.incidents import (
        LakebaseStorageError,
        get_incident,
        list_incidents,
    )

    try:
        if incident_id.strip():
            logger.info("[query_operational_incidents] Lookup id=%r", incident_id)
            incident = get_incident(incident_id.strip())
            if not incident:
                return f"No operational incident found with id '{incident_id.strip()}'."
            return json.dumps(incident, indent=2, default=str)

        logger.info(
            "[query_operational_incidents] list status=%r priority=%r",
            status,
            priority,
        )
        incidents = list_incidents(
            status=status.strip() or None,
            priority=priority.strip() or None,
            limit=100,
        )
    except LakebaseStorageError as exc:
        logger.warning("[query_operational_incidents] Lakebase unavailable: %s", exc)
        return f"Operational incidents are currently unavailable: {exc}"

    if not incidents:
        return "No operational incidents found for the requested filters."

    header = f"OPERATIONAL INCIDENTS ({len(incidents)}):"
    rows = "\n".join(
        f"- {i.get('incident_id')} | {i.get('status')} | {i.get('priority')} | "
        f"{i.get('title')} | assigned_to={i.get('assigned_to')} | "
        f"created={i.get('created_date')}"
        for i in incidents
    )
    return f"{header}\n{rows}"


@tool
def query_my_notifications(tab: str = "all", config: RunnableConfig = None) -> str:
    """Query the current user's HITL notification inbox (Lakebase aidq.notifications).

    Use this for questions about the user's own pending approvals, reviews, or
    information items — e.g. "what's pending my approval?", "do I have anything to
    review?", "show my notifications".

    Args:
        tab: which inbox to read — one of "all", "for_approval", "for_review",
            "information". Defaults to "all".

    Returns a compact, formatted list of the current user's notifications."""
    from api.services.notifications import list_notifications

    configurable = (config or {}).get("configurable") or {}
    user_id = configurable.get("user_id") or "unknown"

    allowed_tabs = {"all", "for_approval", "for_review", "information"}
    tab_value = (tab or "all").strip().lower()
    if tab_value not in allowed_tabs:
        tab_value = "all"

    logger.info(
        "[query_my_notifications] user_id=%r tab=%r", user_id, tab_value
    )
    if user_id == "unknown":
        return (
            "Could not determine the current user, so notifications cannot be listed. "
            "This tool only works within an authenticated chat session."
        )

    items = list_notifications(assignee=user_id, tab=tab_value, limit=50)
    if not items:
        return f"No notifications found for you in the '{tab_value}' inbox."

    header = f"YOUR NOTIFICATIONS — {tab_value} ({len(items)}):"
    rows = "\n".join(
        f"- [{n.get('type')}/{n.get('status')}] priority={n.get('priority')} | "
        f"{n.get('message')} | incident={n.get('incident_number')} | "
        f"requested_on={n.get('requested_on')}"
        for n in items
    )
    return f"{header}\n{rows}"
