"""Agent 3a / 3b: Remediation package."""
from agent_server.agents.remediation.agent import get_agent3a, get_agent3b

__all__ = ["get_agent3a", "get_agent3b"]
