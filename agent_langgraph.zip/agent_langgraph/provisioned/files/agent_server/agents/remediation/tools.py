"""Agent 3a / 3b: Remediation tools — SOP diagnosis, corrections, and ServiceNow resolution."""

from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any
import pandas as pd
from langchain_core.tools import tool

from agent_server.knowledge.outfile_repository import apply_corrections, backup_outfile, load_outfile
from agent_server.knowledge.servicenow_repository import resolve_incident, update_work_notes
from agent_server.knowledge.source_repository import load_source
from agent_server.knowledge.sop_repository import match_sop, query_table
from agent_server.platform.llm import get_bedrock_llm
from typing import Annotated

from langchain_core.messages import ToolMessage
from langchain_core.tools import tool, InjectedToolCallId
from langgraph.prebuilt import InjectedState
from langgraph.prebuilt.chat_agent_executor import AgentState
from langgraph.types import Command
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------



def _normalize_value(value: Any) -> Any:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value

def _compare_columns(
    reason_code: str,
    columns: list[str],
    esns: list[int] | None = None,
    lookup_table_name: str = "workspace.aidq.source_reference",
    lookup_key: str = "ENGINE_SERIAL_NUM",
) -> dict[str, Any]:
    """Compare outfile vs source_reference for the given columns, restricted to `esns`.

    ESNs come from the Step-1 bucket. The outfile is filtered with a boolean ``isin``
    mask (tolerates duplicate ENGINE_SERIAL_NUM rows), and the source is looked up by
    its unique ESN index. One cached read of each file per pipeline run.
    """
    empty = {
        "reason_code": reason_code,
        "total_records": 0,
        "correctable": [],
        "source_issues": [],
        "no_source": [],
    }

    # Normalize + dedupe incoming ESNs to ints (preserve order)
    esn_ints: list[int] = []
    seen: set[int] = set()
    for e in esns or []:
        try:
            ei = int(e)
        except (TypeError, ValueError):
            continue
        if ei not in seen:
            seen.add(ei)
            esn_ints.append(ei)

    logger.info("[_compare_columns] reason_code=%r columns=%s esns=%d", reason_code, columns, len(esn_ints))
    if not esn_ints:
        logger.warning("[_compare_columns] No ESNs supplied for reason_code=%r — returning empty result", reason_code)
        return empty

    out = load_outfile()
    if lookup_table_name == "workspace.aidq.source_reference":
        src = load_source()
    else:
        src = query_table(
            lookup_table_name,
            columns=list(dict.fromkeys([lookup_key, *columns])),
        )
    out.columns = out.columns.str.strip()
    src.columns = src.columns.str.strip()
    out["ENGINE_SERIAL_NUM"] = pd.to_numeric(
        out["ENGINE_SERIAL_NUM"], errors="coerce"
    ).astype("Int64")
    src[lookup_key] = pd.to_numeric(
        src[lookup_key], errors="coerce"
    ).astype("Int64")
    src = src.set_index(lookup_key, drop=False)

    # Only compare columns present in BOTH files
    compare_cols = [c for c in columns if c in out.columns and c in src.columns]

    # Boolean filter — safe even if an ESN appears on multiple outfile rows
    esn_set = set(esn_ints)
    error_df = out[out["ENGINE_SERIAL_NUM"].isin(esn_set)]

    correctable: list[dict] = []
    source_issues: list[dict] = []
    no_source: list[dict] = []
    processed = 0

    for rec in error_df.to_dict("records"):
        esn_raw = rec.get("ENGINE_SERIAL_NUM")
        if pd.isna(esn_raw):
            continue
        esn = int(esn_raw)
        processed += 1

        # Source lookup by unique ESN index
        if esn not in src.index:
            no_source.append({
                "ENGINE_SERIAL_NUM": esn,
                "status": "NO_SOURCE",
                "message": "No source record found for this ENGINE_SERIAL_NUM",
            })
            continue
        src_row = src.loc[esn]

        # No source data for the compared columns → treat as no_source
        source_vals = [src_row.get(c) for c in compare_cols]
        if all(pd.isna(v) for v in source_vals):
            no_source.append({
                "ENGINE_SERIAL_NUM": esn,
                "status": "NO_SOURCE",
                "message": "No source values for the compared columns",
            })
            continue

        differences: dict[str, dict] = {}
        same_values: dict[str, dict] = {}
        for col in compare_cols:
            error_val = _normalize_value(rec.get(col))
            source_val = _normalize_value(src_row.get(col))
            if error_val != source_val:
                differences[col] = {"error_value": error_val, "source_value": source_val}
            else:
                same_values[col] = {"value": error_val}

        if differences:
            correctable.append({
                "ENGINE_SERIAL_NUM": esn,
                "status": "CORRECTABLE",
                "differences": differences,
                "message": "Source has different values — correction available",
            })
        else:
            source_issues.append({
                "ENGINE_SERIAL_NUM": esn,
                "status": "SOURCE_ISSUE",
                "same_values": same_values,
                "message": "Source has same invalid values — escalation needed",
            })

    logger.info(
        "[_compare_columns] reason_code=%r — total=%d correctable=%d source_issues=%d no_source=%d",
        reason_code, processed, len(correctable), len(source_issues), len(no_source),
    )
    return {
        "reason_code": reason_code,
        "total_records": processed,
        "correctable": correctable,
        "source_issues": source_issues,
        "no_source": no_source,
    }
# ---------------------------------------------------------------------------
# SOP validation tools — Agent 3a uses these for diagnosis
# SOP behavior is declared in aidq-sop-knowledgebase/sops/*.md. The generic
# tool resolves the matching definition and performs an allowlisted lookup.
# ---------------------------------------------------------------------------
@tool
def validate_markdown_sop(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Match the reason code to an SOP Markdown definition and validate its columns.

    This generic tool reads reason_code and ESNs from state and finds the best
    active definition in aidq-sop-knowledgebase/sops. Lookup-validation SOPs
    return deterministic correction candidates; guided-review SOPs return the
    required references and procedure without modifying data. Call this first
    for every diagnosis. If nothing matches, it records status=no_sop_match."""
    reason_code = state.get("reason_code", "") or ""
    esns = state.get("esns", []) or []
    sop = match_sop(reason_code)
    if not sop:
        diagnosis = {"status": "no_sop_match", "reason_code": reason_code}
        message = "No active Markdown SOP matches this reason code."
    elif sop.get("execution_mode") == "guided_review":
        unique_esns: list[int] = []
        for esn in esns:
            try:
                normalized_esn = int(esn)
            except (TypeError, ValueError):
                continue
            if normalized_esn not in unique_esns:
                unique_esns.append(normalized_esn)
        diagnosis = {
            "status": "manual_review_required",
            "reason_code": reason_code,
            "total_records": len(unique_esns),
            "correctable": [],
            "source_issues": [
                {
                    "ENGINE_SERIAL_NUM": esn,
                    "status": "MANUAL_REVIEW",
                    "message": (
                        f"Follow {sop['sop_id']} guided review before changing "
                        "or recycling this engine record."
                    ),
                }
                for esn in unique_esns
            ],
            "no_source": [],
            "sop_no": sop["sop_id"],
            "sop_title": sop["title"],
            "tool_name": "validate_markdown_sop",
            "validated_columns": sop["validated_columns"],
            "reference_tables": sop.get("reference_tables", []),
            "procedure": sop["body"],
            "knowledge_source": "markdown_sop",
        }
        message = (
            f"{sop['sop_id']} matched — guided review required for "
            f"{len(unique_esns)} record(s)."
        )
    elif sop.get("execution_mode") == "computed_fill":
        fill_columns = [str(column) for column in sop["validated_columns"]]
        strategy = str(sop.get("fill_strategy", "current_year"))

        esn_ints: list[int] = []
        seen: set[int] = set()
        for esn in esns:
            try:
                ei = int(esn)
            except (TypeError, ValueError):
                continue
            if ei not in seen:
                seen.add(ei)
                esn_ints.append(ei)

        out = load_outfile()
        out.columns = out.columns.str.strip()
        out["ENGINE_SERIAL_NUM"] = pd.to_numeric(
            out["ENGINE_SERIAL_NUM"], errors="coerce"
        ).astype("Int64")
        error_df = out[out["ENGINE_SERIAL_NUM"].isin(set(esn_ints))]

        if strategy == "current_year":
            fill_value: Any = datetime.now().year
        else:
            fill_value = sop.get("fill_value")

        present_columns = [c for c in fill_columns if c in out.columns]
        correctable: list[dict] = []
        source_issues: list[dict] = []
        for rec in error_df.to_dict("records"):
            esn_raw = rec.get("ENGINE_SERIAL_NUM")
            if pd.isna(esn_raw):
                continue
            esn = int(esn_raw)
            differences: dict[str, dict] = {}
            for col in present_columns:
                if _normalize_value(rec.get(col)) is None:
                    differences[col] = {
                        "error_value": None,
                        "source_value": fill_value,
                    }
            if differences:
                correctable.append({
                    "ENGINE_SERIAL_NUM": esn,
                    "status": "CORRECTABLE",
                    "differences": differences,
                    "message": f"Null value — fill via {strategy}",
                })
            else:
                source_issues.append({
                    "ENGINE_SERIAL_NUM": esn,
                    "status": "ALREADY_POPULATED",
                    "message": "Value already present — no fill required",
                })

        diagnosis = {
            "reason_code": reason_code,
            "total_records": len(error_df),
            "correctable": correctable,
            "source_issues": source_issues,
            "no_source": [],
            "sop_no": sop["sop_id"],
            "sop_title": sop["title"],
            "tool_name": "validate_markdown_sop",
            "validated_columns": sop["validated_columns"],
            "fill_strategy": strategy,
            "knowledge_source": sop.get("knowledge_source", "markdown_sop"),
        }
        message = (
            f"{sop['sop_id']} diagnosis — total={diagnosis['total_records']}, "
            f"correctable={len(correctable)}."
        )
    else:
        diagnosis = _compare_columns(
            reason_code,
            [str(column) for column in sop["validated_columns"]],
            esns,
            lookup_table_name=str(sop["lookup_table"]),
            lookup_key=str(sop["lookup_key"]),
        )
        diagnosis.update(
            {
                "sop_no": sop["sop_id"],
                "sop_title": sop["title"],
                "tool_name": "validate_markdown_sop",
                "lookup_table": sop["lookup_table"],
                "lookup_key": sop["lookup_key"],
                "validated_columns": sop["validated_columns"],
                "knowledge_source": sop.get("knowledge_source", "markdown_sop"),
            }
        )
        message = (
            f"{sop['sop_id']} diagnosis — total={diagnosis['total_records']}, "
            f"correctable={len(diagnosis['correctable'])}."
        )
    return Command(
        update={
            "diagnosis": diagnosis,
            "messages": [ToolMessage(message, tool_call_id=tool_call_id)],
        }
    )


@tool
def validate_payment_account_combo(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """SOP-001: Validate PROGRAM_PAYMENT_CODE and PROGRAM_ACCOUNT_CODE against source reference.

    Use when the reason code mentions PROGRAM_PAYMENT_CODE, PROGRAM_ACCOUNT_CODE, or an
    invalid combination of payment and account codes. Takes no arguments — reads reason_code
    from state."""
    reason_code = state.get("reason_code", "") or ""
    esns = state.get("esns", []) or []
    logger.info("[SOP-001] validate_payment_account_combo for reason_code=%r (%d esn)", reason_code, len(esns))
    result = _compare_columns(reason_code, ["PROGRAM_PAYMENT_CODE", "PROGRAM_ACCOUNT_CODE"], esns)
    result["sop_no"] = "SOP-001"
    result["tool_name"] = "validate_payment_account_combo"
    return Command(update={
        "diagnosis": result,
        "messages": [ToolMessage(
            f"SOP-001 diagnosis — total={result['total_records']}, correctable={len(result['correctable'])}.",
            tool_call_id=tool_call_id,
        )],
    })
    
@tool
def validate_engine_system_component(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """SOP-002: Validate ENGINE_SYSTEM_CODE and ENGINE_COMPONENT_CODE against source reference.

    Use this tool when the reason code mentions ENGINE_SYSTEM_CODE, ENGINE_COMPONENT_CODE,
    or describes an invalid FE ET combination of engine system and component codes.

    Compares ENGINE_SYSTEM_CODE and ENGINE_COMPONENT_CODE in Unity Catalog table
    workspace.aidq.outfile against workspace.aidq.source_reference for each
    ENGINE_SERIAL_NUM.

    Takes no arguments — the reason_code is read from agent state. Call this when the
    reason code matches the columns above."""
    reason_code = state.get("reason_code", "") or ""
    esns = state.get("esns", []) or []
    logger.info("[SOP-002] validate_engine_system_component for reason_code=%r (%d esn)", reason_code, len(esns))
    result = _compare_columns(reason_code, ["ENGINE_SYSTEM_CODE", "ENGINE_COMPONENT_CODE"], esns)
    result["sop_no"] = "SOP-002"
    result["tool_name"] = "validate_engine_system_component"
    logger.info(
        "[SOP-002] Result — total=%s  correctable=%d  source_issues=%d  no_source=%d",
        result["total_records"], len(result["correctable"]), len(result["source_issues"]), len(result["no_source"]),
    )
    return Command(update={
        "diagnosis": result,
        "messages": [ToolMessage(
            f"SOP-002 diagnosis — total={result['total_records']}, "
            f"correctable={len(result['correctable'])}, source_issues={len(result['source_issues'])}.",
            tool_call_id=tool_call_id,
        )],
    })

# SOP_TOOLS — the ReAct agent receives a stable generic tool while behavior is
# added or changed through Markdown definitions.
SOP_TOOLS = [validate_markdown_sop]


# ---------------------------------------------------------------------------
# Shared work note tool — used by both Agent 3a (diagnosis) and Agent 3b (apply)
# ---------------------------------------------------------------------------

@tool
def update_servicenow_work_note(sys_id: str, work_note_content: str) -> str:
    """Post a work note to a ServiceNow incident.

    Args:
        sys_id: the ServiceNow sys_id of the incident (NOT the INCxxxxxxx number).
                If empty, null, or "None", the call is skipped and a 'skipped' status is returned.
        work_note_content: the text to post as a work note

    Returns JSON: {sys_id, status, error}"""
    if not sys_id or sys_id in ("None", "null", "undefined"):
        logger.info("[update_servicenow_work_note] sys_id=%r — skipping (not available)", sys_id)
        return json.dumps({"sys_id": sys_id, "status": "skipped",
                           "error": "sys_id not available — work note will be posted when ServiceNow is online"})
    logger.info("[update_servicenow_work_note] Posting work note to sys_id=%s (%d chars)", sys_id, len(work_note_content))
    result = update_work_notes(sys_id, work_note_content)
    logger.info("[update_servicenow_work_note] Result for sys_id=%s: %s", sys_id, result)
    return json.dumps(result)


# ---------------------------------------------------------------------------
# Apply corrections — Agent 3b only
# ---------------------------------------------------------------------------

# @tool
# def apply_sop_corrections(sop_diagnoses_json: str, approved_esns_json: str) -> str:
#     """Apply SOP corrections to the Unity Catalog outfile table for approved ESNs.

#     DETERMINISTIC: always writes the source_value from the diagnosis result.
#     The LLM never decides the correction value.
#     Calls backup_outfile() before any write.

#     Args:
#         sop_diagnoses_json: JSON array of SOP diagnosis dicts from run_all_remediations,
#                             each containing {reason_code, correctable: [{ENGINE_SERIAL_NUM, differences}]}
#         approved_esns_json: JSON array of approved ENGINE_SERIAL_NUM integers,
#                             or the string "all" to approve every correctable record

#     Returns JSON: {status, message, backup_path, updates: [{ENGINE_SERIAL_NUM, reason_code, column, old_value, new_value}]}"""
#     try:
#         diagnoses: list[dict] = json.loads(sop_diagnoses_json)
#     except (json.JSONDecodeError, TypeError) as exc:
#         return json.dumps({"status": "ERROR", "message": f"Invalid sop_diagnoses_json: {exc}", "updates": []})

#     approved_esns: list[int] | None
#     if approved_esns_json == "all":
#         approved_esns = None  # None means approve all
#     else:
#         try:
#             approved_esns = [int(x) for x in json.loads(approved_esns_json)]
#         except (json.JSONDecodeError, TypeError, ValueError) as exc:
#             return json.dumps({"status": "ERROR", "message": f"Invalid approved_esns_json: {exc}", "updates": []})

#     all_updates: list[dict] = []
#     for diagnosis in diagnoses:
#         correctable = diagnosis.get("correctable", [])
#         if approved_esns is not None:
#             approved_set = set(approved_esns)
#             correctable = [r for r in correctable if r["ENGINE_SERIAL_NUM"] in approved_set]
#         for record in correctable:
#             for col, vals in record.get("differences", {}).items():
#                 all_updates.append(
#                     {
#                         "ENGINE_SERIAL_NUM": record["ENGINE_SERIAL_NUM"],
#                         "reason_code": diagnosis.get("reason_code", ""),
#                         "column": col,
#                         "old_value": vals["error_value"],
#                         "new_value": vals["source_value"],
#                     }
#                 )

#     if not all_updates:
#         logger.info("[apply_sop_corrections] No correctable records to update — nothing applied")
#         return json.dumps(
#             {"status": "NO_CORRECTIONS", "message": "No correctable records to update.", "updates": []}
#         )

#     logger.info("[apply_sop_corrections] Applying %d correction(s) — backing up outfile first", len(all_updates))
#     for u in all_updates:
#         logger.info(
#             "[apply_sop_corrections]   ESN=%s  reason_code=%r  column=%s  %r → %r",
#             u["ENGINE_SERIAL_NUM"], u["reason_code"], u["column"], u["old_value"], u["new_value"],
#         )
#     backup_path = backup_outfile()
#     logger.info("[apply_sop_corrections] Backup saved to %s", backup_path)
#     outfile_df = load_outfile()

#     for update in all_updates:
#         mask = (outfile_df["ENGINE_SERIAL_NUM"] == update["ENGINE_SERIAL_NUM"]) & (
#             outfile_df["REASON_CODE"] == update["reason_code"]
#         )
#         outfile_df.loc[mask, update["column"]] = update["new_value"]

#     save_outfile(outfile_df)
#     logger.info("[apply_sop_corrections] Applied %d correction(s) to workspace.aidq.outfile; backup at %s", len(all_updates), backup_path)

#     return json.dumps(
#         {
#             "status": "SUCCESS",
#             "message": f"Applied {len(all_updates)} correction(s) to {OUTFILE_PATH.name}.",
#             "backup_path": str(backup_path),
#             "updates": all_updates,
#         },
#         default=str,
#     )


# @tool
# def resolve_servicenow_ticket(sys_id: str, context_json: str) -> str:
#     """Resolve a ServiceNow incident with an LLM-generated close note.

#     Args:
#         sys_id: ServiceNow sys_id of the incident to resolve
#         context_json: JSON object describing the resolution context —
#                       include reason_code, corrections_applied count, and any relevant details

#     Returns JSON: {sys_id, status, error}"""
#     logger.info("[resolve_servicenow_ticket] Resolving sys_id=%s — generating close note via LLM", sys_id)
#     llm = get_bedrock_llm()
#     close_prompt = (
#         "Write a brief, professional ServiceNow incident resolution note based on the following context.\n\n"
#         f"Resolution Context:\n{context_json}\n\n"
#         "Write 2-3 sentences describing: what data quality issue was found, "
#         "what corrections were applied, and that the incident is now resolved. "
#         "Do not use markdown."
#     )
#     try:
#         resp = llm.invoke(close_prompt)
#         close_note = resp.content if hasattr(resp, "content") else str(resp)
#         if isinstance(close_note, list):
#             close_note = "".join(b.get("text", "") for b in close_note if isinstance(b, dict))
#         logger.info("[resolve_servicenow_ticket] Close note ready (%d chars) for sys_id=%s", len(str(close_note)), sys_id)
#     except Exception:
#         logger.warning("[resolve_servicenow_ticket] LLM close note failed — using fallback text for sys_id=%s", sys_id, exc_info=True)
#         close_note = f"Automated DQ remediation applied. Context: {context_json[:200]}"

#     result = resolve_incident(sys_id, str(close_note), close_code="Solution provided")
#     logger.info("[resolve_servicenow_ticket] Resolve result for sys_id=%s: %s", sys_id, result)
#     return json.dumps(result)





class Agent3aState(AgentState):
    reason_code: str
    sys_id: str
    incident_number: str
    esns: list
    diagnosis: dict
    work_note_status: str


class Agent3bState(AgentState):
    sop_diagnoses: list
    approved_esns: list | None
    tickets: list
    apply_result: dict
    resolved_tickets: list


def _build_diagnosis_note(diagnosis: dict) -> str:
    correctable = diagnosis.get("correctable", [])
    correctable_esns = [r.get("ENGINE_SERIAL_NUM") for r in correctable]
    return "\n".join([
        "[Automated SOP Diagnosis]",
        f"SOP: {diagnosis.get('sop_no', 'N/A')} ({diagnosis.get('tool_name', 'N/A')})",
        f"Reason code: {diagnosis.get('reason_code', '')}",
        f"Total records: {diagnosis.get('total_records', 0)}",
        f"Correctable: {len(correctable)} — ESNs: {correctable_esns}",
        f"Source issues (escalate): {len(diagnosis.get('source_issues', []))}",
        f"No source record: {len(diagnosis.get('no_source', []))}",
    ])
    
    
def _apply_corrections_core(diagnoses: list[dict], approved_esns: list[int] | None) -> dict:
    """Deterministically apply corrections. approved_esns=None means approve all."""
    all_updates: list[dict] = []
    for diagnosis in diagnoses:
        correctable = diagnosis.get("correctable", [])
        if approved_esns is not None:
            approved_set = set(approved_esns)
            correctable = [r for r in correctable if r["ENGINE_SERIAL_NUM"] in approved_set]
        for record in correctable:
            for col, vals in record.get("differences", {}).items():
                all_updates.append({
                    "ENGINE_SERIAL_NUM": record["ENGINE_SERIAL_NUM"],
                    "reason_code": diagnosis.get("reason_code", ""),
                    "column": col,
                    "old_value": vals["error_value"],
                    "new_value": vals["source_value"],
                })
    if not all_updates:
        logger.info("[apply] No correctable records — nothing applied")
        return {"status": "NO_CORRECTIONS", "message": "No correctable records to update.", "updates": []}

    logger.info("[apply] Applying %d correction(s) — backing up first", len(all_updates))
    backup_path = backup_outfile()
    apply_corrections(all_updates)
    logger.info("[apply] Applied %d correction(s); backup at %s", len(all_updates), backup_path)
    return {
        "status": "SUCCESS",
        "message": f"Applied {len(all_updates)} correction(s) to the outfile table.",
        "backup_path": str(backup_path),
        "updates": all_updates,
    }


def verify_applied_updates(updates: list[dict[str, Any]]) -> dict[str, Any]:
    """Re-read the outfile table and verify every proposed value was persisted."""
    if not updates:
        return {
            "status": "NO_UPDATES",
            "verified": True,
            "checked": 0,
            "failures": [],
        }
    frame = load_outfile()
    failures: list[dict[str, Any]] = []
    for update in updates:
        mask = frame["ENGINE_SERIAL_NUM"] == update["ENGINE_SERIAL_NUM"]
        if "REASON_CODE" in frame.columns and update.get("reason_code"):
            mask &= frame["REASON_CODE"] == update["reason_code"]
        rows = frame.loc[mask]
        column = update["column"]
        expected = _normalize_value(update["new_value"])
        if rows.empty or column not in rows.columns:
            actual: Any = None
            matched = False
        else:
            values = [_normalize_value(value) for value in rows[column].tolist()]
            actual = values
            matched = bool(values) and all(value == expected for value in values)
        if not matched:
            failures.append(
                {
                    "ENGINE_SERIAL_NUM": update["ENGINE_SERIAL_NUM"],
                    "column": column,
                    "expected": expected,
                    "actual": actual,
                }
            )
    return {
        "status": "PASSED" if not failures else "FAILED",
        "verified": not failures,
        "checked": len(updates),
        "failures": failures,
    }


def _resolve_ticket_core(sys_id: str, context_json: str) -> dict:
    if not sys_id or sys_id in ("None", "null", "undefined", ""):
        return {"sys_id": sys_id, "status": "skipped", "error": "sys_id not available"}
    llm = get_bedrock_llm()
    close_prompt = (
        "Write a brief, professional ServiceNow incident resolution note based on the following context.\n\n"
        f"Resolution Context:\n{context_json}\n\n"
        "Write 2-3 sentences describing: what data quality issue was found, what corrections "
        "were applied, and that the incident is now resolved. Do not use markdown."
    )
    try:
        resp = llm.invoke(close_prompt)
        close_note = resp.content if hasattr(resp, "content") else str(resp)
        if isinstance(close_note, list):
            close_note = "".join(b.get("text", "") for b in close_note if isinstance(b, dict))
    except Exception:
        logger.warning("[resolve] LLM close note failed — fallback for sys_id=%s", sys_id, exc_info=True)
        close_note = f"Automated DQ remediation applied. Context: {context_json[:200]}"
    return resolve_incident(sys_id, str(close_note), close_code="Solution provided")


@tool
def apply_sop_corrections(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Apply approved SOP corrections to Unity Catalog table workspace.aidq.outfile.

    The update is deterministic. Reads sop_diagnoses and approved_esns from state,
    takes no arguments, and must be called first."""
    diagnoses = state.get("sop_diagnoses", []) or []
    approved_esns = state.get("approved_esns")  # None => all
    result = _apply_corrections_core(diagnoses, approved_esns)
    return Command(update={
        "apply_result": result,
        "messages": [ToolMessage(
            f"Apply result: {result.get('status')} — {len(result.get('updates', []))} correction(s).",
            tool_call_id=tool_call_id,
        )],
    })


@tool
def resolve_all_tickets(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Resolve every ServiceNow ticket in state with an LLM close note. Call AFTER apply_sop_corrections.

    Reads tickets and apply_result from state — takes no arguments."""
    tickets = state.get("tickets", []) or []
    apply_result = state.get("apply_result", {}) or {}
    correction_count = len(apply_result.get("updates", []))
    resolved: list[dict] = []
    for t in tickets:
        context = {
            "reason_code": t.get("reason_code", ""),
            "incident_number": t.get("incident_number", ""),
            "corrections_applied": correction_count,
        }
        resolved.append(_resolve_ticket_core(t.get("sys_id") or "", json.dumps(context, default=str)))
        try:
            from agent_server.agents.outfile_analysis.tools import mark_incident_resolved_in_lakebase

            mark_incident_resolved_in_lakebase(t.get("incident_number"))
        except Exception:
            logger.exception(
                "[resolve_all_tickets] Lakebase status update failed for %s",
                t.get("incident_number"),
            )
    logger.info("[resolve_all_tickets] Resolved %d ticket(s)", len(resolved))
    return Command(update={
        "resolved_tickets": resolved,
        "messages": [ToolMessage(f"Resolved {len(resolved)} ticket(s).", tool_call_id=tool_call_id)],
    })
    
    
@tool
def post_diagnosis_work_note(
    state: Annotated[dict, InjectedState],
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Post the SOP diagnosis (from state) as a work note. Reads sys_id + diagnosis from
    state; skips if sys_id is unavailable. Takes no arguments. Call AFTER the SOP tool."""
    sys_id = state.get("sys_id", "") or ""
    diagnosis = state.get("diagnosis", {}) or {}
    if not sys_id or sys_id in ("None", "null", "undefined"):
        logger.info("[post_diagnosis_work_note] sys_id=%r — skipping", sys_id)
        status = "skipped"
    else:
        result = update_work_notes(sys_id, _build_diagnosis_note(diagnosis))
        status = result.get("status", "updated") if isinstance(result, dict) else "updated"
        logger.info("[post_diagnosis_work_note] Work note %s for sys_id=%s", status, sys_id)
    return Command(update={
        "work_note_status": status,
        "messages": [ToolMessage(f"Work note {status}.", tool_call_id=tool_call_id)],
    })