"""Agent 1: Outfile Analysis package."""
from agent_server.agents.outfile_analysis.agent import get_agent1

__all__ = ["get_agent1"]
