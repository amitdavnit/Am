# """Agent 1: Outfile Analysis — ReAct agent."""

# from __future__ import annotations

# import logging

# from langgraph.prebuilt import create_react_agent

# from agent_server.agents.outfile_analysis.tools import (
#     bucket_outfile,
#     create_servicenow_ticket,
# )
# from agent_server.platform.llm import get_bedrock_llm

# logger = logging.getLogger(__name__)
# NAME = "outfile_analysis"

# SYSTEM_PROMPT = """You are Agent 1: Outfile Analysis.

# Your mission is to read workspace.aidq.outfile and raise a ServiceNow incident for each error bucket.

# MANDATORY SEQUENCE — follow exactly, no deviations:

# STEP 1 — Call bucket_outfile()
#   This reads the Unity Catalog outfile table and groups errors into reason-code buckets.
#   The result is a JSON object: {reason_code: {count, records: [...]}}

# STEP 2 — For EVERY bucket (no exceptions), call create_servicenow_ticket
#   Arguments:
#     - reason_code: exact canonical key from the bucket_outfile output
#     - count: the count value from that bucket
#     - records: a JSON string of the first 5 records from that bucket's records array

# STEP 3 — Return a JSON summary array — OUTPUT ONLY RAW JSON, no markdown fences, no prose:
#   [{"reason_code": "...", "incident_number": "...", "sys_id": "...", "count": N}, ...]
#   Use null for incident_number and sys_id if creation failed.

# RULES:
# - Never skip a bucket.
# - Never invent incident numbers — use exactly what create_servicenow_ticket returns.
# - If bucket_outfile returns an empty object, return [] immediately.
# - OUTPUT ONLY RAW JSON — no ```json fences, no markdown, no surrounding text."""


# def get_agent1():
#     """Return a compiled Agent 1 ReAct graph (no persistent memory needed)."""
#     logger.info("[Agent1] Instantiating Outfile Analysis ReAct agent (tools: bucket_outfile, create_servicenow_ticket)")
#     return create_react_agent(
#         model=get_bedrock_llm(),
#         tools=[bucket_outfile, create_servicenow_ticket],
#         prompt=SYSTEM_PROMPT,
#     )



# """Agent 1: Outfile Analysis — ReAct agent."""

# from __future__ import annotations

# import logging
# import operator
# from typing import Annotated, Any

# from langgraph.prebuilt import create_react_agent
# from langgraph.prebuilt.chat_agent_executor import AgentState

# from agent_server.agents.outfile_analysis.tools import (
#     bucket_outfile,
#     create_servicenow_ticket,
# )
# from agent_server.platform.llm import get_bedrock_llm

# logger = logging.getLogger(__name__)
# NAME = "outfile_analysis"


# class OutfileState(AgentState):
#     """ReAct state extended with two shared keys:

#     - buckets: written by bucket_outfile, read by create_servicenow_ticket.
#     - tickets: accumulated (operator.add reducer) — every create_servicenow_ticket
#       call appends its result so the full ticket list is available in state for
#       any downstream consumer.
#     """
#     buckets: dict[str, Any]
#     tickets: Annotated[list[dict[str, Any]], operator.add]


# SYSTEM_PROMPT = """You are Agent 1: Outfile Analysis.

# Your mission is to read workspace.aidq.outfile and raise a ServiceNow incident for each error bucket.

# MANDATORY SEQUENCE — follow exactly, no deviations:

# STEP 1 — Call bucket_outfile()
#   This reads the Unity Catalog outfile table, groups errors into reason-code buckets,
#   and returns a JSON array summary: [{"reason_code": "...", "count": N}, ...]

# STEP 2 — For EVERY reason_code in the summary (no exceptions), call create_servicenow_ticket
#   Arguments:
#     - reason_code: exact canonical string from the bucket_outfile summary
#   (count and sample records are read from agent state automatically — do NOT pass them.)

# STEP 3 — Return a JSON summary array — OUTPUT ONLY RAW JSON, no markdown fences, no prose:
#   [{"reason_code": "...", "incident_number": "...", "sys_id": "...", "count": N}, ...]
#   Use null for incident_number and sys_id if creation failed.

# RULES:
# - Never skip a reason_code.
# - Never invent incident numbers — use exactly what create_servicenow_ticket returns.
# - If bucket_outfile returns an empty array, return [] immediately.
# - OUTPUT ONLY RAW JSON — no ```json fences, no markdown, no surrounding text."""


# def get_agent1():
#     """Return a compiled Agent 1 ReAct graph (no persistent memory needed)."""
#     logger.info("[Agent1] Instantiating Outfile Analysis ReAct agent (tools: bucket_outfile, create_servicenow_ticket)")
#     return create_react_agent(
#         model=get_bedrock_llm(),
#         tools=[bucket_outfile, create_servicenow_ticket],
#         state_schema=OutfileState,
#         prompt=SYSTEM_PROMPT,
#     )


# """Outfile Analysis agent — ReAct implementation."""

from __future__ import annotations
import logging
from langgraph.prebuilt import InjectedState, create_react_agent

from agent_server.platform.llm import get_bedrock_llm
from agent_server.agents.outfile_analysis.tools import OutfileAgentState
from agent_server.agents.outfile_analysis.tools import bucket_errors, create_tickets

logger = logging.getLogger(__name__)
NAME = "outfile_analysis"





SYSTEM_PROMPT = """You are the Unity Catalog Outfile Analysis agent for a data-quality
remediation pipeline.

Follow these steps strictly in order:
1. Call `bucket_errors` to read the configured outfile source and bucket
   its error records by reason code.
2. Stop after bucketing. Do NOT call create_tickets — incident creation is
   approved separately by the supervisor pipeline.
3. If no buckets were created, stop immediately and report that no errors were found.

Do not skip or reorder steps. After bucketing, give a one-line summary.
"""

_agent = None


def get_agent1():
    global _agent
    if _agent is None:
        _agent = create_react_agent(
            model=get_bedrock_llm("outfile_analysis"),
            tools=[bucket_errors, create_tickets],
            state_schema=OutfileAgentState,
            prompt=SYSTEM_PROMPT,
        )
    return _agent


