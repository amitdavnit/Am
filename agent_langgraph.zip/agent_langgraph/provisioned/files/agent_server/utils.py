import json
import logging
from typing import Any, AsyncGenerator, AsyncIterator, Optional

from databricks.sdk import WorkspaceClient
from langchain.messages import AIMessage, AIMessageChunk, ToolMessage
from mlflow.genai.agent_server import get_request_headers
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentStreamEvent,
    create_function_call_output_item,
    create_text_delta,
    create_text_output_item,
    output_to_responses_items_stream,
)

logger = logging.getLogger(__name__)


def _extract_text_content(content: Any) -> str:
    """Bedrock returns content as [{'type': 'text', 'text': '...'}] blocks."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            block.get("text", "")
            for block in content
            if isinstance(block, dict) and block.get("type") == "text"
        )
    return ""


def _normalize_message_content(msg: Any) -> None:
    if hasattr(msg, "content") and not isinstance(msg.content, str):
        msg.content = _extract_text_content(msg.content)


def _format_step_detail_from_state(node_data: dict) -> str:
    """Build per-step detail markdown from a tool node's state update.

    The pipeline tools return Command(update={...}) instead of a JSON ToolMessage
    payload, so the step data lives in the node's state diff:
      - analyze_outfile: writes buckets AND tickets (bucketing + incident creation)
      - run_all_remediations: writes sop_diagnoses / rca_results
    Returns "" for any node update that isn't a pipeline step.

    Step 1 is detected FIRST by the presence of the ``buckets`` key: analyze_outfile
    also RESETS sop_diagnoses/rca_results to [] in the same update, which must not be
    mistaken for the Step 2 remediation output.
    """
    from agent_server.orchestration.hitl_formatting import (
        format_step1_detail,
        format_step2_detail,
    )

    # Step 1 — analyze_outfile writes buckets (+ tickets). Detect this first.
    if "buckets" in node_data:
        tickets = node_data.get("tickets")
        if isinstance(tickets, list) and tickets:
            return format_step1_detail(tickets)
        buckets = node_data.get("buckets")
        if isinstance(buckets, dict) and buckets:
            return format_step1_detail(buckets)
        return ""

    # Step 2 — run_all_remediations writes sop_diagnoses / rca_results.
    if "sop_diagnoses" in node_data or "rca_results" in node_data:
        return format_step2_detail(node_data)

    return ""


def get_session_id(request: ResponsesAgentRequest) -> str | None:
    if request.context and request.context.conversation_id:
        return request.context.conversation_id
    if request.custom_inputs and isinstance(request.custom_inputs, dict):
        return request.custom_inputs.get("session_id")
    return None


def get_user_workspace_client() -> WorkspaceClient:
    token = get_request_headers().get("x-forwarded-access-token")
    return WorkspaceClient(token=token, auth_type="pat")


def get_databricks_host_from_env() -> Optional[str]:
    try:
        w = WorkspaceClient()
        return w.config.host
    except Exception as e:
        logging.exception(f"Error getting databricks host from env: {e}")
        return None


async def process_agent_astream_events(
    async_stream: AsyncIterator[Any],
) -> AsyncGenerator[ResponsesAgentStreamEvent, None]:
    """
    Process LangGraph astream events into ResponsesAgentStreamEvent objects.

    Stream modes:
      - "messages": token-level AI text deltas (live streaming in the UI)
      - "updates": completed node outputs (pipeline step details, tool calls,
        HITL interrupts, and final text fallback when tokens were not streamed)

    Token streaming skips tool-call chunks and "✅ STEP …" chatter so it does
    not duplicate the deterministic per-step blocks emitted from updates.
    """
    # Track open tool-call IDs so HITL interrupts can close them. Otherwise the
    # chat UI stays in a non-ready state (incomplete function_call) and the user
    # cannot type yes/no to resume.
    pending_tool_call_ids: list[str] = []
    # Message ids that already received token deltas — avoid re-sending full text.
    streamed_text_ids: set[str] = set()
    # Accumulated text for open stream items (finalize on updates / end).
    open_text_streams: dict[str, str] = {}
    # Monotonic sequence so each per-step detail block gets a UNIQUE item id.
    # analyze_outfile and run_all_remediations both run in the "tools" node, so a
    # node-name-based id would collide and the second step's block would be dropped
    # by the client (item already finalized).
    step_detail_seq = 0

    async for event in async_stream:
        # ── Token streaming (LLM chunks) ───────────────────────────────────
        if event[0] == "messages":
            payload = event[1]
            msg = payload[0] if isinstance(payload, (list, tuple)) else payload
            metadata = (
                payload[1]
                if isinstance(payload, (list, tuple)) and len(payload) > 1
                else {}
            )
            if not isinstance(msg, AIMessageChunk):
                continue
            # Only the top-level supervisor ("agent" node) may stream visible text.
            # Sub-steps run raw llm.invoke() calls inside the "tools" node (bucketing
            # code-mapping, ServiceNow incident descriptions, SOP/RCA synthesis); their
            # tokens otherwise leak into the chat AND corrupt the client-side dedup of
            # the deterministic per-step blocks (making the Step 1 table render twice).
            node = metadata.get("langgraph_node") if isinstance(metadata, dict) else None
            if node is not None and node != "agent":
                continue
            tool_call_chunks = getattr(msg, "tool_call_chunks", None) or []
            if tool_call_chunks:
                continue
            # Some providers put tool calls only on additional_kwargs mid-stream.
            additional = getattr(msg, "additional_kwargs", None) or {}
            if additional.get("tool_calls"):
                continue
            text = _extract_text_content(msg.content)
            if not text or text.lstrip().startswith("✅ STEP"):
                continue
            text_id = str(getattr(msg, "id", None) or "supervisor-stream")
            streamed_text_ids.add(text_id)
            open_text_streams[text_id] = open_text_streams.get(text_id, "") + text
            yield ResponsesAgentStreamEvent(
                **create_text_delta(delta=text, item_id=text_id)
            )
            continue

        if event[0] == "updates":
            update_dict = event[1]

            # ── Interrupt event ────────────────────────────────────────────
            # When interrupt() is called inside a tool, LangGraph emits:
            #   ("updates", {"__interrupt__": (<Interrupt(value=..., resumable=True)>, )})
            # We stream the interrupt value as text so the frontend sees it.
            if "__interrupt__" in update_dict:
                interrupts = update_dict["__interrupt__"]
                if not isinstance(interrupts, (list, tuple)):
                    interrupts = [interrupts]
                logger.info(
                    "[utils] HITL interrupt fired — streaming approval summary to client (%d interrupt(s))",
                    len(interrupts),
                )

                # Close any open tool calls so the chat transport returns to
                # status=ready and accepts the user's yes/no reply.
                closed_any = False
                for call_id in list(pending_tool_call_ids):
                    logger.info(
                        "[utils]   Closing open tool call %s for HITL pause",
                        call_id,
                    )
                    yield ResponsesAgentStreamEvent(
                        type="response.output_item.done",
                        item=create_function_call_output_item(
                            call_id,
                            "Paused for human approval. Use Approve / Reject in chat, "
                            "or Notifications → Approve / Reject.",
                        ),
                    )
                    closed_any = True
                pending_tool_call_ids.clear()

                # If we never captured a call_id (message-shape mismatch), emit a
                # synthetic close so the client can still leave streaming state.
                if not closed_any:
                    logger.warning(
                        "[utils] HITL interrupt with no tracked tool_call_id — "
                        "emitting synthetic function_call_output"
                    )
                    yield ResponsesAgentStreamEvent(
                        type="response.output_item.done",
                        item=create_function_call_output_item(
                            "hitl-pause",
                            "Paused for human approval. Use Approve / Reject in chat, "
                            "or Notifications → Approve / Reject.",
                        ),
                    )

                for idx, intr in enumerate(interrupts):
                    value = getattr(intr, "value", None)
                    if value is None:
                        value = str(intr)
                    if isinstance(value, str) and value.strip():
                        item_id = f"hitl-interrupt-{idx}"
                        # Stream HITL summary in chunks for snappier UI.
                        chunk_size = 240
                        for start in range(0, len(value), chunk_size):
                            yield ResponsesAgentStreamEvent(
                                **create_text_delta(
                                    delta=value[start : start + chunk_size],
                                    item_id=item_id,
                                )
                            )
                        yield ResponsesAgentStreamEvent(
                            type="response.output_item.done",
                            item=create_text_output_item(value, item_id),
                        )
                continue

            # ── Normal updates (state diffs from completed nodes) ──────────
            for node_name, node_data in update_dict.items():
                if not isinstance(node_data, dict):
                    continue

                # Deterministic per-step detail block, derived from the tool's
                # STATE update (Command(update=...)) rather than the ToolMessage
                # content. Step 1 = buckets/incidents, Step 2 = SOP diagnosis + RCA.
                step_detail = _format_step_detail_from_state(node_data)
                if step_detail:
                    logger.info(
                        "[utils]   Emitting step detail from node %r (%d chars)",
                        node_name,
                        len(step_detail),
                    )
                    detail_id = f"step-detail-{node_name}-{step_detail_seq}"
                    step_detail_seq += 1
                    # Emit as ONE completed output item (no preceding text deltas).
                    # Streaming deltas + a matching done for the same synthetic id can be
                    # re-appended by the client when dedup misfires, which duplicated the
                    # Step 1 incident table. A lone done renders exactly once.
                    yield ResponsesAgentStreamEvent(
                        type="response.output_item.done",
                        item=create_text_output_item(step_detail, detail_id),
                    )

                messages = node_data.get("messages", [])
                if len(messages) > 0:
                    logger.info(
                        "[utils] Update from node %r — %d message(s)",
                        node_name,
                        len(messages),
                    )
                    for msg in messages:
                        if isinstance(msg, ToolMessage):
                            call_id = getattr(msg, "tool_call_id", None)
                            logger.info(
                                "[utils]   ToolMessage  tool_call_id=%s  content_len=%d",
                                call_id or "?",
                                len(str(msg.content)),
                            )
                            if call_id and call_id in pending_tool_call_ids:
                                pending_tool_call_ids.remove(call_id)
                            if not isinstance(msg.content, str):
                                msg.content = json.dumps(msg.content)
                        else:
                            _normalize_message_content(msg)
                            tool_calls = getattr(msg, "tool_calls", None) or []
                            for tc in tool_calls:
                                call_id = None
                                if isinstance(tc, dict):
                                    call_id = tc.get("id") or tc.get("call_id")
                                else:
                                    call_id = getattr(tc, "id", None) or getattr(
                                        tc, "call_id", None
                                    )
                                if call_id and call_id not in pending_tool_call_ids:
                                    pending_tool_call_ids.append(call_id)
                            additional = getattr(msg, "additional_kwargs", None) or {}
                            for tc in additional.get("tool_calls") or []:
                                if isinstance(tc, dict):
                                    call_id = tc.get("id") or (
                                        (tc.get("function") or {}).get("id")
                                    )
                                    if call_id and call_id not in pending_tool_call_ids:
                                        pending_tool_call_ids.append(call_id)
                            # Free-text: finalize if tokens already streamed;
                            # otherwise emit full text (non-streaming providers).
                            if isinstance(msg, (AIMessage, AIMessageChunk)) and not tool_calls:
                                text = _extract_text_content(msg.content)
                                text_id = str(
                                    getattr(msg, "id", None) or "supervisor-text"
                                )
                                if text_id in streamed_text_ids:
                                    final_text = open_text_streams.get(text_id) or text
                                    if final_text.strip():
                                        yield ResponsesAgentStreamEvent(
                                            type="response.output_item.done",
                                            item=create_text_output_item(
                                                final_text, text_id
                                            ),
                                        )
                                    open_text_streams.pop(text_id, None)
                                elif (
                                    text.strip()
                                    and not text.lstrip().startswith("✅ STEP")
                                ):
                                    yield ResponsesAgentStreamEvent(
                                        **create_text_delta(
                                            delta=text,
                                            item_id=text_id,
                                        )
                                    )
                                    yield ResponsesAgentStreamEvent(
                                        type="response.output_item.done",
                                        item=create_text_output_item(text, text_id),
                                    )
                    for item in output_to_responses_items_stream(messages):
                        payload = item.item if hasattr(item, "item") else None
                        # Assistant free-text ("message" items) is already emitted by the
                        # manual finalization block above (with the same item id as the
                        # streamed deltas, so the client dedups it). Emitting it AGAIN here
                        # produces a second, un-deduped copy — this is what made answers,
                        # the greeting, and the "Pipeline Complete" summary appear twice.
                        # Only pass through tool call / tool result items.
                        if isinstance(payload, dict) and payload.get("type") == "message":
                            continue
                        try:
                            if (
                                isinstance(payload, dict)
                                and payload.get("type") == "function_call"
                            ):
                                call_id = payload.get("call_id") or payload.get("id")
                                if call_id and call_id not in pending_tool_call_ids:
                                    pending_tool_call_ids.append(call_id)
                        except Exception:
                            pass
                        yield item

                if node_name == "agent" and pending_tool_call_ids:
                    logger.debug(
                        "[utils] Open tool calls after agent update: %s",
                        pending_tool_call_ids,
                    )

    # Finalize any token streams that never got an updates-side done event.
    for text_id, text in list(open_text_streams.items()):
        if text.strip():
            yield ResponsesAgentStreamEvent(
                type="response.output_item.done",
                item=create_text_output_item(text, text_id),
            )
    open_text_streams.clear()
