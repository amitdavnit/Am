from pathlib import Path
from contextlib import asynccontextmanager
import asyncio
import logging
import sys

from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from mlflow.genai.agent_server import AgentServer, setup_mlflow_git_based_version_tracking

# Load env vars from .env before importing the agent for proper auth
load_dotenv(dotenv_path=Path(__file__).parent.parent / ".env", override=True)

# psycopg async + Lakebase on Windows requires SelectorEventLoop (not Proactor).
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

from agent_server.logging_config import setup_logging  # noqa: E402

setup_logging()
logger = logging.getLogger(__name__)

# Register agent invoke/stream handlers
import agent_server.agent  # noqa: E402

# Top-level API package (REST) — separate from agent_server
from api import api_router  # noqa: E402
from agent_server.orchestration.workflows.supervisor_workflow import (  # noqa: E402
    reset_supervisor_graph,
)
from agent_server.platform.checkpoint import (  # noqa: E402
    get_lakebase_access_error_message,
    init_lakebase_config,
    lakebase_checkpointer_context,
    set_checkpointer,
    set_server_loop,
)

LAKEBASE_CONFIG = init_lakebase_config()

agent_server = AgentServer("ResponsesAgent", enable_chat_proxy=False)

# Define the app as a module level variable to enable multiple workers
app = agent_server.app  # noqa: F841

app.include_router(api_router)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    """Agent API root — the React AiDQ UI is deployed as a separate Databricks App."""
    return JSONResponse(
        {
            "service": "aidq-agent",
            "ui": "Deploy and open the React AiDQ app (e2e-chatbot-app-next).",
            "endpoints": {
                "invocations": "/invocations",
                "incidents": "/api/v1/incidents",
                "threads": "/api/v1/threads",
                "notifications": "/api/v1/notifications",
                "feedback": "/api/v1/feedback",
                "health": "/api/v1/health",
            },
            "lakebase": {
                "configured": LAKEBASE_CONFIG.configured,
                "description": LAKEBASE_CONFIG.description if LAKEBASE_CONFIG.configured else None,
                "checkpointer": "AsyncCheckpointSaver",
            },
        }
    )


_original_lifespan = app.router.lifespan_context


@asynccontextmanager
async def _lifespan(app):
    """Open Lakebase AsyncCheckpointSaver once per process for durable HITL."""
    # Record the main server loop so background HITL resumes run on the SAME loop
    # the checkpointer pool is bound to (avoids "bound to a different event loop").
    try:
        set_server_loop(asyncio.get_running_loop())
    except RuntimeError:
        pass
    if not LAKEBASE_CONFIG.configured:
        logger.warning(
            "Lakebase not configured — HITL checkpoints are in-memory only. "
            "Set LAKEBASE_AUTOSCALING_ENDPOINT or LAKEBASE_INSTANCE_NAME."
        )
        async with _original_lifespan(app):
            yield
        return

    try:
        async with lakebase_checkpointer_context(LAKEBASE_CONFIG) as checkpointer:
            set_checkpointer(checkpointer)
            reset_supervisor_graph()
            logger.info(
                "Lakebase AsyncCheckpointSaver ready (%s)",
                LAKEBASE_CONFIG.description,
            )
            try:
                async with _original_lifespan(app):
                    yield
            finally:
                set_checkpointer(None)
                reset_supervisor_graph()
    except Exception as exc:
        error_msg = str(exc).lower()
        if any(
            keyword in error_msg
            for keyword in [
                "lakebase",
                "pg_hba",
                "postgres",
                "database instance",
                "insufficient privilege",
                "pooltimeout",
                "proactor",
                "couldn't get a connection",
            ]
        ):
            logger.error(
                "Lakebase checkpointer setup failed: %s\n\n%s",
                exc,
                get_lakebase_access_error_message(LAKEBASE_CONFIG.description),
            )
        else:
            logger.error("Lakebase checkpointer setup failed: %s", exc, exc_info=True)
        # Degrade gracefully so the API still starts (HITL won't survive restarts).
        logger.warning(
            "Continuing with in-memory MemorySaver — durable HITL disabled until "
            "Lakebase connectivity is fixed."
        )
        set_checkpointer(None)
        reset_supervisor_graph()
        async with _original_lifespan(app):
            yield


app.router.lifespan_context = _lifespan

try:
    setup_mlflow_git_based_version_tracking()
except (FileNotFoundError, OSError) as exc:
    # git may not be installed / on PATH (common on Windows); version tracking
    # is optional and should not prevent the server from starting.
    logger.warning("Skipping MLflow git-based version tracking: %s", exc)


def _windows_selector_loop_factory():
    """psycopg async requires SelectorEventLoop on Windows (not Proactor)."""
    import selectors

    return asyncio.SelectorEventLoop(selectors.SelectSelector())


def main():
    """Start uvicorn with a Windows-compatible event loop for Lakebase/psycopg."""
    import uvicorn

    args = agent_server._parse_server_args()
    run_kwargs: dict = {
        "app": "agent_server.start_server:app",
        "host": "0.0.0.0",
        "port": args.port,
        "workers": args.workers,
        "reload": args.reload,
    }
    if sys.platform == "win32":
        # Must pass loop factory into uvicorn — import-time policy alone is not enough.
        run_kwargs["loop"] = _windows_selector_loop_factory
        logger.info("Using Windows SelectorEventLoop for Lakebase AsyncCheckpointSaver")
    uvicorn.run(**run_kwargs)
