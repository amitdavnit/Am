"""Small DataFrame adapter for Unity Catalog Delta tables."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

import numpy as np
import pandas as pd

from api.services.databricks_sql import execute_sql


def load_table(table_name: str, columns: list[str] | None = None) -> pd.DataFrame:
    projection = ", ".join(f"`{column}`" for column in columns) if columns else "*"
    rows = execute_sql(f"SELECT {projection} FROM {table_name}")
    return pd.DataFrame(rows, columns=columns if columns and not rows else None)


def _literal(value: Any) -> str:
    # Unwrap numpy scalars (np.int64/np.float64/np.bool_) to native Python types
    # so numeric values are emitted as numbers, not quoted strings.
    if isinstance(value, np.generic):
        value = value.item()
    if value is None or (not isinstance(value, (list, dict)) and pd.isna(value)):
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return str(value)
    if isinstance(value, (datetime, date)):
        return f"'{value.isoformat()}'"
    return "'" + str(value).replace("'", "''") + "'"


def merge_dataframe(table_name: str, df: pd.DataFrame, key: str) -> None:
    """Atomically replace table contents with a DataFrame using Delta MERGE."""
    columns = list(df.columns)
    if not columns:
        return
    if df.empty:
        execute_sql(f"DELETE FROM {table_name}")
        return

    rows = ",\n".join(
        "(" + ", ".join(_literal(value) for value in row) + ")"
        for row in df.itertuples(index=False, name=None)
    )
    column_sql = ", ".join(f"`{column}`" for column in columns)
    execute_sql(
        f"""
        MERGE INTO {table_name} target
        USING (SELECT * FROM VALUES
          {rows}
        AS source({column_sql})) source
        ON target.`{key}` = source.`{key}`
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
        WHEN NOT MATCHED BY SOURCE THEN DELETE
        """
    )


def append_dataframe(table_name: str, df: pd.DataFrame) -> None:
    if df.empty:
        return
    columns = list(df.columns)
    column_sql = ", ".join(f"`{column}`" for column in columns)
    rows = ",\n".join(
        "(" + ", ".join(_literal(value) for value in row) + ")"
        for row in df.itertuples(index=False, name=None)
    )
    execute_sql(
        f"INSERT INTO {table_name} ({column_sql}) VALUES {rows}"
    )


def merge_cell_updates(
    table_name: str,
    updates: list[dict[str, Any]],
    *,
    key_columns: list[str],
    chunk_size: int = 2000,
) -> int:
    """Apply cell-level corrections with a single MERGE per chunk.

    Only the corrected rows form the MERGE source (never the whole table), so this
    scales with the number of corrections — not table size — and avoids the
    ``DELTA_MULTIPLE_SOURCE_ROW_MATCHING_TARGET_ROW_IN_MERGE`` error that a
    whole-table MERGE hits when the target contains duplicate key values.

    Each ``updates`` dict must contain every column in ``key_columns`` plus a
    ``column`` (name to correct) and ``new_value``. Rows sharing the same key
    tuple are collapsed into one source row, so multiple corrected columns per key
    are supported. Columns a given row does not correct are sent as NULL and kept
    at their existing value via ``COALESCE`` in the UPDATE.

    Returns the number of source rows merged.
    """
    if not updates:
        return 0

    grouped: dict[tuple, dict[str, Any]] = {}
    value_columns: list[str] = []
    for update in updates:
        key = tuple(update[column] for column in key_columns)
        column = update["column"]
        if column not in value_columns:
            value_columns.append(column)
        grouped.setdefault(key, {})[column] = update["new_value"]

    all_columns = list(key_columns) + value_columns
    column_sql = ", ".join(f"`{column}`" for column in all_columns)
    on_sql = " AND ".join(f"t.`{column}` = s.`{column}`" for column in key_columns)
    set_sql = ", ".join(
        f"t.`{column}` = COALESCE(s.`{column}`, t.`{column}`)"
        for column in value_columns
    )

    items = list(grouped.items())
    merged = 0
    for start in range(0, len(items), chunk_size):
        chunk = items[start : start + chunk_size]
        rows_sql = ",\n".join(
            "("
            + ", ".join(_literal(part) for part in key)
            + ", "
            + ", ".join(_literal(cols.get(column)) for column in value_columns)
            + ")"
            for key, cols in chunk
        )
        execute_sql(
            f"""
            MERGE INTO {table_name} t
            USING (SELECT * FROM VALUES
              {rows_sql}
            AS s({column_sql})) s
            ON {on_sql}
            WHEN MATCHED THEN UPDATE SET {set_sql}
            """
        )
        merged += len(chunk)
    return merged
