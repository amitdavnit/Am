"""Incidents master repository — Lakebase aidq.incident_history (no Delta fallback)."""

from __future__ import annotations

import re

import pandas as pd

from agent_server.platform.lakebase import AIDQ_SCHEMA, execute, lakebase_configured

# Columns exposed for stats / analytical QA (excludes heavy text fields)
_STATS_COLS = ["incident_number", "category", "state", "created_date", "resolved_date"]

_INC_ID_RE = re.compile(r"\bINC\d+\b", re.IGNORECASE)


class LakebaseStorageError(RuntimeError):
    pass


def _require_lakebase() -> None:
    if not lakebase_configured():
        raise LakebaseStorageError(
            "Lakebase is required for incident history. "
            "Configure PGHOST+PGDATABASE and run scripts/load_servicenow_history.py."
        )


def extract_incident_ids(text: str) -> list[str]:
    """Return unique INC-prefixed numeric IDs found in text, uppercased, order-preserved."""
    return list(dict.fromkeys(m.upper() for m in _INC_ID_RE.findall(text)))


def load_snow_dump() -> pd.DataFrame:
    """Load full incidents master from Lakebase."""
    _require_lakebase()
    rows = execute(f"SELECT * FROM {AIDQ_SCHEMA}.incident_history")
    return pd.DataFrame(rows) if rows else pd.DataFrame()


def load_incidents_for_stats() -> pd.DataFrame:
    """Load structural columns needed for analytical QA questions."""
    _require_lakebase()
    cols = ", ".join(_STATS_COLS)
    rows = execute(f"SELECT {cols} FROM {AIDQ_SCHEMA}.incident_history")
    return pd.DataFrame(rows) if rows else pd.DataFrame(columns=_STATS_COLS)


def get_known_categories() -> list[str]:
    """Return distinct category (reason_code) values from Lakebase history."""
    _require_lakebase()
    rows = execute(
        f"""
        SELECT DISTINCT category
        FROM {AIDQ_SCHEMA}.incident_history
        WHERE category IS NOT NULL AND category <> ''
        ORDER BY category
        """
    )
    return [str(r["category"]) for r in rows]


def format_stats_rows(df: pd.DataFrame) -> str:
    """
    Format a (possibly filtered) stats DataFrame as plain text for the LLM prompt.
    Each row is one line: incident_number | category | state | created_date | resolved_date
    """
    header = " | ".join(_STATS_COLS)
    rows = "\n".join(
        " | ".join(str(row[c]) for c in _STATS_COLS)
        for _, row in df.iterrows()
    )
    return f"{header}\n{rows}"
