"""ServiceNow REST client for updating incidents (work notes)."""
from __future__ import annotations

import logging
import os

import requests

logger = logging.getLogger(__name__)


def _snow_credentials() -> tuple[str, str, str]:
    """Return (instance, username, password) from environment variables."""
    instance = os.getenv("SERVICENOW_INSTANCE", "").rstrip("/")
    username = os.getenv("SERVICENOW_USERNAME", "")
    password = os.getenv("SERVICENOW_PASSWORD", "")
    return instance, username, password


def get_sys_id_by_number(number: str) -> str | None:
    """Resolve a sys_id from a human-readable incident number (fallback)."""
    instance, username, password = _snow_credentials()
    if not instance:
        return None
    url = f"{instance}/api/now/table/incident"
    params = {
        "sysparm_query": f"number={number}",
        "sysparm_fields": "sys_id",
        "sysparm_limit": "1",
    }
    try:
        resp = requests.get(
            url,
            auth=(username, password),
            headers={"Accept": "application/json"},
            params=params,
            timeout=30,
        )
        resp.raise_for_status()
        rows = resp.json().get("result", [])
        return rows[0]["sys_id"] if rows else None
    except requests.RequestException:
        logger.exception("ServiceNow sys_id lookup failed for %s", number)
        return None


def update_work_notes(sys_id: str, work_notes: str) -> dict:
    """Append a work note to an incident. Returns a status dict."""
    instance, username, password = _snow_credentials()
    if not instance:
        return {"sys_id": sys_id, "status": "failed", "error": "ServiceNow credentials not configured"}
    url = f"{instance}/api/now/table/incident/{sys_id}"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    try:
        resp = requests.patch(
            url,
            auth=(username, password),
            headers=headers,
            json={"work_notes": work_notes},
            timeout=30,
        )
        if resp.status_code == 200:
            return {"sys_id": sys_id, "status": "updated", "error": None}
        logger.error("ServiceNow work_notes update %s: %s", resp.status_code, resp.text)
        return {"sys_id": sys_id, "status": "failed", "error": resp.text}
    except requests.RequestException as exc:
        logger.exception("ServiceNow work_notes update failed")
        return {"sys_id": sys_id, "status": "failed", "error": str(exc)}


def resolve_incident(sys_id: str, resolution_notes: str,
                     close_code: str = "Solution provided") -> dict:
    """Mark an incident Resolved (state=6) with a resolution code + notes."""
    instance, username, password = _snow_credentials()
    if not instance:
        return {"sys_id": sys_id, "status": "failed", "error": "ServiceNow credentials not configured"}
    url = f"{instance}/api/now/table/incident/{sys_id}"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    payload = {
        "state": "6",
        "close_code": close_code,
        "close_notes": resolution_notes,
    }
    try:
        resp = requests.patch(url, auth=(username, password), headers=headers,
                              json=payload, timeout=30)
        if resp.status_code == 200:
            return {"sys_id": sys_id, "status": "resolved", "error": None}
        logger.error("ServiceNow resolve %s: %s", resp.status_code, resp.text)
        return {"sys_id": sys_id, "status": "failed", "error": resp.text}
    except requests.RequestException as exc:
        logger.exception("ServiceNow resolve failed")
        return {"sys_id": sys_id, "status": "failed", "error": str(exc)}
 