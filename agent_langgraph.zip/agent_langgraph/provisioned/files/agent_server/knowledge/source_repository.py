"""Source reference data repository."""

from __future__ import annotations

import os
from typing import Any

import pandas as pd

from agent_server.knowledge.uc_tables import load_table

SOURCE_REFERENCE_TABLE = os.getenv(
    "SOURCE_REFERENCE_TABLE", "workspace.aidq.source_reference"
)
_NUMERIC_COLUMNS = [
    "ENGINE_SERIAL_NUM",
    "PROGRAM_PAYMENT_CODE",
    "PROGRAM_ACCOUNT_CODE",
    "ENGINE_SYSTEM_CODE",
    "ENGINE_COMPONENT_CODE",
]


def load_source() -> pd.DataFrame:
    df = load_table(SOURCE_REFERENCE_TABLE)
    for column in _NUMERIC_COLUMNS:
        if column in df:
            df[column] = pd.to_numeric(df[column], errors="coerce")
    return df


def get_by_esn(esn: int) -> dict[str, Any] | None:
    df = load_source()
    rows = df[df["ENGINE_SERIAL_NUM"] == esn]
    if rows.empty:
        return None
    return rows.iloc[0].to_dict()
