"""Outfile error data repository — Unity Catalog table or local/Volume file path."""

from __future__ import annotations

import io
import logging
import os
import shutil
import uuid
from contextvars import ContextVar
from datetime import datetime
from pathlib import Path

import pandas as pd

from agent_server.knowledge.uc_tables import (
    append_dataframe,
    load_table,
    merge_cell_updates,
    merge_dataframe,
)

logger = logging.getLogger(__name__)

OUTFILE_TABLE = os.getenv("OUTFILE_TABLE", "workspace.aidq.outfile")
OUTFILE_BACKUPS_TABLE = os.getenv(
    "OUTFILE_BACKUPS_TABLE", "workspace.aidq.outfile_backups"
)
_NUMERIC_COLUMNS = [
    "ENGINE_SERIAL_NUM",
    "PROGRAM_PAYMENT_CODE",
    "PROGRAM_ACCOUNT_CODE",
    "ENGINE_SYSTEM_CODE",
    "ENGINE_COMPONENT_CODE",
]

# Per-request / per-pipeline source override (catalog FQN or file path).
_outfile_source: ContextVar[str | None] = ContextVar("outfile_source", default=None)


def default_outfile_source() -> str:
    return (os.getenv("OUTFILE_TABLE") or OUTFILE_TABLE).strip()


def get_outfile_source() -> str:
    return (_outfile_source.get() or default_outfile_source()).strip()


def set_outfile_source(source: str | None) -> str:
    """Set the active outfile source for this pipeline run. Returns resolved source."""
    resolved = (source or "").strip() or default_outfile_source()
    _outfile_source.set(resolved)
    logger.info("[outfile] Active source set to %r", resolved)
    return resolved


def clear_outfile_source() -> None:
    _outfile_source.set(None)


def is_file_source(source: str | None = None) -> bool:
    """True when *source* looks like a filesystem / Volume / object-store path."""
    s = (source or get_outfile_source()).strip()
    if not s:
        return False
    lower = s.lower()
    if lower.startswith(("dbfs:", "file:", "s3://", "abfss:", "wasbs:")):
        return True
    if s.startswith(("/", "\\")) or "\\" in s:
        return True
    if "/Volumes/" in s or "/volumes/" in lower:
        return True
    return lower.endswith((".csv", ".parquet", ".xlsx", ".xls", ".json", ".tsv"))


def is_volume_source(source: str | None = None) -> bool:
    """True when *source* points at a Unity Catalog Volume (/Volumes/...).

    Volume files are not on the local filesystem when running off-cluster, so
    they must be read/written through the Databricks SDK Files API.
    """
    s = (source or get_outfile_source()).strip().replace("\\", "/")
    if s.lower().startswith("dbfs:"):
        s = s[5:]
    return "/volumes/" in s.lower()


def _volume_path(source: str) -> str:
    """Return a clean POSIX /Volumes/... path for the Files API."""
    s = source.strip().replace("\\", "/")
    if s.lower().startswith("dbfs:"):
        s = s[5:]
    idx = s.lower().find("/volumes/")
    if idx > 0:
        s = s[idx:]
    if not s.startswith("/"):
        s = "/" + s
    return s


def _read_dataframe_from_buffer(buffer: io.BytesIO, suffix: str) -> pd.DataFrame:
    suffix = suffix.lower().lstrip(".")
    if suffix == "parquet":
        return pd.read_parquet(buffer)
    if suffix in {"xlsx", "xls"}:
        return pd.read_excel(buffer)
    if suffix == "json":
        return pd.read_json(buffer)
    if suffix == "tsv":
        return pd.read_csv(buffer, sep="\t")
    return pd.read_csv(buffer)


def _write_dataframe_to_buffer(df: pd.DataFrame, suffix: str) -> io.BytesIO:
    suffix = suffix.lower().lstrip(".")
    buffer = io.BytesIO()
    if suffix == "parquet":
        df.to_parquet(buffer, index=False)
    elif suffix in {"xlsx", "xls"}:
        df.to_excel(buffer, index=False)
    elif suffix == "json":
        buffer.write(df.to_json(orient="records", indent=2).encode("utf-8"))
    elif suffix == "tsv":
        df.to_csv(buffer, sep="\t", index=False)
    else:
        df.to_csv(buffer, index=False)
    buffer.seek(0)
    return buffer


def _load_volume_file(source: str) -> pd.DataFrame:
    from api.services.databricks_sql import get_workspace_client

    volume_path = _volume_path(source)
    logger.info("[outfile] Loading Volume file %s via Files API", volume_path)
    client = get_workspace_client()
    response = client.files.download(volume_path)
    data = response.contents.read()
    suffix = volume_path.rsplit(".", 1)[-1] if "." in volume_path else "csv"
    return _read_dataframe_from_buffer(io.BytesIO(data), suffix)


def _save_volume_file(df: pd.DataFrame, source: str) -> None:
    from api.services.databricks_sql import get_workspace_client

    volume_path = _volume_path(source)
    suffix = volume_path.rsplit(".", 1)[-1] if "." in volume_path else "csv"
    buffer = _write_dataframe_to_buffer(df, suffix)
    logger.info("[outfile] Saving Volume file %s (%d rows) via Files API", volume_path, len(df))
    client = get_workspace_client()
    client.files.upload(volume_path, buffer, overwrite=True)


def _normalize_local_path(source: str) -> Path:
    path = source.strip()
    if path.lower().startswith("file:"):
        path = path[5:]
        if path.startswith("///"):
            path = path[3:]
        elif path.startswith("//"):
            path = path[1:]
    if path.lower().startswith("dbfs:"):
        path = path.replace("dbfs:", "/dbfs", 1)
    return Path(path)


def _coerce_numeric(df: pd.DataFrame) -> pd.DataFrame:
    for column in _NUMERIC_COLUMNS:
        if column in df.columns:
            df[column] = pd.to_numeric(df[column], errors="coerce")
    return df


def _load_file(source: str) -> pd.DataFrame:
    if is_volume_source(source):
        return _load_volume_file(source)
    path = _normalize_local_path(source)
    if not path.exists():
        raise FileNotFoundError(f"Outfile path not found: {path}")
    suffix = path.suffix.lower()
    logger.info("[outfile] Loading file source %s", path)
    if suffix == ".parquet":
        df = pd.read_parquet(path)
    elif suffix in {".xlsx", ".xls"}:
        df = pd.read_excel(path)
    elif suffix == ".json":
        df = pd.read_json(path)
    elif suffix == ".tsv":
        df = pd.read_csv(path, sep="\t")
    else:
        df = pd.read_csv(path)
    return df


def load_outfile(source: str | None = None) -> pd.DataFrame:
    """Load error rows from the active Unity Catalog table or file path."""
    resolved = (source or get_outfile_source()).strip()
    if is_file_source(resolved):
        df = _load_file(resolved)
    else:
        logger.info("[outfile] Loading Unity Catalog table %s", resolved)
        df = load_table(resolved)
    df.columns = df.columns.astype(str).str.strip()
    return _coerce_numeric(df)


def save_outfile(df: pd.DataFrame, source: str | None = None) -> None:
    """Persist corrections back to the same catalog table or file path."""
    resolved = (source or get_outfile_source()).strip()
    if is_file_source(resolved):
        if is_volume_source(resolved):
            _save_volume_file(df, resolved)
            return
        path = _normalize_local_path(resolved)
        path.parent.mkdir(parents=True, exist_ok=True)
        suffix = path.suffix.lower()
        logger.info("[outfile] Saving file source %s (%d rows)", path, len(df))
        if suffix == ".parquet":
            df.to_parquet(path, index=False)
        elif suffix in {".xlsx", ".xls"}:
            df.to_excel(path, index=False)
        elif suffix == ".json":
            df.to_json(path, orient="records", indent=2)
        elif suffix == ".tsv":
            df.to_csv(path, sep="\t", index=False)
        else:
            df.to_csv(path, index=False)
        return
    logger.info("[outfile] Saving Unity Catalog table %s (%d rows)", resolved, len(df))
    merge_dataframe(resolved, df, key="ENGINE_SERIAL_NUM")


def apply_corrections(updates: list[dict], source: str | None = None) -> int:
    """Apply cell-level corrections to the active source.

    Each update dict carries ``ENGINE_SERIAL_NUM``, ``reason_code``, ``column`` and
    ``new_value``. Corrections are keyed on (ENGINE_SERIAL_NUM, REASON_CODE).

    - File / Volume source: load, edit in memory, and rewrite the whole file
      (files are bounded and cannot be updated cell-wise).
    - Unity Catalog table: a batched MERGE whose source is only the corrected rows,
      so it scales with the number of corrections rather than table size and is
      immune to duplicate-key MERGE failures elsewhere in the table.

    Returns the number of corrections applied.
    """
    if not updates:
        return 0
    resolved = (source or get_outfile_source()).strip()

    if is_file_source(resolved):
        df = load_outfile(resolved)
        for update in updates:
            mask = (df["ENGINE_SERIAL_NUM"] == update["ENGINE_SERIAL_NUM"]) & (
                df["REASON_CODE"] == update["reason_code"]
            )
            df.loc[mask, update["column"]] = update["new_value"]
        save_outfile(df, resolved)
        return len(updates)

    cell_updates = [
        {
            "ENGINE_SERIAL_NUM": update["ENGINE_SERIAL_NUM"],
            "REASON_CODE": update["reason_code"],
            "column": update["column"],
            "new_value": update["new_value"],
        }
        for update in updates
    ]
    logger.info(
        "[outfile] Applying %d correction(s) to Unity Catalog table %s via targeted MERGE",
        len(cell_updates),
        resolved,
    )
    merge_cell_updates(
        resolved, cell_updates, key_columns=["ENGINE_SERIAL_NUM", "REASON_CODE"]
    )
    return len(cell_updates)


def backup_outfile(source: str | None = None) -> Path:
    """Snapshot the current outfile before applying corrections."""
    resolved = (source or get_outfile_source()).strip()
    snapshot_id = str(uuid.uuid4())
    timestamp = datetime.now()
    df = load_outfile(resolved)

    if is_file_source(resolved):
        if is_volume_source(resolved):
            volume_path = _volume_path(resolved)
            base, dot, suffix = volume_path.rpartition(".")
            backup_path = (
                f"{base}.backup-{snapshot_id}.{suffix}"
                if dot
                else f"{volume_path}.backup-{snapshot_id}"
            )
            _save_volume_file(df, backup_path)
            logger.info("[outfile] Volume backup written to %s", backup_path)
            return Path(backup_path)
        path = _normalize_local_path(resolved)
        backup_path = path.with_name(f"{path.stem}.backup-{snapshot_id}{path.suffix}")
        shutil.copy2(path, backup_path)
        logger.info("[outfile] File backup written to %s", backup_path)
        return backup_path

    df.insert(0, "snapshot_at", timestamp)
    df.insert(0, "snapshot_id", snapshot_id)
    append_dataframe(OUTFILE_BACKUPS_TABLE, df)
    return Path(f"{OUTFILE_BACKUPS_TABLE}/{snapshot_id}")
