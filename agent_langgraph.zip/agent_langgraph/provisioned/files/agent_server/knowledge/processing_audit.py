"""Processing audit log — records outfile processing runs and guards re-processing.

A "processing run" is recorded here after a *successful* analyze_outfile. On a
later attempt the guard decides what (if anything) to process, and records which
ingestion batches were handled so future runs can skip them.

Source identity / dedup differs by type:
  - file  : the file path. Once processed, blocked FOREVER (until forced).
  - table : per-INGESTION_ID *incremental* processing. Only ingestion batches not
            seen in any prior completed run are processed; already-remediated
            batches are skipped. When no new batches exist, the run is blocked
            (unless forced). A table with no INGESTION_ID column falls back to
            all-or-nothing dedup (blocked once processed, until forced).

``plan_processing`` returns a plan with ``allowed_ingestion_ids``:
  - None  → process the whole table (file source, fallback tables, or force).
  - list  → process ONLY rows whose INGESTION_ID is in this list (incremental).
"""

from __future__ import annotations

import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from agent_server.knowledge.uc_tables import append_dataframe
from api.services.databricks_sql import DatabricksSqlError, execute_sql

logger = logging.getLogger(__name__)

PROCESSING_AUDIT_TABLE = os.getenv(
    "PROCESSING_AUDIT_TABLE", "workspace.aidq.processing_audit_log"
)

# INGESTION_ID column stamped on the outfile table by the loader (see
# scripts/migrate_data_to_uc.py). Overridable in case the column is renamed.
INGESTION_ID_COLUMN = os.getenv("OUTFILE_INGESTION_COLUMN", "INGESTION_ID")

_UNKNOWN_VERSION = "unknown"

_DDL = f"""
CREATE TABLE IF NOT EXISTS {PROCESSING_AUDIT_TABLE} (
  audit_id STRING,
  source_identifier STRING,
  source_type STRING,
  source_version STRING,
  processed_date DATE,
  processed_at TIMESTAMP,
  processed_by STRING,
  thread_id STRING,
  status STRING,
  row_count BIGINT,
  bucket_count BIGINT,
  tickets_created BIGINT
) USING DELTA
"""

_table_ready = False


def _quote(value: Any) -> str:
    """SQL string literal with single-quote escaping."""
    return "'" + str(value).replace("'", "''") + "'"


def _ensure_table() -> None:
    global _table_ready
    if _table_ready:
        return
    execute_sql(_DDL)
    _table_ready = True


def _distinct_ingestion_ids(table_fqn: str) -> list[str]:
    """Distinct non-empty INGESTION_ID values currently in the table.

    Raises DatabricksSqlError when the column does not exist — the caller uses
    that to fall back to all-or-nothing dedup.
    """
    rows = execute_sql(
        f"SELECT DISTINCT `{INGESTION_ID_COLUMN}` AS ingestion_id FROM {table_fqn}"
    )
    return [
        str(r.get("ingestion_id"))
        for r in rows
        if r.get("ingestion_id") not in (None, "")
    ]


def _seen_ingestion_ids(source_identifier: str) -> set[str]:
    """Union of all ingestion ids recorded across prior completed runs."""
    rows = execute_sql(
        "SELECT source_version FROM "
        f"{PROCESSING_AUDIT_TABLE} "
        f"WHERE source_identifier = {_quote(source_identifier)} AND status = 'completed'"
    )
    seen: set[str] = set()
    for r in rows:
        for part in str(r.get("source_version") or "").split(","):
            part = part.strip()
            if part and part != _UNKNOWN_VERSION:
                seen.add(part)
    return seen


def _latest_completed(
    source_identifier: str, version: str | None = None
) -> dict[str, Any] | None:
    conditions = [
        f"source_identifier = {_quote(source_identifier)}",
        "status = 'completed'",
    ]
    if version is not None:
        conditions.append(f"source_version = {_quote(version)}")
    rows = execute_sql(
        "SELECT CAST(processed_date AS STRING) AS processed_date, "
        "CAST(processed_at AS STRING) AS processed_at "
        f"FROM {PROCESSING_AUDIT_TABLE} WHERE {' AND '.join(conditions)} "
        "ORDER BY processed_at DESC LIMIT 1"
    )
    return rows[0] if rows else None


def _plan(
    *,
    blocked: bool = False,
    processed_on: str | None = None,
    allowed_ingestion_ids: list[str] | None = None,
    source_version: str = _UNKNOWN_VERSION,
) -> dict[str, Any]:
    return {
        "blocked": blocked,
        "processed_on": processed_on,
        "allowed_ingestion_ids": allowed_ingestion_ids,
        "source_version": source_version,
    }


def plan_processing(
    *, source_identifier: str, source_type: str, force: bool
) -> dict[str, Any]:
    """Decide whether/what to process for this source.

    Returns a plan dict (see module docstring). On any failure it degrades to
    "process the whole source" so the guard never blocks the pipeline by accident.
    """
    # Fail-open default: process everything.
    fallback = _plan(
        source_version=source_identifier
        if source_type == "file"
        else _UNKNOWN_VERSION
    )
    try:
        _ensure_table()

        # FILE — path identity, blocked forever until forced.
        if source_type == "file":
            if force:
                return _plan(source_version=source_identifier)
            prior = _latest_completed(source_identifier)
            if prior:
                return _plan(
                    blocked=True,
                    processed_on=prior.get("processed_date"),
                    source_version=source_identifier,
                )
            return _plan(source_version=source_identifier)

        # TABLE — try per-INGESTION_ID incremental.
        try:
            current_ids = _distinct_ingestion_ids(source_identifier)
        except DatabricksSqlError:
            # No INGESTION_ID column → all-or-nothing dedup (version=sentinel).
            logger.warning(
                "[audit] %s has no %s column — falling back to all-or-nothing dedup",
                source_identifier,
                INGESTION_ID_COLUMN,
            )
            if force:
                return _plan(source_version=_UNKNOWN_VERSION)
            prior = _latest_completed(source_identifier, version=_UNKNOWN_VERSION)
            if prior:
                return _plan(
                    blocked=True,
                    processed_on=prior.get("processed_date"),
                    source_version=_UNKNOWN_VERSION,
                )
            return _plan(source_version=_UNKNOWN_VERSION)

        if force:
            # Reprocess the whole table; mark every current batch as seen.
            return _plan(
                allowed_ingestion_ids=None,
                source_version=",".join(sorted(current_ids)) or _UNKNOWN_VERSION,
            )

        seen = _seen_ingestion_ids(source_identifier)
        new_ids = sorted(i for i in current_ids if i not in seen)
        if not new_ids:
            prior = _latest_completed(source_identifier)
            if prior:
                return _plan(
                    blocked=True,
                    processed_on=prior.get("processed_date"),
                    allowed_ingestion_ids=[],
                    source_version=",".join(sorted(current_ids)) or _UNKNOWN_VERSION,
                )
            # No prior run and nothing new (e.g. empty table) → just run on all.
            return _plan(
                source_version=",".join(sorted(current_ids)) or _UNKNOWN_VERSION
            )

        return _plan(
            allowed_ingestion_ids=new_ids,
            source_version=",".join(new_ids),
        )
    except Exception:
        logger.exception(
            "[audit] plan_processing failed for %r — processing whole source",
            source_identifier,
        )
        return fallback


def record_processing(
    *,
    source_identifier: str,
    source_type: str,
    source_version: str,
    processed_by: str | None,
    thread_id: str | None,
    status: str = "completed",
    row_count: int = 0,
    bucket_count: int = 0,
    tickets_created: int = 0,
) -> None:
    """Best-effort append of one audit row after a successful processing run."""
    try:
        _ensure_table()
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        frame = pd.DataFrame(
            [
                {
                    "audit_id": str(uuid.uuid4()),
                    "source_identifier": source_identifier,
                    "source_type": source_type,
                    "source_version": source_version or _UNKNOWN_VERSION,
                    "processed_date": now.date(),
                    "processed_at": now,
                    "processed_by": processed_by or "unknown",
                    "thread_id": thread_id or "",
                    "status": status,
                    "row_count": int(row_count),
                    "bucket_count": int(bucket_count),
                    "tickets_created": int(tickets_created),
                }
            ]
        )
        append_dataframe(PROCESSING_AUDIT_TABLE, frame)
        logger.info(
            "[audit] Recorded processing of %r (type=%s, version=%r, rows=%d, buckets=%d)",
            source_identifier,
            source_type,
            source_version,
            row_count,
            bucket_count,
        )
    except Exception:
        logger.exception(
            "[audit] Failed to record processing for %r", source_identifier
        )
