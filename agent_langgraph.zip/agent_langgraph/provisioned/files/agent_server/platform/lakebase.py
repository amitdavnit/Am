"""Lakebase (Postgres) connection helpers for AIDQ app state + pgvector.

Performance notes:
  - OAuth tokens are cached (~10 min) so we do not re-auth via Databricks CLI
    on every query (that was adding multi-second latency per request).
  - Connections are reused via a small ConnectionPool.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from contextlib import contextmanager
from typing import Any, Iterator, Sequence
from urllib.parse import quote_plus

logger = logging.getLogger(__name__)

AIDQ_SCHEMA = os.getenv("AIDQ_PG_SCHEMA", "aidq")

# Refresh OAuth a bit before typical 1h expiry; override with LAKEBASE_TOKEN_TTL_SECONDS.
_TOKEN_TTL_SECONDS = float(os.getenv("LAKEBASE_TOKEN_TTL_SECONDS", "600"))
_POOL_MAX_SIZE = int(os.getenv("LAKEBASE_POOL_MAX_SIZE", "8"))

_lock = threading.RLock()
_ws_client: Any | None = None
_cached_token: str | None = None
_cached_token_at: float = 0.0
_cached_username: str | None = None
_pool: Any | None = None
_pool_dsn: str | None = None


def lakebase_configured() -> bool:
    """True when enough env is set to open a Postgres connection."""
    if os.getenv("POSTGRES_URL") or os.getenv("DATABASE_URL"):
        return True
    return bool(os.getenv("PGHOST") and os.getenv("PGDATABASE"))


def _workspace_client():
    """Reuse one WorkspaceClient — constructing it triggers CLI auth every time."""
    global _ws_client
    with _lock:
        if _ws_client is None:
            from databricks.sdk import WorkspaceClient

            _ws_client = WorkspaceClient()
        return _ws_client


def _oauth_token() -> str:
    """Fetch (and cache) a Lakebase / workspace OAuth token."""
    global _cached_token, _cached_token_at

    with _lock:
        now = time.monotonic()
        if (
            _cached_token
            and (now - _cached_token_at) < _TOKEN_TTL_SECONDS
        ):
            return _cached_token

        w = _workspace_client()
        instance = os.getenv("LAKEBASE_INSTANCE_NAME")
        token: str | None = None
        if instance:
            try:
                from databricks.sdk.service.database import (
                    GenerateDatabaseCredentialRequest,
                )

                cred = w.database.generate_database_credential(
                    request=GenerateDatabaseCredentialRequest(
                        instance_names=[instance]
                    )
                )
                if cred and cred.token:
                    token = cred.token
            except Exception:
                logger.debug(
                    "[lakebase] generate_database_credential failed; "
                    "falling back to workspace token",
                    exc_info=True,
                )
        if not token:
            token = (
                w.config.authenticate()
                .get("Authorization", "")
                .removeprefix("Bearer ")
                .strip()
            )
        if not token:
            raise RuntimeError("Failed to obtain Databricks OAuth token for Lakebase")

        _cached_token = token
        _cached_token_at = now
        logger.debug(
            "[lakebase] Refreshed OAuth token (ttl=%ss)", int(_TOKEN_TTL_SECONDS)
        )
        return token


def _resolve_username() -> str:
    global _cached_username
    if os.getenv("PGUSER"):
        return os.environ["PGUSER"]
    with _lock:
        if _cached_username:
            return _cached_username
        try:
            w = _workspace_client()
            me = w.current_user.me()
            _cached_username = (
                me.user_name
                or (me.emails[0].value if me.emails else None)
                or "postgres"
            )
            return _cached_username
        except Exception:
            return os.getenv("USER", "postgres")


def get_connection_dsn(*, force_refresh: bool = False) -> str:
    """Build a Postgres DSN for Lakebase / local Postgres."""
    url = os.getenv("POSTGRES_URL") or os.getenv("DATABASE_URL")
    if url:
        return url

    if not lakebase_configured():
        raise RuntimeError(
            "Lakebase is not configured. Set POSTGRES_URL or PGHOST+PGDATABASE "
            "(and LAKEBASE_INSTANCE_NAME for OAuth), then re-run quickstart."
        )

    if force_refresh:
        with _lock:
            global _cached_token, _cached_token_at
            _cached_token = None
            _cached_token_at = 0.0

    host = os.environ["PGHOST"]
    database = os.environ.get("PGDATABASE", "databricks_postgres")
    port = os.environ.get("PGPORT", "5432")
    user = _resolve_username()
    password = os.getenv("PGPASSWORD") or _oauth_token()
    sslmode = os.getenv("PGSSLMODE", "require")
    return (
        f"postgresql://{quote_plus(user)}:{quote_plus(password)}"
        f"@{host}:{port}/{database}?sslmode={sslmode}"
    )


def _get_pool():
    """Lazy-init a process-wide connection pool keyed by current DSN."""
    global _pool, _pool_dsn
    from psycopg_pool import ConnectionPool
    from psycopg.rows import dict_row

    dsn = get_connection_dsn()
    with _lock:
        if _pool is not None and _pool_dsn == dsn:
            return _pool
        if _pool is not None:
            try:
                _pool.close()
            except Exception:
                logger.debug("[lakebase] Error closing stale pool", exc_info=True)
            _pool = None
        logger.info(
            "[lakebase] Opening connection pool (max_size=%s)", _POOL_MAX_SIZE
        )
        _pool = ConnectionPool(
            conninfo=dsn,
            min_size=1,
            max_size=_POOL_MAX_SIZE,
            kwargs={"row_factory": dict_row},
            open=True,
        )
        _pool_dsn = dsn
        return _pool


def reset_lakebase_pool() -> None:
    """Drop cached token + pool (e.g. after auth errors)."""
    global _pool, _pool_dsn, _cached_token, _cached_token_at
    with _lock:
        if _pool is not None:
            try:
                _pool.close()
            except Exception:
                pass
            _pool = None
            _pool_dsn = None
        _cached_token = None
        _cached_token_at = 0.0


@contextmanager
def get_connection() -> Iterator[Any]:
    """Yield a pooled connection; commit on success, rollback on error."""
    pool = _get_pool()
    with pool.connection() as conn:
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise

def execute(
    sql: str,
    params: Sequence[Any] | dict[str, Any] | None = None,
    *,
    fetch: bool = True,
) -> list[dict[str, Any]]:
    """Execute a SQL statement and optionally return rows as dicts."""
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            if not fetch:
                return []
            if cur.description is None:
                return []
            return list(cur.fetchall())


def execute_script(sql_text: str) -> None:
    """Run a multi-statement SQL script."""
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql_text)
