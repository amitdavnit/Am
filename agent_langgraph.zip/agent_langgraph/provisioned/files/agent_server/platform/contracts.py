"""Shared agent platform contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass
class AgentContext:
    conversation_id: str
    user_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class AgentRunner(Protocol):
    name: str

    def run(self, input: Any, context: AgentContext) -> Any: ...
