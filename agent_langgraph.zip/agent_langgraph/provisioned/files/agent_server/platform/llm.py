"""Shared Databricks LLM helper — supports per-agent endpoints via config/agents.yaml."""

from __future__ import annotations

import os
from functools import lru_cache

from databricks_langchain import ChatDatabricks

from config import get_agent_model_config


@lru_cache(maxsize=16)
def get_llm(agent_name: str | None = None) -> ChatDatabricks:
    """Return a ChatDatabricks model for the given agent (or shared default)."""
    if agent_name:
        cfg = get_agent_model_config(agent_name)
        return ChatDatabricks(
            endpoint=cfg["endpoint"],
            temperature=cfg["temperature"],
            streaming=True,
        )
    return ChatDatabricks(
        endpoint=os.getenv("DATABRICKS_LLM_ENDPOINT", "databricks-gpt-5-2"),
        temperature=float(os.getenv("DATABRICKS_LLM_TEMPERATURE", "0")),
        streaming=True,
    )


# Backward-compatible alias used throughout the multi-agent stack.
def get_bedrock_llm(agent_name: str | None = None) -> ChatDatabricks:
    return get_llm(agent_name)
