"""Shared path configuration."""

from __future__ import annotations

import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DATA_DIR = Path(os.getenv("SOP_DATA_DIR", PROJECT_ROOT / "data"))
CONFIG_DIR = Path(
    os.getenv("SOP_CONFIG_DIR", PROJECT_ROOT / "aidq-sop-knowledgebase")
)

OUTFILE_PATH = Path(os.getenv("SOP_OUTFILE_PATH", DATA_DIR / "outfile.csv"))
SOURCE_PATH = Path(os.getenv("SOP_SOURCE_PATH", DATA_DIR / "source_reference.csv"))
MAPPING_PATH = Path(os.getenv("SOP_MAPPING_PATH", CONFIG_DIR / "sop_mapping.json"))
INCIDENTS_MASTER_PATH = Path(os.getenv("INCIDENTS_MASTER_PATH", DATA_DIR / "incidents_master.csv"))
CHROMA_DIR = Path(os.getenv("CHROMA_PERSIST_DIR", DATA_DIR / "chroma_db"))
BACKUP_DIR = DATA_DIR / "backups"
LOGS_DIR = PROJECT_ROOT / "logs"
