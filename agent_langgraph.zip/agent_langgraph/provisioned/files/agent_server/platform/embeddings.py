"""Shared Databricks embedding model."""

from __future__ import annotations

import os
from functools import lru_cache

from databricks_langchain import DatabricksEmbeddings


@lru_cache(maxsize=1)
def get_embedding_model() -> DatabricksEmbeddings:
    """Return the shared Databricks embedding model used by RCA / vector search."""
    return DatabricksEmbeddings(
        endpoint=os.getenv(
            "DATABRICKS_EMBEDDING_ENDPOINT",
            "databricks-gte-large-en",
        )
    )
