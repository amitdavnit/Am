"""Load agent model configuration from config/agents.yaml + env overrides."""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

_CONFIG_PATH = Path(
    os.getenv(
        "AIDQ_AGENTS_CONFIG",
        Path(__file__).resolve().parent.parent.parent / "config" / "agents.yaml",
    )
)


@lru_cache(maxsize=1)
def load_agents_config() -> dict[str, Any]:
    if not _CONFIG_PATH.exists():
        return {
            "defaults": {"endpoint": "databricks-gpt-5-2", "temperature": 0},
            "agents": {},
            "embeddings": {"endpoint": "databricks-gte-large-en", "dims": 1024},
        }
    with _CONFIG_PATH.open(encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return data


def get_agent_model_config(agent_name: str) -> dict[str, Any]:
    """Resolve endpoint + temperature for an agent.

    Precedence: AGENT_<NAME>_LLM_* env → agents.yaml agent block → defaults → global env.
    """
    cfg = load_agents_config()
    defaults = dict(cfg.get("defaults") or {})
    agent_cfg = dict((cfg.get("agents") or {}).get(agent_name) or {})

    env_key = agent_name.upper().replace("-", "_")
    endpoint = (
        os.getenv(f"AGENT_{env_key}_LLM_ENDPOINT")
        or agent_cfg.get("endpoint")
        or defaults.get("endpoint")
        or os.getenv("DATABRICKS_LLM_ENDPOINT", "databricks-gpt-5-2")
    )
    temp_raw = (
        os.getenv(f"AGENT_{env_key}_LLM_TEMPERATURE")
        or agent_cfg.get("temperature")
        or defaults.get("temperature")
        or os.getenv("DATABRICKS_LLM_TEMPERATURE", "0")
    )
    return {"endpoint": str(endpoint), "temperature": float(temp_raw)}


def get_embedding_config() -> dict[str, Any]:
    cfg = load_agents_config()
    emb = dict(cfg.get("embeddings") or {})
    return {
        "endpoint": os.getenv(
            "DATABRICKS_EMBEDDING_ENDPOINT",
            emb.get("endpoint", "databricks-gte-large-en"),
        ),
        "dims": int(
            os.getenv("EMBEDDING_DIMS", emb.get("dims", 1024))
        ),
    }
