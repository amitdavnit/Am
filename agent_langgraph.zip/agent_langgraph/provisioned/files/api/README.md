# AIDQ API layer (top-level `api/` package)

## Layout

```
Browser
  └─ React UI (e2e-chatbot-app-next)
       ├─ /api/*          → Express proxies to agent
       └─ AIDO Assistant panel
  └─ FastAPI (agent_server.start_server)
       ├─ /api/v1/*       → api/ (this package)
       └─ /invocations    → agent_server (streaming agent)
```

## Endpoints

| Path | Purpose |
|------|---------|
| `GET /api/v1/health` | Health check |
| `GET /api/v1/me` | Logged-in user (Databricks forwarded headers / local fallback) |
| `GET /api/v1/incidents` | Incident list from UC table |
| `GET /api/v1/threads` | Chat thread history (Lakebase when configured, else UC) |
| `POST /api/v1/threads` | Create thread |
| `GET /api/v1/threads/{id}` | Thread + messages |
| `POST /api/v1/threads/{id}/messages` | Persist chat turns |
| `GET /api/v1/notifications` | HITL approval inbox |
| `GET /api/v1/notifications/count` | Badge counts |
| `POST /api/v1/notifications/{id}/approve` | Approve + resume graph |
| `POST /api/v1/notifications/{id}/reject` | Reject + resume graph |
| `POST /api/v1/feedback` | Log thumbs/comment feedback |

## Storage

| Data | Store |
|------|--------|
| Chat threads / messages | **Lakebase** `aidq.chat_*` |
| Notifications / HITL | **Lakebase** `aidq.notifications` |
| Operational incidents | **Lakebase** `aidq.incidents` |
| Incident history + pgvector | **Lakebase** `aidq.incident_history` / `incident_embeddings` |
| Feedback | **Lakebase** `aidq.feedback_events` |
| Outfile / source / SOP knowledge | Unity Catalog Delta (DQ pipeline) |
