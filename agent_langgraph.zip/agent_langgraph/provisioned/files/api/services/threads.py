"""Lakebase-backed chat thread store (with UC Delta fallback)."""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any

from agent_server.platform.lakebase import AIDQ_SCHEMA, execute, lakebase_configured

logger = logging.getLogger(__name__)

# Legacy UC tables used only when Lakebase is not configured.
_UC_THREADS = os.getenv("CHAT_THREADS_TABLE", "workspace.aidq.chat_threads")
_UC_MESSAGES = os.getenv("CHAT_MESSAGES_TABLE", "workspace.aidq.chat_messages")


def _use_lakebase() -> bool:
    """Chat storage is Lakebase-only. Set CHAT_STORE=uc only for emergency UC Delta access."""
    if os.getenv("CHAT_STORE", "lakebase").lower() == "uc":
        return False
    if not lakebase_configured():
        raise RuntimeError(
            "Lakebase is required for chat history. Set PGHOST+PGDATABASE "
            "(CHAT_STORE=uc temporarily restores Unity Catalog Delta)."
        )
    return True


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _as_iso(value: Any) -> str | None:
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value).replace(" ", "T")


def _decode_json(value: Any, default: Any) -> Any:
    if value is None or value == "":
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except (TypeError, json.JSONDecodeError):
        return default


def list_threads(
    *,
    user_id: str | None = None,
    limit: int = 50,
    ending_before: str | None = None,
) -> list[dict[str, Any]]:
    if not _use_lakebase():
        return _uc_list_threads(user_id=user_id, limit=limit, ending_before=ending_before)

    clauses: list[str] = []
    params: dict[str, Any] = {"limit": max(1, min(limit, 200))}
    if user_id:
        clauses.append("t.user_id = %(user_id)s")
        params["user_id"] = user_id
    if ending_before:
        clauses.append(
            """t.updated_at < (
                SELECT updated_at FROM {schema}.chat_threads
                WHERE thread_id = %(ending_before)s
            )""".format(schema=AIDQ_SCHEMA)
        )
        params["ending_before"] = ending_before
    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    rows = execute(
        f"""
        SELECT t.thread_id, t.user_id, t.title, t.created_at, t.updated_at,
               COUNT(m.message_id) AS message_count
        FROM {AIDQ_SCHEMA}.chat_threads t
        LEFT JOIN {AIDQ_SCHEMA}.chat_messages m ON m.thread_id = t.thread_id
        {where}
        GROUP BY t.thread_id, t.user_id, t.title, t.created_at, t.updated_at
        ORDER BY t.updated_at DESC
        LIMIT %(limit)s
        """,
        params,
    )
    return [
        {
            "id": row["thread_id"],
            "user_id": row.get("user_id"),
            "title": row.get("title") or "New chat",
            "created_at": _as_iso(row.get("created_at")),
            "updated_at": _as_iso(row.get("updated_at")),
            "message_count": int(row.get("message_count") or 0),
        }
        for row in rows
    ]


def get_thread(thread_id: str) -> dict[str, Any] | None:
    if not _use_lakebase():
        return _uc_get_thread(thread_id)

    rows = execute(
        f"""
        SELECT thread_id, user_id, title, created_at, updated_at
        FROM {AIDQ_SCHEMA}.chat_threads
        WHERE thread_id = %(thread_id)s
        LIMIT 1
        """,
        {"thread_id": thread_id},
    )
    if not rows:
        return None
    row = rows[0]
    messages = execute(
        f"""
        SELECT message_id, role, content, parts_json, attachments_json,
               trace_id, created_at
        FROM {AIDQ_SCHEMA}.chat_messages
        WHERE thread_id = %(thread_id)s
        ORDER BY created_at, message_id
        """,
        {"thread_id": thread_id},
    )
    return {
        "id": row["thread_id"],
        "user_id": row.get("user_id"),
        "title": row.get("title") or "New chat",
        "created_at": _as_iso(row.get("created_at")),
        "updated_at": _as_iso(row.get("updated_at")),
        "messages": [
            {
                "id": msg["message_id"],
                "role": msg["role"],
                "content": msg.get("content") or "",
                "parts": _decode_json(msg.get("parts_json"), None),
                "attachments": _decode_json(msg.get("attachments_json"), []),
                "trace_id": msg.get("trace_id"),
                "created_at": _as_iso(msg.get("created_at")),
            }
            for msg in messages
        ],
    }


def create_thread(
    *, user_id: str, title: str | None = None, thread_id: str | None = None
) -> dict[str, Any]:
    if not _use_lakebase():
        return _uc_create_thread(user_id=user_id, title=title, thread_id=thread_id)

    thread_id = thread_id or str(uuid.uuid4())
    execute(
        f"""
        INSERT INTO {AIDQ_SCHEMA}.chat_threads (thread_id, user_id, title, created_at, updated_at)
        VALUES (%(thread_id)s, %(user_id)s, %(title)s, NOW(), NOW())
        ON CONFLICT (thread_id) DO NOTHING
        """,
        {
            "thread_id": thread_id,
            "user_id": user_id,
            "title": title or "New chat",
        },
        fetch=False,
    )
    return get_thread(thread_id) or {
        "id": thread_id,
        "user_id": user_id,
        "title": title or "New chat",
        "created_at": _now(),
        "updated_at": _now(),
        "messages": [],
    }


def append_messages(
    thread_id: str,
    messages: list[dict[str, Any]],
    *,
    title: str | None = None,
) -> dict[str, Any] | None:
    if not _use_lakebase():
        return _uc_append_messages(thread_id, messages, title=title)

    thread = get_thread(thread_id)
    if not thread:
        return None

    for msg in messages:
        message_id = msg.get("id") or str(uuid.uuid4())
        execute(
            f"""
            INSERT INTO {AIDQ_SCHEMA}.chat_messages (
                message_id, thread_id, role, content, parts_json,
                attachments_json, trace_id, created_at
            ) VALUES (
                %(message_id)s, %(thread_id)s, %(role)s, %(content)s,
                %(parts_json)s::jsonb, %(attachments_json)s::jsonb,
                %(trace_id)s, COALESCE(%(created_at)s::timestamptz, NOW())
            )
            ON CONFLICT (message_id) DO UPDATE SET
                content = EXCLUDED.content,
                parts_json = EXCLUDED.parts_json,
                attachments_json = EXCLUDED.attachments_json,
                trace_id = COALESCE(EXCLUDED.trace_id, {AIDQ_SCHEMA}.chat_messages.trace_id),
                created_at = EXCLUDED.created_at
            """,
            {
                "message_id": message_id,
                "thread_id": thread_id,
                "role": msg["role"],
                "content": msg.get("content") or "",
                "parts_json": json.dumps(msg["parts"])
                if msg.get("parts") is not None
                else None,
                "attachments_json": json.dumps(msg.get("attachments") or []),
                "trace_id": msg.get("trace_id"),
                "created_at": msg.get("created_at"),
            },
            fetch=False,
        )

    new_title = title
    if not new_title and thread.get("title") in (None, "", "New chat"):
        first_user = next(
            (m for m in messages if m.get("role") == "user" and m.get("content")),
            None,
        )
        if first_user:
            text = str(first_user["content"]).strip().replace("\n", " ")
            new_title = text[:48] + ("..." if len(text) > 48 else "")

    if new_title:
        execute(
            f"""
            UPDATE {AIDQ_SCHEMA}.chat_threads
            SET updated_at = NOW(), title = %(title)s
            WHERE thread_id = %(thread_id)s
            """,
            {"thread_id": thread_id, "title": new_title},
            fetch=False,
        )
    else:
        execute(
            f"""
            UPDATE {AIDQ_SCHEMA}.chat_threads
            SET updated_at = NOW()
            WHERE thread_id = %(thread_id)s
            """,
            {"thread_id": thread_id},
            fetch=False,
        )
    return get_thread(thread_id)


def delete_thread(thread_id: str) -> bool:
    if not _use_lakebase():
        return _uc_delete_thread(thread_id)
    if not get_thread(thread_id):
        return False
    execute(
        f"DELETE FROM {AIDQ_SCHEMA}.chat_messages WHERE thread_id = %(thread_id)s",
        {"thread_id": thread_id},
        fetch=False,
    )
    execute(
        f"DELETE FROM {AIDQ_SCHEMA}.chat_threads WHERE thread_id = %(thread_id)s",
        {"thread_id": thread_id},
        fetch=False,
    )
    return True


# ─── UC Delta fallback (legacy) ───────────────────────────────────────────────

def _sql(value: Any) -> str:
    if value is None:
        return "NULL"
    escaped = str(value).replace("\\", "\\\\").replace("'", "''")
    return "'" + escaped + "'"


def _uc_list_threads(*, user_id, limit, ending_before):
    from api.services.databricks_sql import execute_sql

    filters = [f"t.user_id = {_sql(user_id)}"] if user_id else []
    if ending_before:
        filters.append(
            f"""t.updated_at < (
                SELECT updated_at FROM {_UC_THREADS}
                WHERE thread_id = {_sql(ending_before)}
            )"""
        )
    where = f"WHERE {' AND '.join(filters)}" if filters else ""
    rows = execute_sql(
        f"""
        SELECT t.thread_id, t.user_id, t.title, t.created_at, t.updated_at,
               COUNT(m.message_id) AS message_count
        FROM {_UC_THREADS} t
        LEFT JOIN {_UC_MESSAGES} m ON m.thread_id = t.thread_id
        {where}
        GROUP BY t.thread_id, t.user_id, t.title, t.created_at, t.updated_at
        ORDER BY t.updated_at DESC
        LIMIT {max(1, min(limit, 200))}
        """
    )
    return [
        {
            "id": row["thread_id"],
            "user_id": row.get("user_id"),
            "title": row.get("title") or "New chat",
            "created_at": _as_iso(row.get("created_at")),
            "updated_at": _as_iso(row.get("updated_at")),
            "message_count": int(row.get("message_count") or 0),
        }
        for row in rows
    ]


def _uc_get_thread(thread_id: str):
    from api.services.databricks_sql import execute_sql

    rows = execute_sql(
        f"""
        SELECT thread_id, user_id, title, created_at, updated_at
        FROM {_UC_THREADS}
        WHERE thread_id = {_sql(thread_id)}
        LIMIT 1
        """
    )
    if not rows:
        return None
    row = rows[0]
    messages = execute_sql(
        f"""
        SELECT message_id, role, content, parts_json, attachments_json,
               trace_id, created_at
        FROM {_UC_MESSAGES}
        WHERE thread_id = {_sql(thread_id)}
        ORDER BY created_at, message_id
        """
    )
    return {
        "id": row["thread_id"],
        "user_id": row.get("user_id"),
        "title": row.get("title") or "New chat",
        "created_at": _as_iso(row.get("created_at")),
        "updated_at": _as_iso(row.get("updated_at")),
        "messages": [
            {
                "id": msg["message_id"],
                "role": msg["role"],
                "content": msg.get("content") or "",
                "parts": _decode_json(msg.get("parts_json"), None),
                "attachments": _decode_json(msg.get("attachments_json"), []),
                "trace_id": msg.get("trace_id"),
                "created_at": _as_iso(msg.get("created_at")),
            }
            for msg in messages
        ],
    }


def _uc_create_thread(*, user_id, title, thread_id):
    from api.services.databricks_sql import execute_sql

    thread_id = thread_id or str(uuid.uuid4())
    now = _now()
    execute_sql(
        f"""
        MERGE INTO {_UC_THREADS} target
        USING (
          SELECT {_sql(thread_id)} AS thread_id, {_sql(user_id)} AS user_id,
                 {_sql(title or "New chat")} AS title,
                 TIMESTAMP({_sql(now)}) AS created_at
        ) source
        ON target.thread_id = source.thread_id
        WHEN NOT MATCHED THEN INSERT
          (thread_id, user_id, title, created_at, updated_at)
          VALUES (source.thread_id, source.user_id, source.title,
                  source.created_at, source.created_at)
        """
    )
    return _uc_get_thread(thread_id) or {
        "id": thread_id,
        "user_id": user_id,
        "title": title or "New chat",
        "created_at": now,
        "updated_at": now,
        "messages": [],
    }


def _uc_append_messages(thread_id, messages, *, title):
    from api.services.databricks_sql import execute_sql

    thread = _uc_get_thread(thread_id)
    if not thread:
        return None
    now = _now()
    for msg in messages:
        message_id = msg.get("id") or str(uuid.uuid4())
        created_at = msg.get("created_at") or now
        execute_sql(
            f"""
            MERGE INTO {_UC_MESSAGES} target
            USING (
              SELECT {_sql(message_id)} AS message_id,
                     {_sql(thread_id)} AS thread_id,
                     {_sql(msg["role"])} AS role,
                     {_sql(msg.get("content") or "")} AS content,
                     {_sql(json.dumps(msg.get("parts")) if msg.get("parts") is not None else None)} AS parts_json,
                     {_sql(json.dumps(msg.get("attachments") or []))} AS attachments_json,
                     {_sql(msg.get("trace_id"))} AS trace_id,
                     TIMESTAMP({_sql(created_at)}) AS created_at
            ) source
            ON target.message_id = source.message_id
            WHEN MATCHED THEN UPDATE SET
              content = source.content,
              parts_json = source.parts_json,
              attachments_json = source.attachments_json,
              trace_id = COALESCE(source.trace_id, target.trace_id),
              created_at = source.created_at
            WHEN NOT MATCHED THEN INSERT *
            """
        )

    new_title = title
    if not new_title and thread.get("title") in (None, "", "New chat"):
        first_user = next(
            (m for m in messages if m.get("role") == "user" and m.get("content")),
            None,
        )
        if first_user:
            text = str(first_user["content"]).strip().replace("\n", " ")
            new_title = text[:48] + ("..." if len(text) > 48 else "")

    execute_sql(
        f"""
        UPDATE {_UC_THREADS}
        SET updated_at = TIMESTAMP({_sql(now)})
            {f", title = {_sql(new_title)}" if new_title else ""}
        WHERE thread_id = {_sql(thread_id)}
        """
    )
    return _uc_get_thread(thread_id)


def _uc_delete_thread(thread_id: str) -> bool:
    from api.services.databricks_sql import execute_sql

    if not _uc_get_thread(thread_id):
        return False
    execute_sql(f"DELETE FROM {_UC_MESSAGES} WHERE thread_id = {_sql(thread_id)}")
    execute_sql(f"DELETE FROM {_UC_THREADS} WHERE thread_id = {_sql(thread_id)}")
    return True
