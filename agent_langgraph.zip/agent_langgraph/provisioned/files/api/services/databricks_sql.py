"""Shared Databricks SQL helpers for the FastAPI API layer."""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Any

from databricks.sdk import WorkspaceClient

logger = logging.getLogger(__name__)

_client_lock = threading.Lock()
_workspace_client: WorkspaceClient | None = None


class DatabricksSqlError(RuntimeError):
    """Raised when a SQL statement fails or times out."""


def get_workspace_client() -> WorkspaceClient:
    """Reuse one WorkspaceClient — new clients re-run Databricks CLI auth."""
    global _workspace_client
    with _client_lock:
        if _workspace_client is None:
            _workspace_client = WorkspaceClient()
        return _workspace_client


def get_warehouse_id() -> str:
    warehouse_id = os.getenv("DATABRICKS_SQL_WAREHOUSE_ID", "").strip()
    if not warehouse_id:
        raise DatabricksSqlError(
            "DATABRICKS_SQL_WAREHOUSE_ID is not set. "
            "Add your SQL warehouse id to .env for incident queries."
        )
    return warehouse_id


def get_incident_table() -> str:
    return os.getenv("INCIDENT_TABLE", "workspace.aidq.incident").strip()


def execute_sql(statement: str, *, timeout_seconds: int = 60) -> list[dict[str, Any]]:
    """Run a SQL statement on the configured warehouse and return row dicts."""
    client = get_workspace_client()
    warehouse_id = get_warehouse_id()

    response = client.statement_execution.execute_statement(
        warehouse_id=warehouse_id,
        statement=statement,
        wait_timeout=f"{min(timeout_seconds, 50)}s",
    )

    state = response.status.state.value if response.status and response.status.state else None
    statement_id = response.statement_id

    deadline = time.time() + timeout_seconds
    poll = 0.4
    while state in {"PENDING", "RUNNING"} and time.time() < deadline:
        time.sleep(poll)
        poll = min(poll * 1.4, 2.0)
        response = client.statement_execution.get_statement(statement_id)
        state = response.status.state.value if response.status and response.status.state else None

    if state != "SUCCEEDED":
        message = None
        if response.status and response.status.error:
            message = response.status.error.message
        raise DatabricksSqlError(message or f"SQL statement ended with state={state}")

    manifest = response.manifest
    result = response.result
    if not manifest or not manifest.schema or not manifest.schema.columns:
        return []

    columns = [col.name for col in manifest.schema.columns]
    data_array = result.data_array if result and result.data_array else []
    rows: list[dict[str, Any]] = []
    for raw in data_array:
        rows.append({columns[i]: raw[i] if i < len(raw) else None for i in range(len(columns))})
    return rows
