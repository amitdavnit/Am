"""Incident domain service — Lakebase Postgres (aidq.incidents)."""

from __future__ import annotations

from typing import Any

from agent_server.platform.lakebase import AIDQ_SCHEMA, execute, lakebase_configured


class LakebaseStorageError(RuntimeError):
    """Raised when Lakebase is required but not available."""


def _require_lakebase() -> None:
    if not lakebase_configured():
        raise LakebaseStorageError(
            "Lakebase is required for incidents. Set PGHOST+PGDATABASE "
            "(or POSTGRES_URL) and LAKEBASE_AUTOSCALING_ENDPOINT."
        )


def _as_iso(value: Any) -> str | None:
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value).replace(" ", "T")


def _row_to_incident(row: dict[str, Any]) -> dict[str, Any]:
    normalized = {str(k).lower(): v for k, v in row.items()}

    def get(*keys: str):
        for key in keys:
            if key.lower() in normalized:
                return normalized[key.lower()]
        return None

    return {
        "incident_id": get("incident_id"),
        "violation_id": get("violation_id"),
        "title": get("title"),
        "description": get("description"),
        "priority": get("priority"),
        "status": get("status"),
        "assigned_to": get("assigned_to"),
        "created_date": _as_iso(get("created_date")),
        "closed_date": _as_iso(get("closed_date")),
    }


def list_incidents(
    *,
    status: str | None = None,
    priority: str | None = None,
    limit: int = 100,
) -> list[dict[str, Any]]:
    _require_lakebase()
    clauses: list[str] = []
    params: dict[str, Any] = {"limit": int(limit)}
    if status:
        clauses.append("status = %(status)s")
        params["status"] = status
    if priority:
        clauses.append("priority = %(priority)s")
        params["priority"] = priority
    where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
    rows = execute(
        f"""
        SELECT incident_id, violation_id, title, description, priority, status,
               assigned_to, created_date, closed_date
        FROM {AIDQ_SCHEMA}.incidents
        {where}
        ORDER BY created_date DESC NULLS LAST, incident_id
        LIMIT %(limit)s
        """,
        params,
    )
    return [_row_to_incident(row) for row in rows]


def get_incident(incident_id: str) -> dict[str, Any] | None:
    _require_lakebase()
    rows = execute(
        f"""
        SELECT incident_id, violation_id, title, description, priority, status,
               assigned_to, created_date, closed_date
        FROM {AIDQ_SCHEMA}.incidents
        WHERE incident_id = %(incident_id)s
        LIMIT 1
        """,
        {"incident_id": incident_id},
    )
    if not rows:
        return None
    return _row_to_incident(rows[0])


def upsert_incident(incident: dict[str, Any]) -> dict[str, Any]:
    """Insert or update an operational incident row."""
    _require_lakebase()
    incident_id = incident.get("incident_id")
    if not incident_id:
        raise ValueError("incident_id is required")
    execute(
        f"""
        INSERT INTO {AIDQ_SCHEMA}.incidents (
            incident_id, violation_id, title, description, priority, status,
            assigned_to, created_date, closed_date, updated_at
        ) VALUES (
            %(incident_id)s, %(violation_id)s, %(title)s, %(description)s,
            %(priority)s, %(status)s, %(assigned_to)s,
            %(created_date)s::timestamptz, %(closed_date)s::timestamptz, NOW()
        )
        ON CONFLICT (incident_id) DO UPDATE SET
            violation_id = EXCLUDED.violation_id,
            title = EXCLUDED.title,
            description = EXCLUDED.description,
            priority = EXCLUDED.priority,
            status = EXCLUDED.status,
            assigned_to = EXCLUDED.assigned_to,
            created_date = COALESCE(EXCLUDED.created_date, {AIDQ_SCHEMA}.incidents.created_date),
            closed_date = EXCLUDED.closed_date,
            updated_at = NOW()
        """,
        {
            "incident_id": incident_id,
            "violation_id": incident.get("violation_id"),
            "title": incident.get("title"),
            "description": incident.get("description"),
            "priority": incident.get("priority"),
            "status": incident.get("status"),
            "assigned_to": incident.get("assigned_to"),
            "created_date": incident.get("created_date"),
            "closed_date": incident.get("closed_date"),
        },
        fetch=False,
    )
    return get_incident(incident_id) or incident
