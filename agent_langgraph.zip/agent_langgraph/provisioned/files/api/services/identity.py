"""Resolve the logged-in user from Databricks Apps headers (or local fallback)."""

from __future__ import annotations

import os
from dataclasses import dataclass

from fastapi import Request


@dataclass
class UserInfo:
    id: str
    display_name: str
    email: str | None = None
    role: str = "Data Quality Analyst"


def _display_from_identity(raw: str) -> str:
    """Turn email/username into a friendly display name."""
    local = raw.split("@", 1)[0]
    parts = [p for p in local.replace(".", " ").replace("_", " ").replace("-", " ").split() if p]
    if not parts:
        return raw
    return " ".join(p.capitalize() for p in parts)


def get_user_from_request(request: Request) -> UserInfo:
    headers = {str(k).lower(): v for k, v in request.headers.items()}

    email = headers.get("x-forwarded-email")
    user = headers.get("x-forwarded-user")
    preferred = headers.get("x-forwarded-preferred-username")

    identity = email or preferred or user
    if identity:
        return UserInfo(
            id=identity,
            display_name=_display_from_identity(identity),
            email=email if email and "@" in email else None,
        )

    # Local development fallback
    local_name = os.getenv("LOCAL_USER_DISPLAY_NAME", "Local Developer")
    local_id = os.getenv("LOCAL_USER_ID", "local-dev")
    return UserInfo(id=local_id, display_name=local_name, email=None)
