"""Lakebase-backed feedback store (aidq.feedback_events)."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from agent_server.platform.lakebase import AIDQ_SCHEMA, execute, lakebase_configured


class LakebaseStorageError(RuntimeError):
    pass


def _require_lakebase() -> None:
    if not lakebase_configured():
        raise LakebaseStorageError(
            "Lakebase is required for feedback. Configure PGHOST+PGDATABASE."
        )


def append_feedback(event: dict[str, Any]) -> dict[str, Any]:
    _require_lakebase()
    nested = event.get("payload") or {}
    payload = {
        **event,
        "timestamp": event.get("timestamp")
        or datetime.now(timezone.utc).isoformat(),
    }
    feedback_id = event.get("feedback_id") or str(uuid.uuid4())
    execute(
        f"""
        INSERT INTO {AIDQ_SCHEMA}.feedback_events (
            feedback_id, conversation_id, message_id, user_id, display_name,
            rating, comment, question, answer_excerpt, workflow, agent_name,
            event_type, timestamp
        ) VALUES (
            %(feedback_id)s, %(conversation_id)s, %(message_id)s, %(user_id)s,
            %(display_name)s, %(rating)s, %(comment)s, %(question)s,
            %(answer_excerpt)s, %(workflow)s, %(agent_name)s, %(event_type)s,
            COALESCE(%(timestamp)s::timestamptz, NOW())
        )
        ON CONFLICT (feedback_id) DO UPDATE SET
            conversation_id = EXCLUDED.conversation_id,
            message_id = EXCLUDED.message_id,
            user_id = EXCLUDED.user_id,
            display_name = EXCLUDED.display_name,
            rating = EXCLUDED.rating,
            comment = EXCLUDED.comment,
            question = EXCLUDED.question,
            answer_excerpt = EXCLUDED.answer_excerpt,
            workflow = EXCLUDED.workflow,
            agent_name = EXCLUDED.agent_name,
            event_type = EXCLUDED.event_type,
            timestamp = EXCLUDED.timestamp
        """,
        {
            "feedback_id": feedback_id,
            "conversation_id": event.get("conversation_id"),
            "message_id": nested.get("message_id"),
            "user_id": nested.get("user_id"),
            "display_name": nested.get("display_name"),
            "rating": nested.get("rating"),
            "comment": nested.get("comment"),
            "question": nested.get("question"),
            "answer_excerpt": nested.get("answer_excerpt"),
            "workflow": event.get("workflow"),
            "agent_name": event.get("agent_name"),
            "event_type": event.get("event_type"),
            "timestamp": payload["timestamp"],
        },
        fetch=False,
    )
    # Also upsert by (user_id, message_id) when feedback_id differs — delete dupes
    if nested.get("user_id") and nested.get("message_id"):
        execute(
            f"""
            DELETE FROM {AIDQ_SCHEMA}.feedback_events
            WHERE user_id = %(user_id)s
              AND message_id = %(message_id)s
              AND feedback_id <> %(feedback_id)s
            """,
            {
                "user_id": nested.get("user_id"),
                "message_id": nested.get("message_id"),
                "feedback_id": feedback_id,
            },
            fetch=False,
        )
    payload["feedback_id"] = feedback_id
    return payload


def list_feedback(
    *, conversation_id: str, user_id: str
) -> list[dict[str, Any]]:
    _require_lakebase()
    return execute(
        f"""
        SELECT feedback_id, conversation_id, message_id, user_id, rating,
               comment, question, answer_excerpt, timestamp
        FROM {AIDQ_SCHEMA}.feedback_events
        WHERE conversation_id = %(conversation_id)s
          AND user_id = %(user_id)s
        ORDER BY timestamp
        """,
        {"conversation_id": conversation_id, "user_id": user_id},
    )
