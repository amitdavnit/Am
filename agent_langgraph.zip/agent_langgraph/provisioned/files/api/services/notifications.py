"""Notifications / HITL approval store (Lakebase)."""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from agent_server.platform.lakebase import AIDQ_SCHEMA, execute, lakebase_configured

logger = logging.getLogger(__name__)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _as_iso(value: Any) -> str | None:
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value).replace(" ", "T")


def _row_to_notification(row: dict[str, Any]) -> dict[str, Any]:
    payload = row.get("payload_json") or {}
    if isinstance(payload, str):
        payload = json.loads(payload)
    decision = row.get("decision_json")
    if isinstance(decision, str):
        decision = json.loads(decision)
    return {
        "id": str(row["id"]),
        "incident_number": row.get("incident_number"),
        "type": row["type"],
        "message": row["message"],
        "summary_markdown": row.get("summary_markdown"),
        "payload": payload,
        "requested_by": row.get("requested_by"),
        "assignee": row.get("assignee"),
        "requested_on": _as_iso(row.get("requested_on")),
        "priority": row.get("priority") or "medium",
        "status": row["status"],
        "thread_id": row.get("thread_id"),
        "interrupt_id": row.get("interrupt_id"),
        "decision": decision,
        "read_at": _as_iso(row.get("read_at")),
        "decided_at": _as_iso(row.get("decided_at")),
        "decided_by": row.get("decided_by"),
    }


def create_notification(
    *,
    type: str,
    message: str,
    requested_by: str,
    assignee: str | None = None,
    incident_number: str | None = None,
    summary_markdown: str | None = None,
    payload: dict[str, Any] | None = None,
    priority: str = "medium",
    thread_id: str | None = None,
    interrupt_id: str | None = None,
    status: str = "pending",
) -> dict[str, Any]:
    if not lakebase_configured():
        raise RuntimeError("Lakebase is required for notifications")

    notification_id = str(uuid.uuid4())
    rows = execute(
        f"""
        INSERT INTO {AIDQ_SCHEMA}.notifications (
            id, incident_number, type, message, summary_markdown, payload_json,
            requested_by, assignee, requested_on, priority, status,
            thread_id, interrupt_id
        ) VALUES (
            %(id)s::uuid, %(incident_number)s, %(type)s, %(message)s,
            %(summary_markdown)s, %(payload_json)s::jsonb,
            %(requested_by)s, %(assignee)s, NOW(), %(priority)s, %(status)s,
            %(thread_id)s, %(interrupt_id)s
        )
        RETURNING *
        """,
        {
            "id": notification_id,
            "incident_number": incident_number,
            "type": type,
            "message": message,
            "summary_markdown": summary_markdown,
            "payload_json": json.dumps(payload or {}),
            "requested_by": requested_by,
            "assignee": assignee or requested_by,
            "priority": priority,
            "status": status,
            "thread_id": thread_id,
            "interrupt_id": interrupt_id,
        },
    )
    logger.info(
        "[notifications] Created %s type=%s incident=%s thread=%s",
        notification_id,
        type,
        incident_number,
        thread_id,
    )
    return _row_to_notification(rows[0])


def list_notifications(
    *,
    assignee: str | None = None,
    tab: str = "all",
    limit: int = 50,
    offset: int = 0,
) -> list[dict[str, Any]]:
    if not lakebase_configured():
        return []

    clauses: list[str] = []
    params: dict[str, Any] = {"limit": max(1, min(limit, 200)), "offset": max(0, offset)}
    if assignee:
        clauses.append("assignee = %(assignee)s")
        params["assignee"] = assignee

    tab = (tab or "all").lower()
    if tab == "for_review":
        clauses.append("type = 'review'")
        clauses.append("status = 'pending'")
    elif tab == "for_approval":
        clauses.append("type = 'approval'")
        clauses.append("status = 'pending'")
    elif tab == "information":
        clauses.append("type = 'information'")
    # "all" — no type filter

    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    rows = execute(
        f"""
        SELECT * FROM {AIDQ_SCHEMA}.notifications
        {where}
        ORDER BY requested_on DESC
        LIMIT %(limit)s OFFSET %(offset)s
        """,
        params,
    )
    return [_row_to_notification(r) for r in rows]


def count_notifications(*, assignee: str | None = None) -> dict[str, int]:
    if not lakebase_configured():
        return {"all": 0, "for_review": 0, "for_approval": 0, "information": 0, "pending": 0}

    where = "WHERE assignee = %(assignee)s" if assignee else ""
    params: dict[str, Any] = {"assignee": assignee} if assignee else {}
    rows = execute(
        f"""
        SELECT
          COUNT(*) AS all_count,
          COUNT(*) FILTER (WHERE type = 'review' AND status = 'pending') AS for_review,
          COUNT(*) FILTER (WHERE type = 'approval' AND status = 'pending') AS for_approval,
          COUNT(*) FILTER (WHERE type = 'information') AS information,
          COUNT(*) FILTER (WHERE status = 'pending') AS pending
        FROM {AIDQ_SCHEMA}.notifications
        {where}
        """,
        params,
    )
    row = rows[0] if rows else {}
    return {
        "all": int(row.get("all_count") or 0),
        "for_review": int(row.get("for_review") or 0),
        "for_approval": int(row.get("for_approval") or 0),
        "information": int(row.get("information") or 0),
        "pending": int(row.get("pending") or 0),
    }


def list_for_thread(
    thread_id: str,
    *,
    group_id: str | None = None,
    type: str | None = "approval",
) -> list[dict[str, Any]]:
    """Return all notifications for a graph thread (optionally a single HITL round).

    ``group_id`` is stored in the ``interrupt_id`` column and shared by every
    per-incident notification created in the same request_human_approval round.
    Used by the aggregation gate to decide when every sibling has been resolved.
    """
    if not lakebase_configured():
        return []
    clauses = ["thread_id = %(thread_id)s"]
    params: dict[str, Any] = {"thread_id": thread_id}
    if group_id:
        clauses.append("interrupt_id = %(group_id)s")
        params["group_id"] = group_id
    if type:
        clauses.append("type = %(type)s")
        params["type"] = type
    rows = execute(
        f"""
        SELECT * FROM {AIDQ_SCHEMA}.notifications
        WHERE {' AND '.join(clauses)}
        ORDER BY requested_on
        """,
        params,
    )
    return [_row_to_notification(r) for r in rows]


def get_notification(notification_id: str) -> dict[str, Any] | None:
    if not lakebase_configured():
        return None
    rows = execute(
        f"""
        SELECT * FROM {AIDQ_SCHEMA}.notifications
        WHERE id = %(id)s::uuid
        LIMIT 1
        """,
        {"id": notification_id},
    )
    if not rows:
        return None
    return _row_to_notification(rows[0])


def mark_read(notification_id: str) -> dict[str, Any] | None:
    rows = execute(
        f"""
        UPDATE {AIDQ_SCHEMA}.notifications
        SET status = CASE WHEN status = 'pending' AND type IN ('information', 'review') THEN 'read' ELSE status END,
            read_at = NOW()
        WHERE id = %(id)s::uuid
        RETURNING *
        """,
        {"id": notification_id},
    )
    return _row_to_notification(rows[0]) if rows else None


def mark_all_read(*, assignee: str) -> int:
    rows = execute(
        f"""
        UPDATE {AIDQ_SCHEMA}.notifications
        SET status = CASE WHEN type IN ('information', 'review') AND status = 'pending' THEN 'read' ELSE status END,
            read_at = NOW()
        WHERE assignee = %(assignee)s AND read_at IS NULL
        RETURNING id
        """,
        {"assignee": assignee},
    )
    return len(rows)


def set_decision(
    notification_id: str,
    *,
    status: str,
    decision: dict[str, Any],
    decided_by: str,
) -> dict[str, Any] | None:
    rows = execute(
        f"""
        UPDATE {AIDQ_SCHEMA}.notifications
        SET status = %(status)s,
            decision_json = %(decision)s::jsonb,
            decided_at = NOW(),
            decided_by = %(decided_by)s,
            read_at = COALESCE(read_at, NOW())
        WHERE id = %(id)s::uuid
        RETURNING *
        """,
        {
            "id": notification_id,
            "status": status,
            "decision": json.dumps(decision),
            "decided_by": decided_by,
        },
    )
    return _row_to_notification(rows[0]) if rows else None
