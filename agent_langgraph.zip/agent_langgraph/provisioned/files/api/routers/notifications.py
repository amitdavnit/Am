"""Notifications / Approval API — HITL inbox for the AiDQ UI."""

from __future__ import annotations

import json
import logging
from typing import Any, Literal

from fastapi import APIRouter, BackgroundTasks, HTTPException, Query, Request
from pydantic import BaseModel, Field

from api.services import notifications as notification_service
from api.services.identity import get_user_from_request

logger = logging.getLogger(__name__)
router = APIRouter(tags=["notifications"])


class Notification(BaseModel):
    id: str
    incident_number: str | None = None
    type: Literal["approval", "review", "information"]
    message: str
    summary_markdown: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    requested_by: str | None = None
    assignee: str | None = None
    requested_on: str | None = None
    priority: str = "medium"
    status: str
    thread_id: str | None = None
    interrupt_id: str | None = None
    decision: dict[str, Any] | None = None
    read_at: str | None = None
    decided_at: str | None = None
    decided_by: str | None = None


class NotificationCounts(BaseModel):
    all: int = 0
    for_review: int = 0
    for_approval: int = 0
    information: int = 0
    pending: int = 0


class ApproveRequest(BaseModel):
    approved_esns: list[int] | None = None  # None => approve all
    resume: bool = True  # False = mark decided only (chat already resumed)


class RejectRequest(BaseModel):
    reason: str | None = None
    resume: bool = True


def _extract_final_ai_text(result: dict[str, Any]) -> str:
    """Pull the final assistant text from a resumed graph result (skip tool calls)."""
    messages = (result or {}).get("messages", []) if isinstance(result, dict) else []
    for msg in reversed(messages):
        if getattr(msg, "type", None) == "human" or msg.__class__.__name__ == "HumanMessage":
            continue
        if getattr(msg, "tool_calls", None):
            continue
        content = getattr(msg, "content", None)
        if content is None and isinstance(msg, dict):
            content = msg.get("content")
        if isinstance(content, list):
            content = "".join(
                b.get("text", "") for b in content if isinstance(b, dict)
            )
        if isinstance(content, str) and content.strip():
            return content
    return ""


def _persist_continuation_to_chat(thread_id: str, text: str) -> None:
    """Append the resumed pipeline output as an assistant message so the chat
    window can render the continuation (it polls thread messages)."""
    if not text.strip():
        return
    try:
        from api.services import threads as thread_service

        thread_service.append_messages(
            thread_id,
            [
                {
                    "role": "assistant",
                    "content": text,
                    "parts": [{"type": "text", "text": text}],
                }
            ],
        )
        logger.info(
            "[notifications] Persisted continuation to chat thread=%s (%d chars)",
            thread_id,
            len(text),
        )
    except Exception:
        logger.exception(
            "[notifications] Failed to persist continuation for thread=%s", thread_id
        )


def _resume_supervisor(thread_id: str, resume_payload: dict[str, Any]) -> None:
    """Resume a paused LangGraph thread with a structured HITL decision, then
    persist the continuation output to the chat thread for cross-surface sync.

    Uses asyncio.run so BackgroundTasks can call this from a sync context while
    the Lakebase AsyncCheckpointSaver is active.
    """
    import asyncio

    from langgraph.types import Command

    from agent_server.orchestration.workflows.supervisor_workflow import (
        get_supervisor_graph,
    )
    from agent_server.platform.checkpoint import get_server_loop

    async def _run() -> str:
        graph = get_supervisor_graph()
        config = {"configurable": {"thread_id": thread_id}, "recursion_limit": 25}
        # Guard against a double-resume: only resume if an interrupt is still pending.
        state = await graph.aget_state(config)
        if not any(bool(task.interrupts) for task in state.tasks):
            logger.info(
                "[notifications] Thread=%s has no pending interrupt — skipping resume",
                thread_id,
            )
            return ""
        resume_text = json.dumps(resume_payload)
        result = await graph.ainvoke(Command(resume=resume_text), config=config)
        logger.info("[notifications] Resumed supervisor thread=%s", thread_id)
        return _extract_final_ai_text(result)

    try:
        # The Lakebase checkpointer's pool/lock are bound to the uvicorn main loop.
        # BackgroundTasks runs this sync fn in a threadpool with no running loop, so
        # asyncio.run() would spin up a NEW loop and the final checkpoint write would
        # raise "Lock is bound to a different event loop" (dropping the Pipeline
        # Complete summary). Schedule onto the captured server loop instead.
        server_loop = get_server_loop()
        if server_loop and server_loop.is_running():
            fut = asyncio.run_coroutine_threadsafe(_run(), server_loop)
            final_text = fut.result(timeout=600)
        else:
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None
            if loop and loop.is_running():
                fut = asyncio.run_coroutine_threadsafe(_run(), loop)
                final_text = fut.result(timeout=600)
            else:
                final_text = asyncio.run(_run())
    except Exception:
        logger.exception(
            "[notifications] Failed to resume supervisor for thread=%s", thread_id
        )
        return

    _persist_continuation_to_chat(thread_id, final_text)


def _aggregate_group_decision(siblings: list[dict[str, Any]]) -> dict[str, Any]:
    """Combine per-incident decisions into one supervisor HITL decision.

    approved_esns = union of every approved incident's ESNs (honouring partial
    per-incident approvals). approved_incidents / rejected_incidents let
    apply_corrections resolve only the tickets the user approved.
    """
    approved = [s for s in siblings if s.get("status") == "approved"]
    rejected = [s for s in siblings if s.get("status") == "rejected"]

    union: list[int] = []
    seen: set[int] = set()

    def _add(values: Any) -> None:
        for v in values or []:
            try:
                iv = int(v)
            except (TypeError, ValueError):
                continue
            if iv not in seen:
                seen.add(iv)
                union.append(iv)

    for s in approved:
        decision = s.get("decision") or {}
        payload = s.get("payload") or {}
        if decision.get("decision") == "partial" and decision.get("approved_esns"):
            _add(decision.get("approved_esns"))
        else:
            _add(payload.get("esns"))

    approved_incidents = [s.get("incident_number") for s in approved if s.get("incident_number")]
    rejected_incidents = [s.get("incident_number") for s in rejected if s.get("incident_number")]

    return {
        "decision": "partial" if union else "none",
        "approved_esns": union,
        "approved_incidents": approved_incidents,
        "rejected_incidents": rejected_incidents,
    }


def _handle_group_resume(
    item: dict[str, Any],
    decision: dict[str, Any],
    *,
    should_resume: bool,
    background_tasks: BackgroundTasks,
) -> None:
    """Aggregation gate: record the per-incident decision; resume the graph ONCE
    when every sibling notification in the round has been decided."""
    thread_id = item.get("thread_id")
    if not (should_resume and thread_id):
        return

    # 'review' notifications (source-level issue / RCA-only) are acknowledgement-only —
    # there is no paused graph to resume for them.
    if item.get("type") == "review":
        return

    group_id = (item.get("payload") or {}).get("group_id") or item.get("interrupt_id")

    # Legacy / single-notification approval (no per-incident group) — resume immediately.
    if not group_id:
        background_tasks.add_task(_resume_supervisor, thread_id, decision)
        return

    siblings = notification_service.list_for_thread(
        thread_id, group_id=group_id, type="approval"
    )
    pending = [s for s in siblings if s.get("status") == "pending"]
    if pending:
        logger.info(
            "[notifications] Group %s — %d/%d incident(s) still pending; waiting",
            group_id,
            len(pending),
            len(siblings),
        )
        return

    aggregated = _aggregate_group_decision(siblings)
    logger.info(
        "[notifications] Group %s fully decided — resuming thread=%s decision=%s",
        group_id,
        thread_id,
        aggregated,
    )
    background_tasks.add_task(_resume_supervisor, thread_id, aggregated)


@router.get("/notifications", response_model=list[Notification])
async def list_notifications(
    request: Request,
    tab: str = Query(default="all"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> list[Notification]:
    user = get_user_from_request(request)
    items = notification_service.list_notifications(
        assignee=user.id,
        tab=tab,
        limit=limit,
        offset=offset,
    )
    return [Notification(**item) for item in items]


@router.get("/notifications/count", response_model=NotificationCounts)
async def notification_counts(request: Request) -> NotificationCounts:
    user = get_user_from_request(request)
    counts = notification_service.count_notifications(assignee=user.id)
    return NotificationCounts(**counts)


@router.get("/notifications/{notification_id}", response_model=Notification)
async def get_notification(request: Request, notification_id: str) -> Notification:
    user = get_user_from_request(request)
    item = notification_service.get_notification(notification_id)
    if not item:
        raise HTTPException(status_code=404, detail="Notification not found")
    if item.get("assignee") != user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    return Notification(**item)


@router.post("/notifications/{notification_id}/approve", response_model=Notification)
async def approve_notification(
    request: Request,
    notification_id: str,
    background_tasks: BackgroundTasks,
    body: ApproveRequest | None = None,
) -> Notification:
    user = get_user_from_request(request)
    item = notification_service.get_notification(notification_id)
    if not item:
        raise HTTPException(status_code=404, detail="Notification not found")
    if item.get("assignee") != user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    if item.get("status") != "pending":
        raise HTTPException(status_code=409, detail="Notification is not pending")
    if item.get("type") not in ("approval", "review"):
        raise HTTPException(status_code=400, detail="Notification is not actionable")

    approved_esns = body.approved_esns if body else None
    # "review" = manual acknowledgement (source issue / RCA); "approval" = correction HITL
    is_review = item.get("type") == "review"
    if is_review:
        decision = {"decision": "acknowledged"}
    elif approved_esns is None:
        decision = {"decision": "all", "approved_esns": None}
    else:
        decision = {"decision": "partial", "approved_esns": approved_esns}
    updated = notification_service.set_decision(
        notification_id,
        status="acknowledged" if is_review else "approved",
        decision=decision,
        decided_by=user.id,
    )
    should_resume = body.resume if body is not None else True
    _handle_group_resume(
        updated or item,
        decision,
        should_resume=should_resume,
        background_tasks=background_tasks,
    )
    return Notification(**(updated or item))


@router.post("/notifications/{notification_id}/reject", response_model=Notification)
async def reject_notification(
    request: Request,
    notification_id: str,
    background_tasks: BackgroundTasks,
    body: RejectRequest | None = None,
) -> Notification:
    user = get_user_from_request(request)
    item = notification_service.get_notification(notification_id)
    if not item:
        raise HTTPException(status_code=404, detail="Notification not found")
    if item.get("assignee") != user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    if item.get("status") != "pending":
        raise HTTPException(status_code=409, detail="Notification is not pending")

    is_review = item.get("type") == "review"
    if is_review:
        decision = {"decision": "dismissed", "reason": (body.reason if body else None)}
    else:
        decision = {
            "decision": "none",
            "approved_esns": [],
            "reason": (body.reason if body else None),
        }
    updated = notification_service.set_decision(
        notification_id,
        status="dismissed" if is_review else "rejected",
        decision=decision,
        decided_by=user.id,
    )
    should_resume = body.resume if body is not None else True
    _handle_group_resume(
        updated or item,
        decision,
        should_resume=should_resume,
        background_tasks=background_tasks,
    )
    return Notification(**(updated or item))


@router.post("/notifications/{notification_id}/read", response_model=Notification)
async def mark_notification_read(request: Request, notification_id: str) -> Notification:
    user = get_user_from_request(request)
    item = notification_service.get_notification(notification_id)
    if not item:
        raise HTTPException(status_code=404, detail="Notification not found")
    if item.get("assignee") != user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    updated = notification_service.mark_read(notification_id)
    return Notification(**(updated or item))


@router.post("/notifications/mark-all-read")
async def mark_all_read(request: Request) -> dict[str, Any]:
    user = get_user_from_request(request)
    count = notification_service.mark_all_read(assignee=user.id)
    return {"ok": True, "updated": count}
