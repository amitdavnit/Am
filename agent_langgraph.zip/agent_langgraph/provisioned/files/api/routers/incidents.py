"""Incident REST endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from api.services import incidents as incident_service
from api.services.incidents import LakebaseStorageError

router = APIRouter(tags=["incidents"])


class Incident(BaseModel):
    incident_id: str | None = None
    violation_id: str | None = None
    title: str | None = None
    description: str | None = None
    priority: str | None = None
    status: str | None = None
    assigned_to: str | None = None
    created_date: str | None = None
    closed_date: str | None = None


class IncidentListResponse(BaseModel):
    items: list[Incident]
    total: int


@router.get("/incidents", response_model=IncidentListResponse)
async def list_incidents(
    status: str | None = Query(default=None),
    priority: str | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=500),
) -> IncidentListResponse:
    try:
        items = incident_service.list_incidents(status=status, priority=priority, limit=limit)
    except LakebaseStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return IncidentListResponse(items=[Incident(**item) for item in items], total=len(items))


@router.get("/incidents/summary")
async def incidents_summary() -> dict:
    try:
        items = incident_service.list_incidents(limit=500)
    except LakebaseStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    by_priority: dict[str, int] = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
    by_status: dict[str, int] = {"New": 0, "In Progress": 0, "Resolved": 0}
    for item in items:
        p = item.get("priority") or "Low"
        s = item.get("status") or "New"
        by_priority[p] = by_priority.get(p, 0) + 1
        by_status[s] = by_status.get(s, 0) + 1

    return {
        "total": len(items),
        "critical": by_priority.get("Critical", 0),
        "high": by_priority.get("High", 0),
        "medium": by_priority.get("Medium", 0),
        "low": by_priority.get("Low", 0),
        "in_progress": by_status.get("In Progress", 0),
        "resolved": by_status.get("Resolved", 0),
        "new": by_status.get("New", 0),
        "by_priority": by_priority,
        "by_status": by_status,
    }


@router.get("/incidents/{incident_id}", response_model=Incident)
async def get_incident(incident_id: str) -> Incident:
    try:
        item = incident_service.get_incident(incident_id)
    except LakebaseStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not item:
        raise HTTPException(status_code=404, detail=f"Incident {incident_id} not found")
    return Incident(**item)
