"""User feedback logging endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Request
from pydantic import BaseModel, Field

from api.services.feedback import append_feedback, list_feedback
from api.services.identity import get_user_from_request

router = APIRouter(tags=["feedback"])


class FeedbackRequest(BaseModel):
    conversation_id: str | None = None
    message_id: str | None = None
    rating: str = Field(description="up | down | comment")
    comment: str | None = None
    answer_excerpt: str | None = None
    question: str | None = None


class FeedbackResponse(BaseModel):
    ok: bool = True
    timestamp: str


@router.post("/feedback", response_model=FeedbackResponse)
async def submit_feedback(request: Request, body: FeedbackRequest) -> FeedbackResponse:
    user = get_user_from_request(request)
    saved = append_feedback(
        {
            "conversation_id": body.conversation_id or "unknown",
            "workflow": "aidq_chat",
            "agent_name": "user_feedback",
            "event_type": "message_feedback",
            "payload": {
                "user_id": user.id,
                "display_name": user.display_name,
                "rating": body.rating,
                "comment": body.comment,
                "message_id": body.message_id,
                "question": body.question,
                "answer_excerpt": (body.answer_excerpt or "")[:500],
            },
        }
    )
    return FeedbackResponse(timestamp=saved["timestamp"])


@router.get("/feedback/{conversation_id}")
async def get_feedback(request: Request, conversation_id: str) -> dict:
    user = get_user_from_request(request)
    events = list_feedback(conversation_id=conversation_id, user_id=user.id)
    return {
        str(event["message_id"]): {
            "messageId": event["message_id"],
            "feedbackType": (
                "thumbs_up" if event.get("rating") == "up" else "thumbs_down"
            ),
            "assessmentId": None,
        }
        for event in events
        if event.get("message_id") and event.get("rating") in {"up", "down"}
    }
