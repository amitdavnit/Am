"""Current user identity router."""

from __future__ import annotations

from fastapi import APIRouter, Request
from pydantic import BaseModel

from api.services.identity import get_user_from_request

router = APIRouter(tags=["me"])


class MeResponse(BaseModel):
    id: str
    display_name: str
    email: str | None = None
    role: str = "Data Quality Analyst"
    initials: str


def _initials(name: str) -> str:
    parts = [p for p in name.strip().split() if p]
    if not parts:
        return "?"
    if len(parts) == 1:
        return parts[0][:2].upper()
    return (parts[0][0] + parts[-1][0]).upper()


@router.get("/me", response_model=MeResponse)
async def me(request: Request) -> MeResponse:
    user = get_user_from_request(request)
    return MeResponse(
        id=user.id,
        display_name=user.display_name,
        email=user.email,
        role=user.role,
        initials=_initials(user.display_name),
    )
