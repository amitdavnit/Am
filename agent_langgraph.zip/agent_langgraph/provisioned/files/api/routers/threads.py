"""Chat thread history endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, Field

from api.services import threads as thread_service
from api.services.identity import get_user_from_request

router = APIRouter(tags=["threads"])


class ThreadSummary(BaseModel):
    id: str
    user_id: str | None = None
    title: str
    created_at: str | None = None
    updated_at: str | None = None
    message_count: int = 0


class ThreadMessage(BaseModel):
    id: str | None = None
    role: str
    content: str
    parts: list[dict[str, Any]] | None = None
    attachments: list[dict[str, Any]] = Field(default_factory=list)
    trace_id: str | None = None
    created_at: str | None = None


class ThreadDetail(BaseModel):
    id: str
    user_id: str | None = None
    title: str
    created_at: str | None = None
    updated_at: str | None = None
    messages: list[ThreadMessage] = Field(default_factory=list)


class CreateThreadRequest(BaseModel):
    id: str | None = None
    title: str | None = None


class AppendMessagesRequest(BaseModel):
    messages: list[ThreadMessage]
    title: str | None = None


@router.get("/threads", response_model=list[ThreadSummary])
async def list_threads(
    request: Request,
    limit: int = Query(default=50, ge=1, le=200),
    ending_before: str | None = Query(default=None),
) -> list[ThreadSummary]:
    user = get_user_from_request(request)
    items = thread_service.list_threads(
        user_id=user.id,
        limit=limit,
        ending_before=ending_before,
    )
    return [ThreadSummary(**item) for item in items]


@router.post("/threads", response_model=ThreadDetail)
async def create_thread(request: Request, body: CreateThreadRequest | None = None) -> ThreadDetail:
    user = get_user_from_request(request)
    thread = thread_service.create_thread(
        user_id=user.id,
        title=(body.title if body else None),
        thread_id=(body.id if body else None),
    )
    if thread.get("user_id") != user.id:
        raise HTTPException(status_code=409, detail="Thread ID already exists")
    return ThreadDetail(**thread)


@router.get("/threads/{thread_id}", response_model=ThreadDetail)
async def get_thread(request: Request, thread_id: str) -> ThreadDetail:
    thread = thread_service.get_thread(thread_id)
    if not thread:
        raise HTTPException(status_code=404, detail="Thread not found")
    user = get_user_from_request(request)
    if thread.get("user_id") != user.id:
        raise HTTPException(status_code=403, detail="Thread access denied")
    return ThreadDetail(**thread)


@router.post("/threads/{thread_id}/messages", response_model=ThreadDetail)
async def append_messages(
    request: Request, thread_id: str, body: AppendMessagesRequest
) -> ThreadDetail:
    existing = thread_service.get_thread(thread_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Thread not found")
    user = get_user_from_request(request)
    if existing.get("user_id") != user.id:
        raise HTTPException(status_code=403, detail="Thread access denied")
    thread = thread_service.append_messages(
        thread_id,
        [m.model_dump() for m in body.messages],
        title=body.title,
    )
    if not thread:
        raise HTTPException(status_code=404, detail="Thread not found")
    return ThreadDetail(**thread)


@router.delete("/threads/{thread_id}")
async def delete_thread(request: Request, thread_id: str) -> dict:
    existing = thread_service.get_thread(thread_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Thread not found")
    user = get_user_from_request(request)
    if existing.get("user_id") != user.id:
        raise HTTPException(status_code=403, detail="Thread access denied")
    if not thread_service.delete_thread(thread_id):
        raise HTTPException(status_code=404, detail="Thread not found")
    return {"ok": True}
