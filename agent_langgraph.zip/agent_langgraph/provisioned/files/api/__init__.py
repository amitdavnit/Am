"""Top-level FastAPI API package — REST for UI, separate from agent_server."""

from __future__ import annotations

from fastapi import APIRouter

from api.routers import feedback, health, incidents, me, notifications, threads

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(health.router)
api_router.include_router(me.router)
api_router.include_router(incidents.router)
api_router.include_router(threads.router)
api_router.include_router(notifications.router)
api_router.include_router(feedback.router)
