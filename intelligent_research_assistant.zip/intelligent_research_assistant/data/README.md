Put your PDF here for CLI use, for example:

data/attention_is_all_you_need.pdf

The PDF is intentionally not bundled.
