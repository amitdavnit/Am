import tempfile
import streamlit as st
from src.pipeline import ResearchAssistant

st.set_page_config(page_title="Intelligent Research Assistant", page_icon="🤖", layout="wide")
st.title("🤖 Intelligent Agentic Research Assistant")
st.caption("LangChain + CrewAI + ChromaDB + Groq + Tavily")

@st.cache_resource
def get_assistant():
    return ResearchAssistant()

try:
    assistant = get_assistant()
except Exception as exc:
    st.error(f"Startup error: {exc}")
    st.info("Add keys to .env and install requirements.")
    st.stop()

with st.sidebar:
    st.header("1. Upload document")
    uploaded = st.file_uploader("Upload PDF", type=["pdf"])

    if uploaded is not None and st.button("Process / Re-index PDF", type="primary"):
        with st.spinner("Chunking, embedding and indexing..."):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                tmp.write(uploaded.read())
                tmp_path = tmp.name
            try:
                info = assistant.index_pdf(tmp_path, reset=True)
                st.session_state["indexed_pdf"] = uploaded.name
                st.success(f"Indexed {uploaded.name}: {info['pages']} pages, {info['chunks']} chunks")
            except Exception as exc:
                st.error(f"Indexing failed: {exc}")

    if "indexed_pdf" in st.session_state:
        st.success(f"Active: {st.session_state['indexed_pdf']}")

    st.divider()
    st.write("LOCAL → ChromaDB")
    st.write("WEB → Tavily")
    st.write("BOTH → ChromaDB + Tavily")

question = st.text_input(
    "Ask a question",
    placeholder="What is self-attention according to the uploaded paper?"
)

if st.button("Ask", disabled=not bool(question.strip())):
    with st.spinner("Routing → retrieving → answering → validating..."):
        try:
            result = assistant.ask(question.strip())
        except Exception as exc:
            st.error(f"Request failed: {exc}")
            st.stop()

    c1, c2 = st.columns(2)
    c1.metric("Selected route", result["route"])
    score = result["validation"].get("score")
    c2.metric("Validation score", f"{score}/100" if score is not None else "N/A")

    st.subheader("Answer")
    st.write(result["answer"])

    st.subheader("Validation")
    st.json(result["validation"])

    if result["sources"]:
        st.subheader("Sources")
        for src in result["sources"]:
            if src["type"] == "local":
                p = src.get("page")
                page_text = f"page {p + 1}" if isinstance(p, int) else "page ?"
                st.write(f"📄 {src['source']} — {page_text} — relevance {src['relevance']}")
            else:
                st.write(f"🌐 {src.get('title','Web source')}: {src.get('url','')}")
