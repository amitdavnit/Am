from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings
from .config import settings

class VectorStoreService:
    def __init__(self):
        self.embeddings = HuggingFaceEmbeddings(
            model_name=settings.embedding_model,
            encode_kwargs={"normalize_embeddings": True},
        )
        self._open_db()

    def _open_db(self):
        self.db = Chroma(
            collection_name=settings.chroma_collection,
            embedding_function=self.embeddings,
            persist_directory=settings.chroma_dir,
        )

    def reset(self):
        try:
            self.db.delete_collection()
        except Exception:
            pass
        self._open_db()

    def add_documents(self, chunks):
        if not chunks:
            return 0
        self.db.add_documents(chunks)
        return len(chunks)

    def search(self, query, k=None):
        return self.db.similarity_search_with_relevance_scores(
            query, k=k or settings.top_k
        )
