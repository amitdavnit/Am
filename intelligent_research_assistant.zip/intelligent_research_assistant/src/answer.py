from langchain_groq import ChatGroq
from .config import settings

class AnswerGenerator:
    def __init__(self):
        if not settings.groq_api_key:
            raise RuntimeError("GROQ_API_KEY missing in .env")
        self.llm = ChatGroq(
            api_key=settings.groq_api_key,
            model=settings.groq_model,
            temperature=0.2,
        )

    def generate(self, question, local_results=None, web_results=None):
        local_results = local_results or []
        web_results = web_results or []

        parts = []
        for i, (doc, score) in enumerate(local_results, 1):
            source = doc.metadata.get("source", "uploaded document")
            page = doc.metadata.get("page", "?")
            parts.append(
                f"[LOCAL {i}] source={source}, page={page}, relevance={score:.3f}\n"
                + doc.page_content
            )

        for i, item in enumerate(web_results, 1):
            parts.append(
                f"[WEB {i}] title={item.get('title','')}\n"
                f"url={item.get('url','')}\n"
                f"{item.get('content','')}"
            )

        context = "\n\n".join(parts)
        prompt = (
            "You are an intelligent research assistant.\n"
            "Answer using ONLY the supplied context.\n"
            "If context is insufficient, explicitly say what is missing.\n"
            "Do not fabricate facts or citations.\n"
            "Use source/page references for local content and URLs for web content.\n\n"
            f"QUESTION:\n{question}\n\n"
            f"CONTEXT:\n{context}"
        )
        return self.llm.invoke(prompt).content
