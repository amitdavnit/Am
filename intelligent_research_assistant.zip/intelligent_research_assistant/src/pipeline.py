from pathlib import Path
from .ingestion import load_pdf, chunk_documents
from .vector_store import VectorStoreService
from .web_search import WebSearchService
from .router import QueryRouter
from .answer import AnswerGenerator
from .validator import ResponseValidator

class ResearchAssistant:
    def __init__(self):
        self.vector_store = VectorStoreService()
        self.web_search = WebSearchService()
        self.router = QueryRouter()
        self.answer_generator = AnswerGenerator()
        self.validator = ResponseValidator()

    def index_pdf(self, pdf_path, reset=True):
        docs = load_pdf(pdf_path)
        chunks = chunk_documents(docs)
        if reset:
            self.vector_store.reset()
        count = self.vector_store.add_documents(chunks)
        return {"file": Path(pdf_path).name, "pages": len(docs), "chunks": count}

    def ask(self, question):
        route = self.router.route(question)
        local_results = []
        web_results = []

        if route in ("LOCAL", "BOTH"):
            try:
                local_results = self.vector_store.search(question)
            except Exception:
                local_results = []

        if route in ("WEB", "BOTH"):
            try:
                web_results = self.web_search.search(question)
            except Exception as exc:
                web_results = [{"title": "Web unavailable", "url": "", "content": str(exc)}]

        answer = self.answer_generator.generate(
            question, local_results=local_results, web_results=web_results
        )

        context_parts = []
        for doc, score in local_results:
            context_parts.append(f"LOCAL score={score:.3f}\n{doc.page_content}")
        for item in web_results:
            context_parts.append(f"WEB {item.get('url','')}\n{item.get('content','')}")

        validation = self.validator.validate(
            question, answer, "\n\n".join(context_parts)
        )

        sources = []
        for doc, score in local_results:
            sources.append({
                "type": "local",
                "source": doc.metadata.get("source", "uploaded document"),
                "page": doc.metadata.get("page"),
                "relevance": round(float(score), 3),
            })
        for item in web_results:
            if item.get("url"):
                sources.append({
                    "type": "web",
                    "title": item.get("title", ""),
                    "url": item.get("url", ""),
                })

        return {
            "route": route,
            "answer": answer,
            "validation": validation,
            "sources": sources,
        }
