import re
from crewai import Agent, Task, Crew
from langchain_groq import ChatGroq
from .config import settings

class QueryRouter:
    def __init__(self):
        self.llm = None
        if settings.groq_api_key:
            self.llm = ChatGroq(
                api_key=settings.groq_api_key,
                model=settings.groq_model,
                temperature=0,
            )

    @staticmethod
    def fallback_route(query):
        q = query.lower()
        both_words = ["compare", "comparison", "versus", " vs ", "modern", "current architecture"]
        web_words = ["latest", "today", "current", "recent", "news", "this week", "this month", "newest", "updated"]
        if any(x in q for x in both_words):
            return "BOTH"
        if any(x in q for x in web_words):
            return "WEB"
        return "LOCAL"

    def route(self, query):
        if not self.llm:
            return self.fallback_route(query)

        try:
            agent = Agent(
                role="Research Query Router",
                goal="Choose LOCAL, WEB, or BOTH as the best information source.",
                backstory="You only classify the source and never answer the user question.",
                llm=self.llm,
                verbose=False,
                allow_delegation=False,
            )
            description = (
                "Classify the query into exactly one label: LOCAL, WEB, or BOTH.\n"
                "LOCAL = uploaded PDF/document is enough.\n"
                "WEB = fresh/current external information is needed.\n"
                "BOTH = local document plus current/external information are both useful.\n"
                f"Query: {query}\n"
                "Return only one word."
            )
            task = Task(
                description=description,
                expected_output="Exactly one of LOCAL, WEB, BOTH",
                agent=agent,
            )
            result = str(Crew(agents=[agent], tasks=[task], verbose=False).kickoff()).upper()
            match = re.search(r"\b(LOCAL|WEB|BOTH)\b", result)
            if match:
                return match.group(1)
        except Exception:
            pass

        return self.fallback_route(query)
