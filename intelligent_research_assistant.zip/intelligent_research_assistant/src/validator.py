import re
from crewai import Agent, Task, Crew
from langchain_groq import ChatGroq
from .config import settings

class ResponseValidator:
    def __init__(self):
        self.llm = None
        if settings.groq_api_key:
            self.llm = ChatGroq(
                api_key=settings.groq_api_key,
                model=settings.groq_model,
                temperature=0,
            )

    def validate(self, question, answer, context):
        if not self.llm:
            return {"status": "SKIPPED", "score": None, "reason": "No Groq key."}

        try:
            agent = Agent(
                role="Grounding Validator",
                goal="Check whether the answer is supported by retrieved context.",
                backstory="You are a strict RAG quality and hallucination reviewer.",
                llm=self.llm,
                verbose=False,
                allow_delegation=False,
            )
            description = (
                "Evaluate the answer against the supplied context.\n\n"
                f"Question:\n{question}\n\n"
                f"Answer:\n{answer}\n\n"
                f"Context:\n{context}\n\n"
                "Return exactly three lines:\n"
                "STATUS: PASS or FAIL\n"
                "SCORE: integer 0 to 100\n"
                "REASON: one short explanation"
            )
            task = Task(
                description=description,
                expected_output="STATUS, SCORE, and REASON in three lines",
                agent=agent,
            )
            result = str(Crew(agents=[agent], tasks=[task], verbose=False).kickoff())

            sm = re.search(r"STATUS:\s*(PASS|FAIL)", result, re.I)
            scm = re.search(r"SCORE:\s*(\d{1,3})", result, re.I)
            rm = re.search(r"REASON:\s*(.+)", result, re.I | re.S)

            return {
                "status": sm.group(1).upper() if sm else "UNKNOWN",
                "score": int(scm.group(1)) if scm else None,
                "reason": rm.group(1).strip() if rm else result.strip(),
            }
        except Exception as exc:
            return {"status": "ERROR", "score": None, "reason": str(exc)}
