from tavily import TavilyClient
from .config import settings

class WebSearchService:
    def __init__(self):
        self.client = TavilyClient(api_key=settings.tavily_api_key) if settings.tavily_api_key else None

    def search(self, query, max_results=5):
        if not self.client:
            raise RuntimeError("TAVILY_API_KEY missing in .env")
        result = self.client.search(
            query=query,
            search_depth="advanced",
            max_results=max_results,
            include_answer=False,
        )
        return result.get("results", [])
