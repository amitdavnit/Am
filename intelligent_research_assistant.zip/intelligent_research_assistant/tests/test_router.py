from src.router import QueryRouter

def test_local():
    assert QueryRouter.fallback_route("Explain self-attention from this document") == "LOCAL"

def test_web():
    assert QueryRouter.fallback_route("What are the latest transformer developments?") == "WEB"

def test_both():
    assert QueryRouter.fallback_route("Compare this paper with modern transformer architectures") == "BOTH"
