import argparse
from src.pipeline import ResearchAssistant

def main():
    parser = argparse.ArgumentParser(description="Intelligent Agentic Research Assistant")
    parser.add_argument("--pdf", help="Optional PDF to index")
    parser.add_argument("--question", required=True)
    args = parser.parse_args()

    assistant = ResearchAssistant()

    if args.pdf:
        info = assistant.index_pdf(args.pdf, reset=True)
        print(f"Indexed {info['file']} | pages={info['pages']} | chunks={info['chunks']}")

    result = assistant.ask(args.question)
    print("\nROUTE:", result["route"])
    print("\nANSWER:\n", result["answer"])
    print("\nVALIDATION:", result["validation"])
    print("\nSOURCES:")
    for src in result["sources"]:
        print("-", src)

if __name__ == "__main__":
    main()
