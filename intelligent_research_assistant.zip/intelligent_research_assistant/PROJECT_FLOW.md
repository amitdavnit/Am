# Demo / Viva Flow

1. PDF is loaded with `PyPDFLoader`.
2. Text is split using `RecursiveCharacterTextSplitter`.
3. `BAAI/bge-small-en-v1.5` creates vector embeddings.
4. ChromaDB stores the embeddings.
5. CrewAI Router chooses LOCAL / WEB / BOTH.
6. LOCAL uses vector similarity search.
7. WEB uses Tavily search.
8. Groq LLM creates a grounded answer from retrieved context.
9. CrewAI Validator checks grounding and gives a score.
10. Streamlit displays the route, answer, validation, and sources.

## Why embeddings?
They convert text into vectors so semantically similar text can be retrieved.

## Why chunking?
Smaller focused chunks improve retrieval precision and fit model context limits.

## Why a router?
Document questions and current-web questions need different sources.

## Why validation?
RAG can still hallucinate, so a second agent checks grounding.
