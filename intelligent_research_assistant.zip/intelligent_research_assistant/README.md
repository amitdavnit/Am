# Intelligent Agentic Research Assistant

Complete training-case-study project using:

- LangChain
- CrewAI
- ChromaDB
- `BAAI/bge-small-en-v1.5` embeddings
- Groq LLM
- Tavily web search
- Streamlit UI

## Architecture

```text
User Query
    |
CrewAI Router
    |
    +---------- LOCAL ----------> ChromaDB
    |
    +---------- WEB ------------> Tavily
    |
    +---------- BOTH -----------> ChromaDB + Tavily
                                   |
                                 Groq LLM
                                   |
                             CrewAI Validator
                                   |
                           Final Answer + Sources
```

## Setup on Windows

Recommended Python: 3.11

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Open `.env` and add your Groq and Tavily API keys.

## Run

```bat
streamlit run app.py
```

Then:

1. Upload a PDF.
2. Click **Process / Re-index PDF**.
3. Ask a question.
4. Router chooses LOCAL / WEB / BOTH.
5. Answer is generated and validated.

## CLI

```bat
python cli.py --pdf data\attention_is_all_you_need.pdf --question "What is self-attention?"
```

For later questions without re-indexing:

```bat
python cli.py --question "Explain multi-head attention"
```

## Example routing

LOCAL:
- What is self-attention according to this paper?
- Explain the encoder architecture in the uploaded PDF.

WEB:
- What are the latest transformer developments?
- What is new in LLMs today?

BOTH:
- Compare the original transformer paper with modern transformer architectures.

## Project folders

```text
intelligent_research_assistant/
├── app.py
├── cli.py
├── requirements.txt
├── .env.example
├── src/
│   ├── config.py
│   ├── ingestion.py
│   ├── vector_store.py
│   ├── web_search.py
│   ├── router.py
│   ├── answer.py
│   ├── validator.py
│   └── pipeline.py
├── data/
├── chroma_db/
└── tests/
```

The research paper itself is not included. Upload your own PDF in the UI or place it in `data/`.
